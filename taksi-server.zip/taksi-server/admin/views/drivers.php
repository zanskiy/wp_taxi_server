<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$action  = sanitize_key( $_GET['action'] ?? 'list' );
$id      = (int) ( $_GET['id'] ?? 0 );
$saved   = ! empty( $_GET['saved'] );
$deleted = ! empty( $_GET['deleted'] );

$default_commission = (float) get_option( 'ts_default_commission_pct', 0 );

if ( $action === 'edit' && $id ) {
    $driver = TS_Drivers::get( $id );
    if ( ! $driver ) { $action = 'list'; }
}

if ( $action === 'add' || $action === 'edit' ) :
    $d = $driver ?? null;
    $payment_type     = $d ? $d->payment_type     : 'percent';
    $commission_pct   = $d ? (float) $d->commission_pct   : $default_commission;
    $subscription_fee = $d ? (float) $d->subscription_fee : 0.00;
?>
<div class="wrap ts-wrap">
<h1><?php echo $d ? 'Редактировать водителя' : 'Новый водитель'; ?></h1>
<?php if ($saved): ?><div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div><?php endif; ?>

<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="driver">
  <?php if ($d): ?><input type="hidden" name="id" value="<?php echo $d->id; ?>"><?php endif; ?>
  <?php wp_nonce_field('ts_save'); ?>

  <table class="form-table">
    <tr><th>Имя *</th>
        <td><input type="text" name="name" class="regular-text" required value="<?php echo esc_attr($d->name??''); ?>"></td></tr>
    <tr><th>Позывной *</th>
        <td><input type="text" name="callsign" class="regular-text" required value="<?php echo esc_attr($d->callsign??''); ?>">
        <p class="description">Должен совпадать с позывным автомобиля для входа через сайт.</p></td></tr>
    <tr><th>Телефон</th>
        <td><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr($d->phone??''); ?>"></td></tr>
    <tr><th>Номер водительского</th>
        <td><input type="text" name="license" class="regular-text" value="<?php echo esc_attr($d->license??''); ?>"></td></tr>
    <tr><th>Статус</th>
        <td><select name="status">
          <?php foreach(array('active'=>'Активен','inactive'=>'Неактивен','blocked'=>'Заблокирован','pending'=>'Ожидает одобрения') as $v=>$l): ?>
          <option value="<?php echo $v; ?>" <?php selected($d->status??'active',$v); ?>><?php echo $l; ?></option>
          <?php endforeach; ?>
        </select></td></tr>
    <tr><th>Telegram Chat ID</th>
        <td><input type="text" name="telegram_chat_id" class="regular-text" value="<?php echo esc_attr($d->telegram_chat_id??''); ?>">
        <p class="description">Для уведомлений через Telegram-бот.</p></td></tr>
    <tr><th>Viber ID</th>
        <td><input type="text" name="viber_id" class="regular-text" value="<?php echo esc_attr($d->viber_id??''); ?>"></td></tr>
    <tr><th>Max ID</th>
        <td><input type="text" name="max_id" class="regular-text" value="<?php echo esc_attr($d->max_id??''); ?>"></td></tr>

    <tr><td colspan="2"><hr><h2 style="margin:0 0 4px;">💰 Модель оплаты</h2></td></tr>

    <tr><th>Тип оплаты</th>
        <td>
          <label style="margin-right:16px;">
            <input type="radio" name="payment_type" value="percent" <?php checked($payment_type,'percent'); ?>> Процент с поездок
          </label>
          <label>
            <input type="radio" name="payment_type" value="subscription"> Абонентская плата
          </label>
          <p class="description">Выберите как водитель рассчитывается с вами.</p>
        </td></tr>

    <tr id="row-commission" style="<?php echo $payment_type==='percent' ? '' : 'display:none;'; ?>">
        <th>Комиссия (%)</th>
        <td><input type="number" name="commission_pct" class="small-text" min="0" max="100" step="0.01"
                   value="<?php echo esc_attr(number_format($commission_pct,2,'.','')); ?>">
        <p class="description">Процент от стоимости каждой поездки, который водитель отдаёт вам.</p></td></tr>

    <tr id="row-subscription" style="<?php echo $payment_type==='subscription' ? '' : 'display:none;'; ?>">
        <th>Абонентская плата (BYN/мес)</th>
        <td><input type="number" name="subscription_fee" class="small-text" min="0" step="0.01"
                   value="<?php echo esc_attr(number_format($subscription_fee,2,'.','')); ?>">
        <p class="description">Фиксированная сумма в месяц, которую водитель платит вам.</p></td></tr>

    <tr><td colspan="2"><hr></td></tr>
    <tr><th>Примечание</th>
        <td><textarea name="notes" class="large-text" rows="3"><?php echo esc_textarea($d->notes??''); ?></textarea></td></tr>
  </table>

  <?php if ($d) : $secret = get_option('ts_driver_secret','taksi-server'); $token = md5($d->callsign.$secret); ?>
  <div style="background:#f0f7ff;border:1px solid #b3d4fb;border-radius:8px;padding:12px;margin:12px 0;">
    <strong>Данные для входа:</strong><br>
    Позывной: <code><?php echo esc_html($d->callsign); ?></code>&nbsp;
    Токен: <code><?php echo esc_html($token); ?></code>
    <button type="button" class="ts-copy-btn button button-small" style="margin-left:8px;"
            data-copy="Позывной: <?php echo esc_attr($d->callsign); ?> | Токен: <?php echo esc_attr($token); ?>">Скопировать</button>
  </div>
  <?php endif; ?>

  <p>
    <button type="submit" class="button button-primary">💾 Сохранить</button>
    <a href="?page=ts-drivers" class="button">Отмена</a>
  </p>
</form>
</div>

<script>
document.querySelectorAll('[name="payment_type"]').forEach(function(radio){
  radio.addEventListener('change', function(){
    document.getElementById('row-commission').style.display   = (this.value==='percent')       ? '' : 'none';
    document.getElementById('row-subscription').style.display = (this.value==='subscription')  ? '' : 'none';
  });
});
</script>

<?php else:
/* ---- LIST ---- */
$drivers = TS_Drivers::get_all( array( 'limit' => 500 ) );
$status_labels = array(
    'active'  => '<span style="color:#4caf50;font-weight:600;">● Активен</span>',
    'inactive' => '<span style="color:#9e9e9e;">● Неактивен</span>',
    'blocked'  => '<span style="color:#e53935;">● Заблок.</span>',
    'pending'  => '<span style="color:#fb8c00;">● Ожидает</span>',
);
$payment_labels = array( 'percent' => 'Процент', 'subscription' => 'Абонент' );
?>
<div class="wrap ts-wrap">
<h1>Водители <a href="?page=ts-drivers&action=add" class="page-title-action">+ Добавить</a></h1>
<?php if ($saved):   ?><div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div><?php endif; ?>
<?php if ($deleted): ?><div class="notice notice-success is-dismissible"><p>🗑️ Удалено.</p></div><?php endif; ?>

<table class="wp-list-table widefat fixed striped ts-table">
<thead>
  <tr>
    <th>ID</th><th>Имя</th><th>Позывной</th><th>Телефон</th>
    <th>Оплата</th><th>%&nbsp;/&nbsp;Абон.</th>
    <th>Статус</th><th>Telegram</th><th>Действия</th>
  </tr>
</thead>
<tbody>
<?php foreach ($drivers as $d):
  $ptype  = $d->payment_type ?? 'percent';
  $pval   = $ptype === 'percent'
            ? esc_html(number_format((float)($d->commission_pct??0),2)).'%'
            : 'BYN&nbsp;'.esc_html(number_format((float)($d->subscription_fee??0),2));
?>
<tr>
  <td><?php echo $d->id; ?></td>
  <td><strong><?php echo esc_html($d->name); ?></strong></td>
  <td><code><?php echo esc_html($d->callsign); ?></code></td>
  <td><?php echo esc_html($d->phone); ?></td>
  <td><?php echo esc_html($payment_labels[$ptype]??$ptype); ?></td>
  <td><?php echo $pval; ?></td>
  <td><?php echo $status_labels[$d->status] ?? esc_html($d->status); ?></td>
  <td><?php echo $d->telegram_chat_id ? '<code>'.esc_html($d->telegram_chat_id).'</code>' : '—'; ?></td>
  <td>
    <?php if ($d->status === 'pending'): ?>
      <button class="button button-small ts-approve-driver" data-id="<?php echo $d->id; ?>">✅ Одобрить</button>
    <?php endif; ?>
    <a href="?page=ts-drivers&action=edit&id=<?php echo $d->id; ?>" class="button button-small">Изменить</a>
    <button class="button button-small ts-delete" data-entity="driver" data-id="<?php echo $d->id; ?>">🗑</button>
  </td>
</tr>
<?php endforeach; ?>
<?php if(empty($drivers)): ?><tr><td colspan="9" style="text-align:center;color:#999;">Нет водителей</td></tr><?php endif; ?>
</tbody>
</table>
</div>
<?php endif; ?>
