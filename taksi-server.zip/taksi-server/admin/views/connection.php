<?php if ( ! defined( 'ABSPATH' ) ) exit;
$api_base   = rest_url( 'taksi-server/v1' );
$secret     = get_option( 'ts_driver_secret', 'taksi-server' );
$tcp_port   = get_option( 'ts_tcp_port', '4000' );
$company    = get_option( 'ts_company_name', 'Такси Сервер' );
?>
<div class="wrap ts-wrap">
<h1>🔗 Подключение и шорткоды</h1>

<div class="ts-info-box">
  <h3>🌐 REST API — базовый URL</h3>
  <code class="ts-code-block"><?php echo esc_html( $api_base ); ?></code>
  <button class="ts-copy-btn" data-copy="<?php echo esc_attr( $api_base ); ?>">Скопировать</button>
</div>

<div class="ts-info-box">
  <h3>📎 Шорткоды</h3>
  <table class="ts-table widefat">
    <thead><tr><th>Шорткод</th><th>Описание</th><th>Как использовать</th></tr></thead>
    <tbody>
      <tr>
        <td><code>[taksi_order_form]</code></td>
        <td>Форма заказа такси для клиентов</td>
        <td>Добавьте на любую страницу сайта, доступную клиентам</td>
      </tr>
      <tr>
        <td><code>[taksi_driver_app]</code></td>
        <td>Приложение водителя (вход + заказы + статус)</td>
        <td>Создайте страницу для водителей (можно скрыть из меню)</td>
      </tr>
      <tr>
        <td><code>[taksi_driver_register]</code></td>
        <td>Форма самостоятельной регистрации водителя</td>
        <td>Добавьте на страницу «Стать водителем»</td>
      </tr>
    </tbody>
  </table>
</div>

<div class="ts-info-box">
  <h3>📡 API — Водитель</h3>
  <p>Токен водителя = <code>md5(позывной + "<?php echo esc_html( $secret ); ?>")</code></p>
  <table class="ts-table widefat ts-table-sm">
    <thead><tr><th>Метод</th><th>URL</th><th>Параметры</th></tr></thead>
    <tbody>
      <tr><td>GET</td><td><code>/driver/orders?callsign=001&token=xxx</code></td><td>Получить активные заказы</td></tr>
      <tr><td>POST</td><td><code>/driver/order/accept</code></td><td>callsign, token, order_id</td></tr>
      <tr><td>POST</td><td><code>/driver/order/arrived</code></td><td>callsign, token, order_id</td></tr>
      <tr><td>POST</td><td><code>/driver/order/complete</code></td><td>callsign, token, order_id</td></tr>
      <tr><td>POST</td><td><code>/driver/order/cancel</code></td><td>callsign, token, order_id</td></tr>
      <tr><td>POST</td><td><code>/driver/status</code></td><td>callsign, token, status (free/busy/offline)</td></tr>
      <tr><td>POST</td><td><code>/driver/location</code></td><td>callsign, token, lat, lng</td></tr>
      <tr><td>POST</td><td><code>/driver/register</code></td><td>name, callsign, phone, license, telegram_chat_id</td></tr>
    </tbody>
  </table>
</div>

<div class="ts-info-box">
  <h3>📡 API — Клиент</h3>
  <table class="ts-table widefat ts-table-sm">
    <thead><tr><th>Метод</th><th>URL</th><th>Параметры</th></tr></thead>
    <tbody>
      <tr><td>POST</td><td><code>/client/order</code></td><td>phone, name, address_from, address_to, waypoints[], notes, tg_id</td></tr>
      <tr><td>GET</td><td><code>/client/order/{id}?phone=xxx</code></td><td>Статус заказа</td></tr>
    </tbody>
  </table>
</div>

<div class="ts-info-box">
  <h3>📍 Telegram — геопозиция водителей (webhook)</h3>
  <?php
  $tg_token   = get_option( 'ts_telegram_driver_bot_token', '' );
  $webhook_url = rest_url( 'taksi-server/v1/telegram/location' );
  $set_url     = $tg_token
    ? "https://api.telegram.org/bot{$tg_token}/setWebhook?url=" . urlencode( $webhook_url )
    : '';
  ?>
  <p>Когда водитель отправляет геопозицию боту (вручную или Live Location), координаты автоматически обновляются на карте диспетчера.</p>
  <table class="ts-table widefat ts-table-sm" style="margin-top:10px;">
    <tr>
      <th style="width:160px;">Webhook URL</th>
      <td>
        <code class="ts-code-block"><?php echo esc_html( $webhook_url ); ?></code>
        <button class="ts-copy-btn" data-copy="<?php echo esc_attr( $webhook_url ); ?>">Скопировать</button>
      </td>
    </tr>
    <tr>
      <th>Активировать webhook</th>
      <td>
        <?php if ( $tg_token ) : ?>
          <a href="<?php echo esc_url( $set_url ); ?>" target="_blank" class="button button-secondary">
            🔗 Установить webhook в Telegram
          </a>
          <p class="description" style="margin-top:6px;">Нажмите — откроется страница API Telegram. Если видите <code>"ok":true</code> — webhook установлен.</p>
        <?php else : ?>
          <span style="color:#e53935;">⚠️ Сначала укажите токен бота водителей в <a href="<?php echo admin_url('admin.php?page=ts-settings'); ?>">Настройках</a>.</span>
        <?php endif; ?>
      </td>
    </tr>
    <tr>
      <th>Инструкция для водителя</th>
      <td>
        <ol style="margin:6px 0 0 16px;padding:0;font-size:13px;">
          <li>Открыть чат с ботом водителей в Telegram</li>
          <li>Нажать скрепку (📎) → <b>Геопозиция</b></li>
          <li>Выбрать <b>Транслировать геопозицию</b> для Live Location (обновляется автоматически) <br>или <b>Отправить текущую геопозицию</b> разово</li>
        </ol>
      </td>
    </tr>
  </table>
</div>

<div class="ts-info-box">
  <h3>🖥 TCP-сервер для таксофонов (Такси Мастер)</h3>
  <p>Порт: <strong><?php echo esc_html( $tcp_port ); ?></strong></p>
  <p>Для запуска TCP-сервера (совместимость с таксофонами):</p>
  <code class="ts-code-block">php <?php echo esc_html( WP_PLUGIN_DIR . '/taksi-server/taxophone-server.php' ); ?></code>
  <p>Автозапуск через crontab:</p>
  <code class="ts-code-block">@reboot php <?php echo esc_html( WP_PLUGIN_DIR . '/taksi-server/taxophone-server.php' ); ?> >> /tmp/ts-tcp.log 2>&1 &</code>
</div>
</div>
