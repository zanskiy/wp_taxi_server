<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$stats       = TS_Orders::today_stats();
$cars        = TS_Cars::count_by_status();
$new_orders  = TS_Orders::get_all( array( 'status' => 'new', 'limit' => 10 ) );
$active_orders = TS_Orders::get_all( array( 'status' => array( 'in_progress', 'assigned', 'arrived' ), 'limit' => 10 ) );
$pending_drivers = TS_Drivers::get_all( array( 'status' => 'pending' ) );
?>
<div class="wrap ts-wrap">
<h1>🚖 Такси Сервер — Панель управления</h1>

<?php if ( $pending_drivers ) : ?>
<div class="notice notice-warning">
  <p>⚠️ <strong><?php echo count( $pending_drivers ); ?> новых заявок от водителей</strong> ожидают одобрения.
    <a href="<?php echo admin_url( 'admin.php?page=ts-drivers&status=pending' ); ?>">Просмотреть →</a></p>
</div>
<?php endif; ?>

<div class="ts-stats-grid">
  <div class="ts-stat-card ts-stat-blue">
    <div class="ts-stat-value"><?php echo (int) $stats->total; ?></div>
    <div class="ts-stat-label">Заказов сегодня</div>
  </div>
  <div class="ts-stat-card ts-stat-green">
    <div class="ts-stat-value"><?php echo (int) $stats->active; ?></div>
    <div class="ts-stat-label">Активных</div>
  </div>
  <div class="ts-stat-card ts-stat-teal">
    <div class="ts-stat-value"><?php echo (int) $stats->completed; ?></div>
    <div class="ts-stat-label">Выполнено</div>
  </div>
  <div class="ts-stat-card ts-stat-red">
    <div class="ts-stat-value"><?php echo (int) $stats->cancelled; ?></div>
    <div class="ts-stat-label">Отменено</div>
  </div>
  <div class="ts-stat-card ts-stat-money">
    <div class="ts-stat-value"><?php echo number_format( (float) $stats->revenue, 0, '.', ' ' ); ?> BYN</div>
    <div class="ts-stat-label">Выручка сегодня</div>
  </div>
</div>

<div class="ts-car-badges">
  <div class="ts-car-badge free"><span class="ts-car-dot free"></span><strong><?php echo $cars['free']; ?></strong> Свободных</div>
  <div class="ts-car-badge busy"><span class="ts-car-dot busy"></span><strong><?php echo $cars['busy']; ?></strong> Занятых</div>
  <div class="ts-car-badge offline"><span class="ts-car-dot offline"></span><strong><?php echo $cars['offline']; ?></strong> Офлайн</div>
  <a href="<?php echo admin_url( 'admin.php?page=ts-dispatcher' ); ?>" class="ts-btn ts-btn-primary" style="margin-left:auto;">
    🖥 Открыть панель диспетчера →
  </a>
</div>

<div class="ts-dash-grid">
  <div class="ts-dash-card">
    <div class="ts-dash-card-hdr">
      <h2>🆕 Новые заказы</h2>
      <a href="<?php echo admin_url( 'admin.php?page=ts-orders&status=new' ); ?>">Все →</a>
    </div>
    <?php if ( $new_orders ) : ?>
    <table class="ts-table widefat ts-table-sm">
      <thead><tr><th>№</th><th>Телефон</th><th>Откуда</th><th>Время</th></tr></thead>
      <tbody>
        <?php foreach ( $new_orders as $o ) : ?>
        <tr>
          <td><a href="<?php echo admin_url( 'admin.php?page=ts-orders&action=edit&id=' . $o->id ); ?>"><?php echo esc_html( $o->order_number ); ?></a></td>
          <td><?php echo esc_html( $o->client_phone ); ?></td>
          <td><?php echo esc_html( mb_strimwidth( $o->address_from, 0, 35, '…' ) ); ?></td>
          <td><?php echo esc_html( substr( $o->created_at, 11, 5 ) ); ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else : ?><p class="ts-empty">Нет новых заказов</p><?php endif; ?>
  </div>

  <div class="ts-dash-card">
    <div class="ts-dash-card-hdr">
      <h2>🏎 Активные поездки</h2>
      <a href="<?php echo admin_url( 'admin.php?page=ts-orders&status=in_progress' ); ?>">Все →</a>
    </div>
    <?php if ( $active_orders ) : ?>
    <table class="ts-table widefat ts-table-sm">
      <thead><tr><th>№</th><th>Водитель</th><th>Куда</th><th>Статус</th></tr></thead>
      <tbody>
        <?php $sl = array( 'assigned' => '🚗', 'in_progress' => '🏎', 'arrived' => '🅿' );
        foreach ( $active_orders as $o ) : ?>
        <tr>
          <td><?php echo esc_html( $o->order_number ); ?></td>
          <td><?php echo esc_html( $o->driver_name ?? '—' ); ?></td>
          <td><?php echo esc_html( mb_strimwidth( $o->address_to ?: 'Не указано', 0, 30, '…' ) ); ?></td>
          <td><?php echo esc_html( ( $sl[ $o->status ] ?? '' ) . ' ' . $o->status ); ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else : ?><p class="ts-empty">Нет активных поездок</p><?php endif; ?>
  </div>
</div>

<div class="ts-shortcodes-box">
  <h3>📎 Шорткоды для страниц сайта</h3>
  <div class="ts-sc-grid">
    <div class="ts-sc-item">
      <code>[taksi_order_form]</code>
      <span>Форма заказа такси для клиентов</span>
    </div>
    <div class="ts-sc-item">
      <code>[taksi_driver_app]</code>
      <span>Приложение водителя (вход + заказы)</span>
    </div>
    <div class="ts-sc-item">
      <code>[taksi_driver_register]</code>
      <span>Форма самостоятельной регистрации водителя</span>
    </div>
  </div>
</div>

</div>
