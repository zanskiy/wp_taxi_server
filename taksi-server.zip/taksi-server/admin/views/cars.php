<?php if ( ! defined( 'ABSPATH' ) ) exit;
$action  = sanitize_key( $_GET['action'] ?? 'list' );
$id      = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
$saved   = ! empty( $_GET['saved'] );
$item    = $id ? TS_Cars::get( $id ) : null;
$drivers = TS_Drivers::get_active();
$secret  = get_option( 'ts_driver_secret', 'taksi-server' );
?>
<div class="wrap ts-wrap">
<h1>🚗 Автомобили <a href="<?php echo admin_url( 'admin.php?page=ts-cars&action=new' ); ?>" class="page-title-action">+ Добавить</a></h1>
<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div><?php endif; ?>
<?php if ( $action === 'list' ) :
  $search   = sanitize_text_field( $_GET['s'] ?? '' );
  $status_f = sanitize_key( $_GET['status'] ?? '' );
  $items    = TS_Cars::get_all( array( 'search' => $search, 'status' => $status_f ) );
?>
<form method="get" class="ts-filter-form">
  <input type="hidden" name="page" value="ts-cars">
  <input type="text" name="s" placeholder="Поиск…" value="<?php echo esc_attr( $search ); ?>">
  <select name="status">
    <option value="">Все</option>
    <option value="free"    <?php selected( $status_f, 'free' );    ?>>Свободен</option>
    <option value="busy"    <?php selected( $status_f, 'busy' );    ?>>Занят</option>
    <option value="offline" <?php selected( $status_f, 'offline' ); ?>>Офлайн</option>
  </select>
  <button type="submit" class="button">Фильтр</button>
</form>
<table class="ts-table widefat">
<thead><tr><th>Позывной</th><th>Номер</th><th>Модель</th><th>Цвет</th><th>Водитель</th><th>Телефон</th><th>Статус</th><th>Токен подключения</th><th></th></tr></thead>
<tbody>
<?php if ( $items ) : foreach ( $items as $c ) :
  $token = md5( $c->callsign . $secret );
?>
<tr>
  <td><strong><?php echo esc_html( $c->callsign ); ?></strong></td>
  <td><?php echo esc_html( $c->plate ); ?></td>
  <td><?php echo esc_html( $c->model ); ?></td>
  <td><?php echo esc_html( $c->color ); ?></td>
  <td><?php echo esc_html( $c->driver_name ?? '—' ); ?></td>
  <td><?php echo esc_html( $c->phone ); ?></td>
  <td><span class="ts-badge ts-badge-<?php echo esc_attr( $c->status ); ?>"><?php echo array( 'free' => 'Свободен', 'busy' => 'Занят', 'offline' => 'Офлайн' )[ $c->status ] ?? $c->status; ?></span></td>
  <td>
    <span class="ts-token-short"><?php echo esc_html( substr( $token, 0, 10 ) . '…' ); ?></span>
    <button class="ts-copy-btn" data-copy="<?php echo esc_attr( $token ); ?>">Скопировать</button>
  </td>
  <td>
    <a href="<?php echo admin_url( 'admin.php?page=ts-cars&action=edit&id=' . $c->id ); ?>" class="button button-small">Ред.</a>
    <button class="button button-small ts-delete" data-entity="car" data-id="<?php echo esc_attr( $c->id ); ?>">Удалить</button>
  </td>
</tr>
<?php endforeach; else : ?>
  <tr><td colspan="9" class="ts-empty">Нет автомобилей. <a href="<?php echo admin_url( 'admin.php?page=ts-cars&action=new' ); ?>">Добавить →</a></td></tr>
<?php endif; ?>
</tbody>
</table>
<?php else : ?>
<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="car">
  <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
  <?php wp_nonce_field( 'ts_save' ); ?>
  <h2><?php echo $id ? 'Редактировать автомобиль' : 'Добавить автомобиль'; ?></h2>
  <table class="form-table">
    <tr><th>Позывной *</th><td><input type="text" name="callsign" required class="regular-text" value="<?php echo esc_attr( $item->callsign ?? '' ); ?>"></td></tr>
    <tr><th>Гос. номер *</th><td><input type="text" name="plate" required class="regular-text" value="<?php echo esc_attr( $item->plate ?? '' ); ?>"></td></tr>
    <tr><th>Модель</th><td><input type="text" name="model" class="regular-text" placeholder="Toyota Camry" value="<?php echo esc_attr( $item->model ?? '' ); ?>"></td></tr>
    <tr><th>Цвет</th><td><input type="text" name="color" class="regular-text" placeholder="Белый" value="<?php echo esc_attr( $item->color ?? '' ); ?>"></td></tr>
    <tr>
      <th>Водитель</th>
      <td>
        <select name="driver_id">
          <option value="">— не назначен —</option>
          <?php foreach ( $drivers as $d ) : ?>
          <option value="<?php echo esc_attr( $d->id ); ?>" <?php selected( $item->driver_id ?? '', $d->id ); ?>><?php echo esc_html( $d->name . ' (' . $d->callsign . ')' ); ?></option>
          <?php endforeach; ?>
        </select>
      </td>
    </tr>
    <tr>
      <th>Статус</th>
      <td>
        <select name="status">
          <option value="offline" <?php selected( $item->status ?? 'offline', 'offline' ); ?>>Офлайн</option>
          <option value="free"    <?php selected( $item->status ?? '', 'free' ); ?>>Свободен</option>
          <option value="busy"    <?php selected( $item->status ?? '', 'busy' ); ?>>Занят</option>
        </select>
      </td>
    </tr>
    <tr><th>Телефон машины</th><td><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr( $item->phone ?? '' ); ?>"></td></tr>
    <tr><th>Примечание</th><td><textarea name="notes" class="large-text" rows="3"><?php echo esc_textarea( $item->notes ?? '' ); ?></textarea></td></tr>
  </table>
  <p>
    <button type="submit" class="button button-primary">Сохранить</button>
    <a href="<?php echo admin_url( 'admin.php?page=ts-cars' ); ?>" class="button">Отмена</a>
  </p>
</form>
<?php endif; ?>
</div>
