<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="ts-client-form-wrap" style="max-width:520px;margin:0 auto;">
<style>
.ts-client-form-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
.ts-cf-card{background:#fff;border:1px solid #e0e0e0;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);}
.ts-cf-header{background:#1a1a2e;color:#fff;padding:20px 24px;}
.ts-cf-header h2{margin:0 0 4px;font-size:20px;}
.ts-cf-header p{margin:0;font-size:13px;opacity:.7;}
.ts-cf-body{padding:24px;}
.ts-cf-field{margin-bottom:16px;}
.ts-cf-label{display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;}
.ts-cf-input,.ts-cf-textarea{width:100%;padding:11px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;transition:border-color .15s;font-family:inherit;}
.ts-cf-input:focus,.ts-cf-textarea:focus{outline:none;border-color:#e63946;}
.ts-cf-textarea{resize:vertical;min-height:60px;}
.ts-cf-add-btn{background:none;border:1.5px dashed #ddd;color:#2196f3;padding:8px 14px;border-radius:8px;cursor:pointer;font-size:13px;margin-top:4px;}
.ts-cf-add-btn:hover{border-color:#2196f3;background:#e3f2fd;}
.ts-cf-wp-row{display:flex;gap:8px;align-items:center;margin-top:8px;}
.ts-cf-wp-remove{background:none;border:none;color:#999;font-size:18px;cursor:pointer;padding:0 4px;}
.ts-cf-submit{width:100%;padding:14px;background:#e63946;color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;margin-top:4px;}
.ts-cf-submit:disabled{opacity:.6;}
.ts-cf-msg{padding:14px;border-radius:10px;margin-top:14px;font-size:14px;}
.ts-cf-msg.ok{background:#e8f5e9;color:#2e7d32;border:1px solid #c8e6c9;}
.ts-cf-msg.err{background:#ffebee;color:#c62828;border:1px solid #ffcdd2;}
.ts-cf-success-num{font-size:22px;font-weight:800;color:#2e7d32;margin:4px 0;}
</style>
<div class="ts-cf-card">
  <div class="ts-cf-header">
    <h2>🚖 <?php echo esc_html( get_option( 'ts_company_name', 'Заказать такси' ) ); ?></h2>
    <p><?php echo esc_html( get_option( 'ts_company_phone', '' ) ); ?></p>
  </div>
  <div class="ts-cf-body">
    <div class="ts-cf-field">
      <label class="ts-cf-label">Телефон *</label>
      <input type="tel" class="ts-cf-input" id="cf-phone" placeholder="+7 000 000 00 00">
    </div>
    <div class="ts-cf-field">
      <label class="ts-cf-label">Ваше имя</label>
      <input type="text" class="ts-cf-input" id="cf-name" placeholder="Необязательно">
    </div>
    <div class="ts-cf-field">
      <label class="ts-cf-label">Откуда *</label>
      <input type="text" class="ts-cf-input" id="cf-from" placeholder="Адрес подачи">
    </div>
    <div id="cf-waypoints"></div>
    <button type="button" class="ts-cf-add-btn" id="cf-add-wp">+ Добавить остановку</button>
    <div class="ts-cf-field" style="margin-top:12px;">
      <label class="ts-cf-label">Куда</label>
      <input type="text" class="ts-cf-input" id="cf-to" placeholder="Адрес назначения">
    </div>
    <div class="ts-cf-field">
      <label class="ts-cf-label">Примечание водителю</label>
      <textarea class="ts-cf-textarea" id="cf-notes" placeholder="Любые пожелания…"></textarea>
    </div>
    <button type="button" class="ts-cf-submit" id="cf-submit">🚕 Вызвать такси</button>
    <div id="cf-msg" style="display:none;"></div>
  </div>
</div>
</div>

<script>
(function(){
  var apiBase = '<?php echo esc_js( rest_url( 'taksi-server/v1' ) ); ?>';
  var nonce   = '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>';
  var wpCount = 0;

  document.getElementById('cf-add-wp').onclick = function(){
    wpCount++;
    var wrap = document.getElementById('cf-waypoints');
    var row  = document.createElement('div');
    row.className='ts-cf-wp-row'; row.id='cf-wp-'+wpCount;
    row.innerHTML='<input type="text" class="ts-cf-input ts-cf-wp-inp" placeholder="Промежуточная точка '+(wpCount)+'" style="flex:1;">'
      +'<button type="button" class="ts-cf-wp-remove" onclick="document.getElementById(\'cf-wp-'+wpCount+'\').remove()">✕</button>';
    wrap.appendChild(row);
  };

  document.getElementById('cf-submit').onclick = function(){
    var phone = document.getElementById('cf-phone').value.trim();
    var from  = document.getElementById('cf-from').value.trim();
    if(!phone||!from){ showMsg('❌ Укажите телефон и адрес подачи','err'); return; }

    var waypoints = [];
    document.querySelectorAll('.ts-cf-wp-inp').forEach(function(inp){ var v=inp.value.trim(); if(v) waypoints.push(v); });

    var btn = this;
    btn.disabled=true; btn.textContent='Отправляем…';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', apiBase+'/client/order');
    xhr.setRequestHeader('Content-Type','application/json');
    xhr.setRequestHeader('X-WP-Nonce', nonce);
    xhr.onload = function(){
      btn.disabled=false; btn.textContent='🚕 Вызвать такси';
      var res = JSON.parse(xhr.responseText);
      if(res.ok){
        showMsg('<div>✅ Заказ принят!</div><div class="ts-cf-success-num">№ '+res.order_number+'</div><div>Диспетчер свяжется с вами в ближайшее время.</div>','ok');
        document.getElementById('cf-phone').value='';
        document.getElementById('cf-name').value='';
        document.getElementById('cf-from').value='';
        document.getElementById('cf-to').value='';
        document.getElementById('cf-notes').value='';
        document.getElementById('cf-waypoints').innerHTML='';
        wpCount=0;
      } else {
        showMsg('❌ Ошибка: '+(res.message||'Попробуйте ещё раз'),'err');
      }
    };
    xhr.send(JSON.stringify({phone:phone,name:document.getElementById('cf-name').value,address_from:from,address_to:document.getElementById('cf-to').value,notes:document.getElementById('cf-notes').value,waypoints:waypoints}));
  };

  function showMsg(text,type){
    var el=document.getElementById('cf-msg');
    el.style.display=''; el.className='ts-cf-msg '+type; el.innerHTML=text;
  }
})();
</script>
