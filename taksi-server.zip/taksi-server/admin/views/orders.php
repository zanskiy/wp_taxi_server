<?php if ( ! defined( 'ABSPATH' ) ) exit;
$action   = sanitize_key( $_GET['action'] ?? 'list' );
$id       = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
$saved    = ! empty( $_GET['saved'] );
$item     = $id ? TS_Orders::get( $id ) : null;
$cars     = TS_Cars::get_all();
$drivers  = TS_Drivers::get_active();
$dispatchers = TS_Dispatchers::get_all();
$phones   = TS_Phones::get_active();
$status_labels = array( 'new' => 'Новый', 'assigned' => 'Назначен', 'in_progress' => 'В пути', 'arrived' => 'Прибыл', 'completed' => 'Выполнен', 'cancelled' => 'Отменён' );
?>
<div class="wrap ts-wrap">
<h1>📋 Заказы
  <a href="<?php echo admin_url( 'admin.php?page=ts-orders&action=new' ); ?>" class="page-title-action">+ Добавить</a>
</h1>
<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div><?php endif; ?>

<?php if ( $action === 'list' ) :
  $search   = sanitize_text_field( $_GET['s'] ?? '' );
  $status_f = sanitize_key( $_GET['status'] ?? '' );
  $date_from = sanitize_text_field( $_GET['date_from'] ?? '' );
  $date_to   = sanitize_text_field( $_GET['date_to']   ?? '' );
  $items = TS_Orders::get_all( array( 'search' => $search, 'status' => $status_f, 'date_from' => $date_from, 'date_to' => $date_to, 'limit' => 200 ) );
?>
<form method="get" class="ts-filter-form">
  <input type="hidden" name="page" value="ts-orders">
  <input type="text" name="s" placeholder="Поиск по номеру, телефону, адресу…" value="<?php echo esc_attr( $search ); ?>" style="width:260px;">
  <select name="status">
    <option value="">Все статусы</option>
    <?php foreach ( $status_labels as $v => $l ) : ?>
    <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $status_f, $v ); ?>><?php echo esc_html( $l ); ?></option>
    <?php endforeach; ?>
  </select>
  <input type="date" name="date_from" value="<?php echo esc_attr( $date_from ); ?>" title="С">
  <input type="date" name="date_to" value="<?php echo esc_attr( $date_to ); ?>" title="По">
  <button type="submit" class="button">Фильтр</button>
</form>

<table class="ts-table widefat">
<thead>
  <tr><th>№</th><th>Дата</th><th>Клиент</th><th>Откуда</th><th>Куда</th><th>Водитель</th><th>Машина</th><th>Статус</th><th>Цена</th><th></th></tr>
</thead>
<tbody>
<?php if ( $items ) : foreach ( $items as $o ) : ?>
<tr class="<?php echo $o->status === 'completed' ? 'ts-row-ok' : ( $o->status === 'cancelled' ? 'ts-row-cancel' : '' ); ?>">
  <td><strong><?php echo esc_html( $o->order_number ); ?></strong></td>
  <td><?php echo esc_html( substr( $o->created_at, 0, 16 ) ); ?></td>
  <td>
    <?php echo esc_html( $o->client_name ?: '—' ); ?>
    <?php if ( $o->client_phone ) : ?><br><small><?php echo esc_html( $o->client_phone ); ?></small><?php endif; ?>
  </td>
  <td><?php echo esc_html( mb_strimwidth( $o->address_from, 0, 35, '…' ) ); ?></td>
  <td><?php echo esc_html( mb_strimwidth( $o->address_to ?: '—', 0, 30, '…' ) ); ?></td>
  <td><?php echo esc_html( $o->driver_name ?? '—' ); ?></td>
  <td><?php echo esc_html( $o->car_callsign ?? '—' ); ?></td>
  <td><span class="ts-badge ts-badge-<?php echo esc_attr( $o->status ); ?>"><?php echo esc_html( $status_labels[ $o->status ] ?? $o->status ); ?></span></td>
  <td><?php echo $o->price ? number_format( (float) $o->price, 0, '.', ' ' ) . ' BYN' : '—'; ?></td>
  <td>
    <a href="<?php echo admin_url( 'admin.php?page=ts-orders&action=edit&id=' . $o->id ); ?>" class="button button-small">Ред.</a>
    <button class="button button-small ts-delete" data-entity="order" data-id="<?php echo esc_attr( $o->id ); ?>">Удалить</button>
  </td>
</tr>
<?php endforeach; else : ?>
  <tr><td colspan="10" class="ts-empty">Нет заказов</td></tr>
<?php endif; ?>
</tbody>
</table>

<?php else : /* ADD / EDIT */ ?>
<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="order">
  <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
  <?php wp_nonce_field( 'ts_save' ); ?>

  <h2><?php echo $id ? 'Редактировать заказ' : 'Добавить заказ'; ?></h2>
  <div class="ts-form-grid">
    <div>
      <table class="form-table">
        <tr><th>Телефон клиента *</th><td><input type="text" name="client_phone" required class="regular-text" value="<?php echo esc_attr( $item->client_phone ?? '' ); ?>"></td></tr>
        <tr><th>Имя клиента</th><td><input type="text" name="client_name" class="regular-text" value="<?php echo esc_attr( $item->client_name ?? '' ); ?>"></td></tr>
        <tr><th>Telegram Chat ID клиента</th><td><input type="text" name="client_tg_id" class="regular-text" placeholder="Для уведомлений" value="<?php echo esc_attr( $item->client_tg_id ?? '' ); ?>"></td></tr>
        <tr>
          <th>Откуда *</th>
          <td><textarea name="address_from" required class="large-text" rows="2"><?php echo esc_textarea( $item->address_from ?? '' ); ?></textarea></td>
        </tr>
        <tr>
          <th>Промежуточные точки</th>
          <td>
            <div id="admin-waypoints">
              <?php
              $existing_wps = array();
              if ( $item && ! empty( $item->waypoints ) ) {
                  $existing_wps = json_decode( $item->waypoints, true ) ?: array();
              }
              foreach ( $existing_wps as $i => $wp ) : ?>
              <div class="ts-wp-row" data-wp="<?php echo $i; ?>">
                <input type="text" name="waypoints[]" class="regular-text" value="<?php echo esc_attr( $wp ); ?>">
                <button type="button" class="button button-small ts-wp-remove-admin">✕</button>
              </div>
              <?php endforeach; ?>
            </div>
            <button type="button" class="button button-small" id="admin-add-wp" style="margin-top:6px;">+ Добавить остановку</button>
          </td>
        </tr>
        <tr>
          <th>Куда</th>
          <td><textarea name="address_to" class="large-text" rows="2"><?php echo esc_textarea( $item->address_to ?? '' ); ?></textarea></td>
        </tr>
      </table>
    </div>
    <div>
      <table class="form-table">
        <tr>
          <th>Статус</th>
          <td>
            <select name="status">
              <?php foreach ( $status_labels as $v => $l ) : ?>
              <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $item->status ?? 'new', $v ); ?>><?php echo esc_html( $l ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th>Машина</th>
          <td>
            <select name="car_id">
              <option value="">— не назначена —</option>
              <?php foreach ( $cars as $c ) : ?>
              <option value="<?php echo esc_attr( $c->id ); ?>" <?php selected( $item->car_id ?? '', $c->id ); ?>>
                <?php echo esc_html( $c->callsign . ' · ' . $c->model . ' · ' . $c->plate ); ?>
              </option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th>Водитель</th>
          <td>
            <select name="driver_id">
              <option value="">— не назначен —</option>
              <?php foreach ( $drivers as $d ) : ?>
              <option value="<?php echo esc_attr( $d->id ); ?>" <?php selected( $item->driver_id ?? '', $d->id ); ?>><?php echo esc_html( $d->name . ' (' . $d->callsign . ')' ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th>Диспетчер</th>
          <td>
            <select name="dispatcher_id">
              <option value="">— нет —</option>
              <?php foreach ( $dispatchers as $d ) : ?>
              <option value="<?php echo esc_attr( $d->id ); ?>" <?php selected( $item->dispatcher_id ?? '', $d->id ); ?>><?php echo esc_html( $d->name ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th>Телефонная линия</th>
          <td>
            <select name="phone_line_id">
              <option value="">— нет —</option>
              <?php foreach ( $phones as $p ) : ?>
              <option value="<?php echo esc_attr( $p->id ); ?>" <?php selected( $item->phone_line_id ?? '', $p->id ); ?>><?php echo esc_html( $p->number . ' ' . $p->description ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr><th>Цена (BYN)</th><td><input type="number" name="price" class="small-text" step="10" min="0" value="<?php echo esc_attr( $item->price ?? '' ); ?>"></td></tr>
        <tr><th>Расстояние (км)</th><td><input type="number" name="distance_km" class="small-text" step="0.1" min="0" value="<?php echo esc_attr( $item->distance_km ?? '' ); ?>"></td></tr>
        <tr><th>Примечание</th><td><textarea name="notes" class="large-text" rows="3"><?php echo esc_textarea( $item->notes ?? '' ); ?></textarea></td></tr>
      </table>
    </div>
  </div>
  <p>
    <button type="submit" class="button button-primary">Сохранить</button>
    <a href="<?php echo admin_url( 'admin.php?page=ts-orders' ); ?>" class="button">Отмена</a>
  </p>
</form>
<script>
jQuery(function($){
  var wpCount = <?php echo count( $existing_wps ); ?>;
  $('#admin-add-wp').on('click',function(){
    wpCount++;
    $('#admin-waypoints').append(
      '<div class="ts-wp-row" data-wp="'+wpCount+'">'
      +'<input type="text" name="waypoints[]" class="regular-text" placeholder="Промежуточная точка">'
      +' <button type="button" class="button button-small ts-wp-remove-admin">✕</button>'
      +'</div>'
    );
  });
  $(document).on('click','.ts-wp-remove-admin',function(){ $(this).closest('.ts-wp-row').remove(); });
});
</script>
<?php endif; ?>
</div>
