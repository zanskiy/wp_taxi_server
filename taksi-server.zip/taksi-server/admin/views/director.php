<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$today      = current_time( 'Y-m-d' );
$week_from  = date( 'Y-m-d', strtotime( '-6 days', current_time( 'timestamp' ) ) );
$month_from = date( 'Y-m-01', current_time( 'timestamp' ) );

$today_stats = TS_Orders::today_stats();
$week_sum    = TS_Reports::summary( $week_from, $today );
$month_sum   = TS_Reports::summary( $month_from, $today );
$cars        = TS_Cars::count_by_status();
$top_drivers = TS_Reports::top_drivers( $month_from, $today, 10 );
$rev_days    = TS_Reports::revenue_by_day( $week_from, $today );
$hourly      = TS_Reports::hourly_distribution( $month_from, $today );
$company     = get_option( 'ts_company_name', 'Такси Сервер' );

$rev_labels = array(); $rev_data = array(); $rev_completed = array();
foreach ( $rev_days as $r ) {
    $rev_labels[]    = date( 'd.m', strtotime( $r->day ) );
    $rev_data[]      = (float) $r->revenue;
    $rev_completed[] = (int) $r->completed;
}
?>
<div class="wrap ts-wrap">
<div class="ts-dir-header">
  <h1>📊 Директор — <?php echo esc_html( $company ); ?></h1>
  <span class="ts-dir-date"><?php echo date_i18n( 'j F Y', current_time( 'timestamp' ) ); ?></span>
</div>

<!-- Fleet status -->
<div class="ts-fleet-row">
  <div class="ts-fleet-card ts-fleet-free">
    <div class="ts-fleet-dot"></div>
    <div class="ts-fleet-num"><?php echo $cars['free']; ?></div>
    <div class="ts-fleet-lbl">Свободных</div>
  </div>
  <div class="ts-fleet-card ts-fleet-busy">
    <div class="ts-fleet-dot"></div>
    <div class="ts-fleet-num"><?php echo $cars['busy']; ?></div>
    <div class="ts-fleet-lbl">В работе</div>
  </div>
  <div class="ts-fleet-card ts-fleet-offline">
    <div class="ts-fleet-dot"></div>
    <div class="ts-fleet-num"><?php echo $cars['offline']; ?></div>
    <div class="ts-fleet-lbl">Офлайн</div>
  </div>
  <div class="ts-fleet-total">
    <div class="ts-fleet-num"><?php echo array_sum( $cars ); ?></div>
    <div class="ts-fleet-lbl">Всего машин</div>
  </div>
</div>

<!-- KPI tabs -->
<div class="ts-dir-kpi-tabs">
  <button class="ts-kpi-tab ts-kpi-tab-active" data-period="today">Сегодня</button>
  <button class="ts-kpi-tab" data-period="week">7 дней</button>
  <button class="ts-kpi-tab" data-period="month">Месяц</button>
</div>

<?php
$periods = array(
    'today' => array( 'label' => 'Сегодня', 'data' => $today_stats ),
    'week'  => array( 'label' => '7 дней',  'data' => $week_sum ),
    'month' => array( 'label' => 'Месяц',   'data' => $month_sum ),
);
foreach ( $periods as $period_key => $period ) :
    $s = $period['data'];
    $total = max( 1, (int) ( $s->total ?? 0 ) );
    $done  = (int) ( $s->completed ?? 0 );
    $rate  = round( $done / $total * 100 );
?>
<div class="ts-dir-kpis" id="kpi-<?php echo esc_attr( $period_key ); ?>" <?php echo $period_key !== 'today' ? 'style="display:none;"' : ''; ?>>
  <div class="ts-dkpi ts-dkpi-revenue">
    <div class="ts-dkpi-label">Выручка</div>
    <div class="ts-dkpi-value"><?php echo number_format( (float)($s->revenue??0), 0, '.', ' ' ); ?> <span>BYN</span></div>
    <div class="ts-dkpi-sub">Ср. чек: <?php echo number_format( (float)($s->avg_price??0), 0, '.', ' ' ); ?> BYN</div>
  </div>
  <div class="ts-dkpi ts-dkpi-total">
    <div class="ts-dkpi-label">Заказов</div>
    <div class="ts-dkpi-value"><?php echo (int)($s->total??0); ?></div>
    <div class="ts-dkpi-sub">Активных: <?php echo (int)($s->active??0); ?></div>
  </div>
  <div class="ts-dkpi ts-dkpi-done">
    <div class="ts-dkpi-label">Выполнено</div>
    <div class="ts-dkpi-value"><?php echo $done; ?></div>
    <div class="ts-dkpi-sub">Конверсия <?php echo $rate; ?>%</div>
    <div class="ts-dkpi-bar"><div class="ts-dkpi-bar-fill" style="width:<?php echo $rate; ?>%;background:#4caf50;"></div></div>
  </div>
  <div class="ts-dkpi ts-dkpi-cancel">
    <div class="ts-dkpi-label">Отменено</div>
    <div class="ts-dkpi-value"><?php echo (int)($s->cancelled??0); ?></div>
  </div>
  <?php if ( ! empty( $s->avg_km ) ) : ?>
  <div class="ts-dkpi ts-dkpi-km">
    <div class="ts-dkpi-label">Ср. км</div>
    <div class="ts-dkpi-value"><?php echo number_format( (float)$s->avg_km, 1 ); ?> <span>км</span></div>
  </div>
  <?php endif; ?>
</div>
<?php endforeach; ?>

<!-- Charts -->
<div class="ts-dir-charts">
  <div class="ts-dir-chart-card">
    <div class="ts-dir-chart-title">Выручка по дням (7 дней)</div>
    <canvas id="ts-revenue-chart" height="120"></canvas>
  </div>
  <div class="ts-dir-chart-card">
    <div class="ts-dir-chart-title">Заказы по часам (текущий месяц)</div>
    <canvas id="ts-hourly-chart" height="120"></canvas>
  </div>
</div>

<!-- Top drivers -->
<div class="ts-dir-section">
  <div class="ts-dir-section-hdr">
    <h2>🏆 Топ водителей (месяц)</h2>
    <a href="<?php echo admin_url( 'admin.php?page=ts-reports' ); ?>">Подробные отчёты →</a>
  </div>
  <?php if ( $top_drivers ) : ?>
  <div class="ts-dir-top-grid">
    <?php $medals = array( '🥇', '🥈', '🥉' );
    $max_rev = max( array_column( (array) $top_drivers, 'revenue' ) ) ?: 1;
    foreach ( $top_drivers as $i => $d ) :
      $rank = $i + 1;
      $pct  = round( $d->revenue / $max_rev * 100 );
    ?>
    <div class="ts-drv-top-card <?php echo $rank <= 3 ? 'ts-drv-medal' : ''; ?>">
      <div class="ts-dtc-rank"><?php echo isset( $medals[ $i ] ) ? $medals[ $i ] : '#' . $rank; ?></div>
      <div class="ts-dtc-body">
        <div class="ts-dtc-name"><?php echo esc_html( $d->name ); ?></div>
        <div class="ts-dtc-bar"><div class="ts-dtc-bar-fill" style="width:<?php echo $pct; ?>%;"></div></div>
        <div class="ts-dtc-stats">
          <span><?php echo (int)$d->trips; ?> поездок</span>
          <span><?php echo number_format( (float)$d->revenue, 0, '.', ' ' ); ?> BYN</span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else : ?>
  <p class="ts-empty">Нет данных за текущий месяц.</p>
  <?php endif; ?>
</div>

<!-- Car map placeholder -->
<div class="ts-dir-section" style="margin-top:14px;">
  <div class="ts-dir-section-hdr">
    <h2>🗺 Карта — расположение водителей</h2>
  </div>
  <div id="ts-cars-map-table">
    <?php $active_cars = TS_Cars::get_with_location(); ?>
    <?php if ( $active_cars ) : ?>
    <table class="ts-table widefat">
      <thead><tr><th>Позывной</th><th>Водитель</th><th>Модель</th><th>Статус</th><th>Координаты</th><th>Последний сигнал</th></tr></thead>
      <tbody>
      <?php foreach ( $active_cars as $c ) : ?>
        <tr>
          <td><strong><?php echo esc_html( $c->callsign ); ?></strong></td>
          <td><?php echo esc_html( $c->driver_name ?? '—' ); ?></td>
          <td><?php echo esc_html( $c->model ); ?></td>
          <td><span class="ts-badge ts-badge-<?php echo esc_attr( $c->status ); ?>"><?php echo array( 'free' => 'Свободен', 'busy' => 'Занят', 'offline' => 'Офлайн' )[ $c->status ] ?? $c->status; ?></span></td>
          <td><?php echo $c->lat ? esc_html( $c->lat . ', ' . $c->lng ) : '—'; ?></td>
          <td><?php echo $c->last_seen ? esc_html( $c->last_seen ) : '—'; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php else : ?>
    <p class="ts-empty">Нет активных машин. Водители отправляют координаты через мобильное приложение.</p>
    <?php endif; ?>
  </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function(){
  // KPI tabs
  document.querySelectorAll('.ts-kpi-tab').forEach(function(btn){
    btn.addEventListener('click',function(){
      document.querySelectorAll('.ts-kpi-tab').forEach(function(b){ b.classList.remove('ts-kpi-tab-active'); });
      this.classList.add('ts-kpi-tab-active');
      var period = this.dataset.period;
      ['today','week','month'].forEach(function(p){
        document.getElementById('kpi-'+p).style.display = p===period ? '' : 'none';
      });
    });
  });

  var revLabels    = <?php echo wp_json_encode( $rev_labels ); ?>;
  var revData      = <?php echo wp_json_encode( $rev_data ); ?>;
  var revCompleted = <?php echo wp_json_encode( $rev_completed ); ?>;
  var hourlyData   = <?php echo wp_json_encode( array_values( $hourly ) ); ?>;
  var hourlyLabels = Array.from({length:24},function(_,i){ return i+':00'; });

  new Chart(document.getElementById('ts-revenue-chart'), {
    type:'bar',
    data:{
      labels: revLabels,
      datasets:[
        { label:'Выручка BYN', data:revData, backgroundColor:'rgba(230,57,70,.75)', borderRadius:6, yAxisID:'y' },
        { label:'Поездок',   data:revCompleted, type:'line', borderColor:'#2196f3', backgroundColor:'transparent', pointRadius:4, tension:.3, yAxisID:'y2' }
      ]
    },
    options:{ responsive:true, interaction:{mode:'index',intersect:false},
      scales:{
        y:{ beginAtZero:true, position:'left', ticks:{callback:function(v){ return v.toLocaleString('ru')+'BYN'; }} },
        y2:{ beginAtZero:true, position:'right', grid:{drawOnChartArea:false} }
      }
    }
  });

  new Chart(document.getElementById('ts-hourly-chart'), {
    type:'bar',
    data:{
      labels: hourlyLabels,
      datasets:[{ label:'Заказов', data:hourlyData, backgroundColor:'rgba(33,150,243,.7)', borderRadius:4 }]
    },
    options:{ responsive:true, scales:{ y:{ beginAtZero:true } } }
  });
})();
</script>
