<?php if ( ! defined( 'ABSPATH' ) ) exit;
$action = sanitize_key( $_GET['action'] ?? 'list' );
$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
$saved  = ! empty( $_GET['saved'] );
$item   = $id ? TS_Dispatchers::get( $id ) : null;

// Показать одноразовый пароль после создания WP-аккаунта
$new_creds = get_transient( 'ts_disp_new_creds_' . get_current_user_id() );
if ( $new_creds ) delete_transient( 'ts_disp_new_creds_' . get_current_user_id() );
?>
<div class="wrap ts-wrap">
<h1>👩‍💼 Диспетчеры <a href="<?php echo admin_url( 'admin.php?page=ts-dispatchers&action=new' ); ?>" class="page-title-action">+ Добавить</a></h1>

<?php if ( $saved ) : ?>
  <div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div>
<?php endif; ?>

<?php if ( $new_creds ) : ?>
  <div class="notice notice-warning" style="padding:16px;">
    <h3 style="margin:0 0 8px;">🔑 Аккаунт WordPress создан — сохраните данные!</h3>
    <p style="margin:4px 0;">Это сообщение показывается <strong>только один раз</strong>.</p>
    <table style="border-collapse:collapse;margin-top:8px;">
      <tr><td style="padding:4px 12px 4px 0;font-weight:600;">Сайт:</td><td><?php echo esc_html( home_url( '/wp-login.php' ) ); ?></td></tr>
      <tr><td style="padding:4px 12px 4px 0;font-weight:600;">Логин:</td><td><code><?php echo esc_html( $new_creds['login'] ); ?></code></td></tr>
      <tr><td style="padding:4px 12px 4px 0;font-weight:600;">Пароль:</td><td><code style="background:#fff3cd;padding:2px 8px;border-radius:4px;font-size:15px;"><?php echo esc_html( $new_creds['password'] ); ?></code></td></tr>
      <tr><td style="padding:4px 12px 4px 0;font-weight:600;">Доступ:</td>
          <td><a href="<?php echo esc_url( home_url( '/?page_id=' . get_option( 'ts_dispatcher_page_id', '' ) ) ); ?>" target="_blank">Панель диспетчера</a></td></tr>
    </table>
    <p style="margin-top:10px;">
      <button type="button" class="button ts-copy-btn"
        data-copy="Логин: <?php echo esc_attr( $new_creds['login'] ); ?>&#10;Пароль: <?php echo esc_attr( $new_creds['password'] ); ?>&#10;Сайт: <?php echo esc_attr( home_url( '/wp-login.php' ) ); ?>">
        📋 Скопировать данные
      </button>
    </p>
  </div>
<?php endif; ?>

<?php if ( $action === 'list' ) :
  $items = TS_Dispatchers::get_all( array( 'search' => sanitize_text_field( $_GET['s'] ?? '' ) ) );
?>
<table class="ts-table widefat">
<thead>
  <tr>
    <th>ФИО</th>
    <th>Логин</th>
    <th>Телефон</th>
    <th>Статус</th>
    <th>WP-аккаунт</th>
    <th></th>
  </tr>
</thead>
<tbody>
<?php if ( $items ) : foreach ( $items as $d ) : ?>
<tr>
  <td><strong><?php echo esc_html( $d->name ); ?></strong></td>
  <td><?php echo esc_html( $d->login ); ?></td>
  <td><?php echo esc_html( $d->phone ); ?></td>
  <td><span class="ts-badge ts-badge-<?php echo esc_attr( $d->status ); ?>"><?php echo $d->status === 'active' ? 'Активен' : 'Не активен'; ?></span></td>
  <td>
    <?php if ( ! empty( $d->wp_user_id ) ) :
      $wp_user = get_user_by( 'id', (int) $d->wp_user_id );
    ?>
      <?php if ( $wp_user ) : ?>
        <span class="ts-badge ts-badge-active">✅ <?php echo esc_html( $wp_user->user_login ); ?></span>
        <button class="button button-small ts-disp-revoke"
                data-id="<?php echo esc_attr( $d->id ); ?>"
                data-nonce="<?php echo wp_create_nonce( 'ts_nonce' ); ?>"
                title="Отозвать доступ к сайту (роль снимается, аккаунт остаётся)">
          🚫 Отозвать
        </button>
      <?php else : ?>
        <span style="color:#999;">Аккаунт удалён</span>
      <?php endif; ?>
    <?php else : ?>
      <span style="color:#aaa;">Нет</span>
      <button class="button button-small button-primary ts-disp-create-wp"
              data-id="<?php echo esc_attr( $d->id ); ?>"
              data-name="<?php echo esc_attr( $d->name ); ?>"
              data-nonce="<?php echo wp_create_nonce( 'ts_nonce' ); ?>">
        ➕ Создать аккаунт
      </button>
    <?php endif; ?>
  </td>
  <td style="white-space:nowrap;">
    <a href="<?php echo admin_url( 'admin.php?page=ts-dispatchers&action=edit&id=' . $d->id ); ?>" class="button button-small">Ред.</a>
    <button class="button button-small ts-delete" data-entity="dispatcher" data-id="<?php echo esc_attr( $d->id ); ?>">Удалить</button>
  </td>
</tr>
<?php endforeach; else : ?>
  <tr><td colspan="6" class="ts-empty">Нет диспетчеров. <a href="<?php echo admin_url( 'admin.php?page=ts-dispatchers&action=new' ); ?>">Добавить первого</a></td></tr>
<?php endif; ?>
</tbody>
</table>

<script>
(function($){
  // Создать WP-аккаунт
  $(document).on('click', '.ts-disp-create-wp', function(){
    var btn    = $(this);
    var id     = btn.data('id');
    var name   = btn.data('name');
    var nonce  = btn.data('nonce');

    var email = prompt('Email для аккаунта диспетчера «' + name + '»\n(можно оставить пустым — будет сгенерирован автоматически):', '');
    if (email === null) return; // отмена

    btn.prop('disabled', true).text('Создаём…');
    $.post('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>', {
      action:        'ts_action',
      ts_action:     'create_dispatcher_wp',
      dispatcher_id: id,
      email:         email,
      nonce:         nonce,
    }, function(res){
      if (res && res.success) {
        location.reload();
      } else {
        alert('Ошибка: ' + (res && res.data ? res.data : 'нет ответа'));
        btn.prop('disabled', false).text('➕ Создать аккаунт');
      }
    }).fail(function(){ btn.prop('disabled',false).text('➕ Создать аккаунт'); alert('Ошибка соединения'); });
  });

  // Отозвать доступ
  $(document).on('click', '.ts-disp-revoke', function(){
    if (!confirm('Отозвать WordPress-доступ? Аккаунт останется, но диспетчер больше не сможет войти в панель.')) return;
    var btn   = $(this);
    var id    = btn.data('id');
    var nonce = btn.data('nonce');
    btn.prop('disabled', true).text('Отзываем…');
    $.post('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>', {
      action:        'ts_action',
      ts_action:     'revoke_dispatcher_wp',
      dispatcher_id: id,
      nonce:         nonce,
    }, function(res){
      if (res && res.success) {
        location.reload();
      } else {
        alert('Ошибка: ' + (res && res.data ? res.data : 'нет ответа'));
        btn.prop('disabled', false).text('🚫 Отозвать');
      }
    }).fail(function(){ btn.prop('disabled',false).text('🚫 Отозвать'); alert('Ошибка соединения'); });
  });
})(jQuery);
</script>

<?php else : /* форма добавления / редактирования */ ?>

<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="dispatcher">
  <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
  <?php wp_nonce_field( 'ts_save' ); ?>

  <h2><?php echo $id ? 'Редактировать диспетчера' : 'Добавить диспетчера'; ?></h2>

  <table class="form-table">
    <tr>
      <th>ФИО *</th>
      <td><input type="text" name="name" required class="regular-text" value="<?php echo esc_attr( $item->name ?? '' ); ?>"></td>
    </tr>
    <tr>
      <th>Логин *</th>
      <td>
        <input type="text" name="login" required class="regular-text" value="<?php echo esc_attr( $item->login ?? '' ); ?>">
        <p class="description">Используется как логин WordPress-аккаунта (латинские буквы, цифры, подчёркивание)</p>
      </td>
    </tr>
    <tr>
      <th>Email</th>
      <td>
        <input type="email" name="email" class="regular-text" value="<?php echo esc_attr( $item->email ?? '' ); ?>">
        <p class="description">Нужен для WP-аккаунта. Если не указан — будет сгенерирован автоматически.</p>
      </td>
    </tr>
    <tr>
      <th>Телефон</th>
      <td><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr( $item->phone ?? '' ); ?>"></td>
    </tr>
    <tr>
      <th>Статус</th>
      <td>
        <select name="status">
          <option value="active"   <?php selected( $item->status ?? 'active', 'active' );   ?>>Активен</option>
          <option value="inactive" <?php selected( $item->status ?? '', 'inactive' ); ?>>Не активен</option>
        </select>
      </td>
    </tr>
    <tr>
      <th>Примечание</th>
      <td><textarea name="notes" class="large-text" rows="3"><?php echo esc_textarea( $item->notes ?? '' ); ?></textarea></td>
    </tr>

    <?php if ( ! $id ) : /* только при создании */ ?>
    <tr>
      <th>WordPress-аккаунт</th>
      <td>
        <label>
          <input type="checkbox" name="create_wp_user" value="1" checked>
          <strong>Создать WordPress-аккаунт автоматически</strong>
        </label>
        <p class="description">После сохранения будет создан WP-пользователь с ролью «Диспетчер такси».<br>
          Логин и пароль отобразятся один раз — сохраните их.</p>
        <div style="margin-top:8px;">
          <label style="display:block;margin-bottom:4px;">Пароль (необязательно, сгенерируется автоматически)</label>
          <input type="password" name="wp_password" class="regular-text" autocomplete="new-password" placeholder="Оставьте пустым для автогенерации">
        </div>
      </td>
    </tr>
    <?php elseif ( ! empty( $item->wp_user_id ) ) :
      $wp_user = get_user_by( 'id', (int) $item->wp_user_id );
    ?>
    <tr>
      <th>WordPress-аккаунт</th>
      <td>
        <?php if ( $wp_user ) : ?>
          <span class="ts-badge ts-badge-active">✅ Привязан: <?php echo esc_html( $wp_user->user_login ); ?></span>
          <a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . $wp_user->ID ) ); ?>" class="button button-small" style="margin-left:8px;">Редактировать в WP</a>
        <?php else : ?>
          <span style="color:#999;">Аккаунт WP был удалён</span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endif; ?>

  </table>

  <p class="submit">
    <button type="submit" class="button button-primary">💾 Сохранить</button>
    <a href="<?php echo admin_url( 'admin.php?page=ts-dispatchers' ); ?>" class="button">Отмена</a>
  </p>
</form>

<?php endif; ?>
</div>
