<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="ts-driver-app" id="ts-dapp">
<style>
.ts-driver-app{max-width:480px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
.ts-dapp-header{background:#1a1a2e;color:#fff;padding:16px;border-radius:12px 12px 0 0;display:flex;justify-content:space-between;align-items:center;}
.ts-dapp-header h2{margin:0;font-size:18px;}
.ts-dapp-body{background:#fff;border:1px solid #e0e0e0;border-radius:0 0 12px 12px;padding:20px;}
.ts-dapp-input{width:100%;padding:10px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:15px;margin-bottom:10px;box-sizing:border-box;}
.ts-dapp-btn{width:100%;padding:12px;background:#e63946;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;}
.ts-dapp-btn:disabled{opacity:.6;}
.ts-dapp-msg{padding:10px;border-radius:8px;margin:8px 0;font-size:14px;}
.ts-dapp-msg.ok{background:#e8f5e9;color:#2e7d32;}
.ts-dapp-msg.err{background:#ffebee;color:#c62828;}
.ts-order-block{background:#f8f9fa;border-radius:10px;padding:14px;margin:8px 0;border-left:4px solid #e63946;}
.ts-order-block.status-arrived{border-left-color:#2196f3;}
.ts-order-block.status-in_progress{border-left-color:#4caf50;}
.ts-order-block.is-new-blink{animation:ts-blink 1s ease-in-out 3;}
@keyframes ts-blink{0%,100%{box-shadow:0 0 0 0 rgba(230,57,70,.4);}50%{box-shadow:0 0 0 8px rgba(230,57,70,0);}}
.ts-ob-num{font-size:13px;font-weight:700;color:#888;margin-bottom:6px;}
.ts-ob-status{display:inline-block;padding:2px 8px;border-radius:12px;font-size:12px;font-weight:600;margin-left:6px;}
.ts-ob-status.s-assigned{background:#fff3e0;color:#e65100;}
.ts-ob-status.s-arrived{background:#e3f2fd;color:#1565c0;}
.ts-ob-status.s-in_progress{background:#e8f5e9;color:#2e7d32;}
.ts-ob-addr{font-size:15px;margin:4px 0;}
.ts-ob-actions{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;}
.ts-ob-btn{flex:1;min-width:120px;padding:10px;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;}
.ts-ob-btn-arrived{background:#ff9800;color:#fff;}
.ts-ob-btn-intaxi{background:#2196f3;color:#fff;}
.ts-ob-btn-complete{background:#4caf50;color:#fff;}
.ts-ob-btn-cancel{background:#f5f5f5;color:#666;}
.ts-ob-btn:disabled{opacity:.5;cursor:not-allowed;}
.ts-status-row{display:flex;gap:8px;margin:10px 0;}
.ts-status-btn{flex:1;padding:8px;border-radius:8px;border:1.5px solid #ddd;background:#fff;font-size:13px;cursor:pointer;}
.ts-status-btn.active{border-color:#e63946;background:#e63946;color:#fff;font-weight:700;}
.ts-dapp-section{margin-top:14px;}
.ts-dapp-section h3{font-size:14px;color:#888;text-transform:uppercase;letter-spacing:.5px;margin:0 0 8px;}
.ts-action-err{margin-top:6px;padding:6px 10px;background:#ffebee;color:#c62828;border-radius:6px;font-size:13px;display:none;}
.ts-sound-badge{font-size:12px;padding:3px 8px;border-radius:10px;cursor:pointer;border:1px solid #ddd;background:#fff;}
.ts-sound-badge.on{background:#e8f5e9;color:#2e7d32;border-color:#a5d6a7;}
.ts-sound-badge.off{background:#fafafa;color:#999;}
</style>

<div class="ts-dapp-header">
  <h2>🚖 Водитель</h2>
  <div style="display:flex;align-items:center;gap:8px;">
    <span id="ts-sound-toggle" class="ts-sound-badge off" title="Включить/выключить звук">🔇 Звук</span>
    <span id="ts-dapp-callsign-display" style="font-size:13px;opacity:.8;"></span>
  </div>
</div>
<div class="ts-dapp-body">

  <!-- Login section -->
  <div id="ts-dapp-login">
    <p style="font-size:14px;color:#666;margin:0 0 12px;">Введите позывной и токен для входа</p>
    <input type="text" class="ts-dapp-input" id="dapp-callsign" placeholder="Позывной (тот же что у автомобиля)">
    <input type="password" class="ts-dapp-input" id="dapp-token" placeholder="Токен (из карточки водителя)">
    <button class="ts-dapp-btn" id="dapp-login-btn">Войти</button>
    <div id="dapp-login-msg" class="ts-dapp-msg" style="display:none;"></div>
    <p style="font-size:12px;color:#aaa;margin-top:8px;">Позывной и токен выдаёт диспетчер.</p>
  </div>

  <!-- Active section -->
  <div id="ts-dapp-active" style="display:none;">

    <div class="ts-dapp-section">
      <h3>Мой статус</h3>
      <div class="ts-status-row">
        <button class="ts-status-btn" data-status="free">🟢 Свободен</button>
        <button class="ts-status-btn" data-status="busy">🔴 Занят</button>
        <button class="ts-status-btn" data-status="offline">⚫ Офлайн</button>
      </div>
      <div id="dapp-status-msg" class="ts-action-err"></div>
    </div>

    <div class="ts-dapp-section">
      <h3>Активный заказ</h3>
      <div id="dapp-orders-list">
        <p style="color:#999;font-size:14px;">Загрузка…</p>
      </div>
    </div>

    <!-- Баланс -->
    <div class="ts-dapp-section" id="dapp-balance-section" style="margin-top:14px;">
      <h3>💰 Мой баланс — <span id="dapp-balance-month">…</span></h3>
      <div id="dapp-balance-body" style="background:#f8f9fa;border-radius:10px;padding:12px;font-size:14px;line-height:1.8;">
        <span style="color:#aaa;font-size:13px;">Загрузка…</span>
      </div>
    </div>

    <div id="dapp-location-msg" style="font-size:12px;color:#aaa;margin-top:10px;text-align:center;"></div>
    <button class="ts-dapp-btn" id="dapp-logout-btn" style="background:#666;margin-top:14px;">Выйти</button>
  </div>

</div>
</div>

<script>
(function(){
  var apiBase = '<?php echo esc_js( rest_url( 'taksi-server/v1' ) ); ?>';
  var nonce   = '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>';
  var callsign = '', token = '';
  var locationInterval = null, ordersInterval = null;
  var knownOrderIds = null;   // null = первая загрузка, не уведомлять
  var soundEnabled = localStorage.getItem('ts_sound') !== '0';

  /* ---- Звуковые уведомления (Web Audio API) ---- */
  var audioCtx = null;

  function getAudioCtx(){
    if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }

  // Трёхкратный сигнал "новый заказ"
  function playOrderAlert(){
    if(!soundEnabled) return;
    try {
      var ctx = getAudioCtx();
      var notes = [880, 1047, 1319]; // A5, C6, E6
      var t = ctx.currentTime;
      notes.forEach(function(freq, i){
        var osc  = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + i * 0.18);
        gain.gain.setValueAtTime(0.0, t + i * 0.18);
        gain.gain.linearRampToValueAtTime(0.55, t + i * 0.18 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.18 + 0.32);
        osc.start(t + i * 0.18);
        osc.stop(t  + i * 0.18 + 0.35);
      });
    } catch(e) {}
  }

  // Тихий тик при изменении статуса заказа
  function playStatusTick(){
    if(!soundEnabled) return;
    try {
      var ctx = getAudioCtx();
      var osc  = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'triangle'; osc.frequency.value = 660;
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
      osc.start(); osc.stop(ctx.currentTime + 0.2);
    } catch(e) {}
  }

  /* ---- Browser Notification (push) ---- */
  function requestNotifPermission(cb){
    if(!('Notification' in window)){ cb && cb(); return; }
    if(Notification.permission === 'granted'){ cb && cb(); return; }
    if(Notification.permission !== 'denied'){
      Notification.requestPermission().then(function(){ cb && cb(); });
    }
  }

  function showBrowserNotif(order){
    if(!('Notification' in window) || Notification.permission !== 'granted') return;
    var n = new Notification('🚖 Новый заказ!', {
      body: '📍 ' + (order.address_from || '') + (order.address_to ? ' → ' + order.address_to : ''),
      icon: '<?php echo esc_js( plugins_url( "assets/img/icon-128.png", TS_PLUGIN_FILE ) ); ?>',
      tag:  'ts-order-' + order.id,
      requireInteraction: true
    });
    setTimeout(function(){ n.close(); }, 15000);
  }

  /* ---- Кнопка управления звуком ---- */
  var soundEl = document.getElementById('ts-sound-toggle');
  function updateSoundBadge(){
    if(soundEnabled){
      soundEl.textContent = '🔔 Звук'; soundEl.className = 'ts-sound-badge on';
    } else {
      soundEl.textContent = '🔇 Звук'; soundEl.className = 'ts-sound-badge off';
    }
  }
  updateSoundBadge();

  soundEl.onclick = function(){
    soundEnabled = !soundEnabled;
    localStorage.setItem('ts_sound', soundEnabled ? '1' : '0');
    updateSoundBadge();
    if(soundEnabled){
      // Инициализируем AudioContext при первом нажатии (требование браузера)
      try{ getAudioCtx(); } catch(e){}
      playStatusTick();
    }
  };

  /* ---- HTTP API helper ---- */
  function api(endpoint, method, data, cb){
    var url = apiBase + endpoint;
    if(method === 'GET' && data){
      url += '?' + Object.keys(data).map(function(k){
        return encodeURIComponent(k)+'='+encodeURIComponent(data[k]);
      }).join('&');
    }
    var xhr = new XMLHttpRequest();
    xhr.open(method, url);
    xhr.setRequestHeader('X-WP-Nonce', nonce);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function(){
      try {
        var res = JSON.parse(xhr.responseText);
        if(xhr.status >= 400){ cb(res.message || 'Ошибка '+xhr.status, null); }
        else { cb(null, res); }
      } catch(e){ cb('Ошибка разбора ответа', null); }
    };
    xhr.onerror = function(){ cb('Нет соединения', null); };
    xhr.send(method !== 'GET' ? JSON.stringify(data) : null);
  }

  function showMsg(el, text, type){
    el.style.display = '';
    el.className = 'ts-dapp-msg ' + type;
    el.textContent = text;
  }

  /* ---- Вход ---- */
  document.getElementById('dapp-login-btn').onclick = function(){
    callsign = document.getElementById('dapp-callsign').value.trim();
    token    = document.getElementById('dapp-token').value.trim();
    var msgEl = document.getElementById('dapp-login-msg');
    if(!callsign || !token){ showMsg(msgEl, 'Введите позывной и токен', 'err'); return; }
    this.disabled = true; this.textContent = 'Входим…';
    var btn = this;
    api('/driver/orders', 'GET', {callsign:callsign, token:token}, function(err, res){
      btn.disabled = false; btn.textContent = 'Войти';
      if(err || !res || !res.ok){
        showMsg(msgEl, 'Неверный позывной или токен. Проверьте у диспетчера.', 'err');
        return;
      }
      localStorage.setItem('ts_callsign', callsign);
      localStorage.setItem('ts_token', token);
      requestNotifPermission(null);
      // Инициализируем аудио после взаимодействия пользователя
      try{ getAudioCtx(); } catch(e){}
      showActive();
    });
  };

  /* ---- Активный режим ---- */
  function showActive(){
    document.getElementById('ts-dapp-login').style.display = 'none';
    document.getElementById('ts-dapp-active').style.display = '';
    document.getElementById('ts-dapp-callsign-display').textContent = callsign;
    loadOrders();
    loadBalance();
    startLocation();
    ordersInterval = setInterval(loadOrders, 10000);
    setInterval(loadBalance, 120000); // обновлять баланс каждые 2 минуты
  }

  /* ---- Баланс водителя ---- */
  function loadBalance(){
    api('/driver/balance', 'GET', {callsign:callsign, token:token}, function(err, res){
      var monthEl = document.getElementById('dapp-balance-month');
      var bodyEl  = document.getElementById('dapp-balance-body');
      if(err || !res || !res.ok){
        bodyEl.innerHTML = '<span style="color:#aaa;font-size:13px;">Нет данных</span>';
        return;
      }
      monthEl.textContent = res.month;

      var payLabel = res.payment_type === 'percent'
        ? 'Комиссия фирмы: ' + res.commission + '%'
        : 'Абонентская плата: ' + fmtByn(res.sub_fee) + ' BYN/мес';

      var deductLabel = res.payment_type === 'percent'
        ? 'Удержано (' + res.commission + '%)'
        : 'Абонент (фикс.)';

      var netColor = res.net >= 0 ? '#2e7d32' : '#c62828';

      bodyEl.innerHTML =
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">'
        + kv('🚕 Поездок за месяц', res.trips)
        + kv('💰 Выручка', fmtByn(res.revenue) + ' BYN')
        + kv(deductLabel, '<span style="color:#e65100;">−' + fmtByn(res.deducted) + ' BYN</span>')
        + kv('✅ Ваш заработок', '<strong style="color:'+netColor+';">' + fmtByn(res.net) + ' BYN</strong>')
        + '</div>'
        + '<div style="font-size:11px;color:#aaa;margin-top:8px;">' + payLabel + '</div>'
        + '<div style="font-size:11px;color:#bbb;margin-top:2px;">Всего поездок: ' + res.all_trips + ' / выручка: ' + fmtByn(res.all_revenue) + ' BYN</div>';
    });
  }

  function kv(k, v){
    return '<div style="background:#fff;border-radius:7px;padding:8px 10px;">'
      + '<div style="font-size:11px;color:#888;margin-bottom:2px;">' + k + '</div>'
      + '<div style="font-weight:700;font-size:15px;">' + v + '</div>'
      + '</div>';
  }

  function fmtByn(n){
    return parseFloat(n||0).toLocaleString('ru', {minimumFractionDigits:2, maximumFractionDigits:2});
  }

  /* ---- Геолокация ---- */
  function startLocation(){
    var locMsg = document.getElementById('dapp-location-msg');
    if(!navigator.geolocation){
      locMsg.textContent = '⚠️ Браузер не поддерживает геолокацию';
      return;
    }
    sendLocation();
    locationInterval = setInterval(sendLocation, 30000);
  }

  function sendLocation(){
    var locMsg = document.getElementById('dapp-location-msg');
    navigator.geolocation.getCurrentPosition(
      function(pos){
        api('/driver/location', 'POST', {
          callsign:callsign, token:token,
          lat:pos.coords.latitude, lng:pos.coords.longitude
        }, function(err){
          locMsg.textContent = err ? '⚠️ Геолокация: '+err
            : '📍 Передана ('+new Date().toLocaleTimeString()+')';
        });
      },
      function(e){
        var msgs={1:'⚠️ Доступ к геолокации запрещён.',2:'⚠️ Невозможно определить позицию.',3:'⚠️ Таймаут геолокации.'};
        locMsg.textContent = msgs[e.code]||'⚠️ Ошибка геолокации';
      },
      {enableHighAccuracy:true, timeout:10000, maximumAge:30000}
    );
  }

  /* ---- Загрузка заказов + детектор новых ---- */
  function loadOrders(){
    api('/driver/orders', 'GET', {callsign:callsign, token:token}, function(err, res){
      var el = document.getElementById('dapp-orders-list');
      if(err || !res || !res.ok){
        el.innerHTML = '<p style="color:#e63946;font-size:14px;">⚠️ '+escHtml(err||'нет ответа')+'</p>';
        return;
      }
      var orders = res.orders || [];

      // Определяем новые заказы
      if(knownOrderIds !== null && orders.length > 0){
        var newOnes = orders.filter(function(o){
          return !knownOrderIds[o.id] && o.status === 'assigned';
        });
        if(newOnes.length > 0){
          playOrderAlert();
          if(navigator.vibrate) navigator.vibrate([300,100,300,100,300]);
          newOnes.forEach(function(o){ showBrowserNotif(o); });
        }
      }

      // Обновляем список известных ID
      var newMap = {};
      orders.forEach(function(o){ newMap[o.id] = o.status; });

      // Тик если статус существующего заказа изменился
      if(knownOrderIds !== null){
        orders.forEach(function(o){
          if(knownOrderIds[o.id] && knownOrderIds[o.id] !== o.status){
            playStatusTick();
          }
        });
      }

      knownOrderIds = newMap;

      if(!orders.length){
        el.innerHTML = '<p style="color:#999;font-size:14px;">Нет активных заказов. Ожидайте.</p>';
        return;
      }
      el.innerHTML = orders.map(function(o){ return renderOrder(o); }).join('');
    });
  }

  /* ---- Рендер карточки заказа ---- */
  var statusLabels = {assigned:'🚗 Назначен', arrived:'🅿 Прибыл', in_progress:'🚕 В такси'};

  function renderOrder(o){
    var waypoints = '';
    if(o.waypoints){
      try{
        var wps = JSON.parse(o.waypoints);
        if(wps.length) waypoints='<div class="ts-ob-addr" style="color:#888;">🔀 '+escHtml(wps.join(' → '))+'</div>';
      }catch(e){}
    }
    var statusClass = 'status-' + o.status;
    var statusLabel = statusLabels[o.status] || o.status;

    var btns = '';
    if(o.status === 'assigned'){
      btns += '<button class="ts-ob-btn ts-ob-btn-arrived" onclick="dappAction(\'arrived\','+o.id+',this)">🅿 Прибыл к клиенту</button>';
    }
    if(o.status === 'arrived'){
      btns += '<button class="ts-ob-btn ts-ob-btn-intaxi" onclick="dappAction(\'accept\','+o.id+',this)">🚕 Клиент в машине</button>';
    }
    if(o.status === 'arrived' || o.status === 'in_progress'){
      btns += '<button class="ts-ob-btn ts-ob-btn-complete" onclick="dappAction(\'complete\','+o.id+',this)">✅ Завершить поездку</button>';
    }
    btns += '<button class="ts-ob-btn ts-ob-btn-cancel" onclick="dappAction(\'cancel\','+o.id+',this)">✕ Отказать</button>';

    return '<div class="ts-order-block '+statusClass+(knownOrderIds && !knownOrderIds[o.id]?' is-new-blink':'')+'">'
      +'<div class="ts-ob-num">Заказ '+escHtml(o.order_number)
        +'<span class="ts-ob-status s-'+o.status+'">'+statusLabel+'</span></div>'
      +'<div class="ts-ob-addr">📍 <b>'+escHtml(o.address_from)+'</b></div>'
      + waypoints
      +(o.address_to?'<div class="ts-ob-addr">🏁 '+escHtml(o.address_to)+'</div>':'')
      +'<div class="ts-ob-addr" style="color:#555;">📞 '+escHtml(o.client_phone)+'</div>'
      +(o.client_name?'<div class="ts-ob-addr" style="color:#666;">👤 '+escHtml(o.client_name)+'</div>':'')
      +(o.notes?'<div class="ts-ob-addr" style="color:#888;">💬 '+escHtml(o.notes)+'</div>':'')
      +'<div class="ts-ob-actions">'+btns+'</div>'
      +'<div class="ts-action-err" id="err-'+o.id+'"></div>'
      +'</div>';
  }

  /* ---- Действия водителя ---- */
  var epMap = {accept:'/driver/order/accept', arrived:'/driver/order/arrived',
               complete:'/driver/order/complete', cancel:'/driver/order/cancel'};
  var btnLabels = {arrived:'🅿 Прибыл к клиенту', accept:'🚕 Клиент в машине',
                   complete:'✅ Завершить поездку', cancel:'✕ Отказать'};

  window.dappAction = function(action, orderId, btn){
    var ep = epMap[action]; if(!ep) return;
    if(btn){ btn.disabled=true; btn.textContent='…'; }
    var errEl = document.getElementById('err-'+orderId);
    if(errEl) errEl.style.display='none';

    api(ep,'POST',{callsign:callsign, token:token, order_id:orderId}, function(err, res){
      if(btn){ btn.disabled=false; btn.textContent=btnLabels[action]||action; }
      if(err || !res || !res.ok){
        var msg = err || (res&&res.message) || 'Ошибка. Попробуйте снова.';
        if(errEl){ errEl.style.display=''; errEl.textContent='❌ '+msg; }
      } else {
        loadOrders();
      }
    });
  };

  /* ---- Кнопки статуса ---- */
  document.querySelectorAll('.ts-status-btn').forEach(function(btn){
    btn.onclick = function(){
      var status = this.dataset.status;
      document.querySelectorAll('.ts-status-btn').forEach(function(b){ b.classList.remove('active'); });
      this.classList.add('active');
      // Инициализируем AudioContext при нажатии (требование браузеров)
      try{ getAudioCtx(); } catch(e){}
      api('/driver/status','POST',{callsign:callsign, token:token, status:status}, function(err){
        if(err){
          var m=document.getElementById('dapp-status-msg');
          m.style.display=''; m.textContent='❌ '+err;
          setTimeout(function(){ m.style.display='none'; },3000);
        }
      });
    };
  });

  /* ---- Выход ---- */
  document.getElementById('dapp-logout-btn').onclick = function(){
    if(locationInterval) clearInterval(locationInterval);
    if(ordersInterval)   clearInterval(ordersInterval);
    callsign=''; token=''; knownOrderIds=null;
    localStorage.removeItem('ts_callsign'); localStorage.removeItem('ts_token');
    document.getElementById('ts-dapp-login').style.display='';
    document.getElementById('ts-dapp-active').style.display='none';
    document.getElementById('ts-dapp-callsign-display').textContent='';
  };

  function escHtml(s){
    var d=document.createElement('div'); d.textContent=String(s||''); return d.innerHTML;
  }

  /* ---- Автовход ---- */
  var sc=localStorage.getItem('ts_callsign'), tk=localStorage.getItem('ts_token');
  if(sc&&tk){
    document.getElementById('dapp-callsign').value=sc;
    document.getElementById('dapp-token').value=tk;
    callsign=sc; token=tk;
    requestNotifPermission(null);
    showActive();
  }
})();
</script>
