<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$today      = current_time( 'Y-m-d' );
$date_from  = sanitize_text_field( $_GET['date_from'] ?? date( 'Y-m-01', current_time( 'timestamp' ) ) );
$date_to    = sanitize_text_field( $_GET['date_to']   ?? $today );

$summary        = TS_Reports::summary( $date_from, $date_to );
$rev_days       = TS_Reports::revenue_by_day( $date_from, $date_to );
$top_drivers    = TS_Reports::top_drivers( $date_from, $date_to, 15 );
$hourly         = TS_Reports::hourly_distribution( $date_from, $date_to );
$driver_earn    = TS_Reports::driver_earnings( $date_from, $date_to );

$rev_labels = array(); $rev_data = array(); $rev_cancel = array();
foreach ( $rev_days as $r ) {
    $rev_labels[] = date( 'd.m', strtotime( $r->day ) );
    $rev_data[]   = (float) $r->revenue;
    $rev_cancel[] = (int) $r->cancelled;
}

// Итоги по заработку
$earn_total_revenue = 0;
$earn_total_income  = 0;
foreach ( $driver_earn as $de ) {
    $earn_total_revenue += (float) $de->revenue;
    $earn_total_income  += (float) $de->company_income;
}
?>
<div class="wrap ts-wrap">
<div class="ts-page-header">
  <h1>📈 Отчёты</h1>
</div>

<style>
.ts-earn-table td.num { text-align:right; font-variant-numeric:tabular-nums; }
.ts-earn-badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:12px; font-weight:600; }
.ts-earn-badge.pct  { background:#e3f2fd; color:#1565c0; }
.ts-earn-badge.sub  { background:#f3e5f5; color:#6a1b9a; }
.ts-earn-row-sub td { background:#fdf8ff; }
.ts-earn-total td   { font-weight:700; background:#f5f5f5; border-top:2px solid #ddd; }
.ts-earn-zero { color:#bbb; }
.ts-tab-btns  { display:flex; gap:6px; margin-bottom:14px; border-bottom:2px solid #e0e0e0; }
.ts-tab-btn   { padding:8px 18px; border:none; background:none; font-size:14px; cursor:pointer; border-bottom:3px solid transparent; margin-bottom:-2px; }
.ts-tab-btn.active { border-bottom-color:#e63946; font-weight:700; color:#e63946; }
.ts-tab-pane  { display:none; }
.ts-tab-pane.active { display:block; }
</style>

<!-- Filter -->
<form method="get" class="ts-report-filter">
  <input type="hidden" name="page" value="ts-reports">
  <div class="ts-filter-inline">
    <div class="ts-fi-group">
      <label>С</label>
      <input type="date" name="date_from" value="<?php echo esc_attr( $date_from ); ?>">
    </div>
    <div class="ts-fi-group">
      <label>По</label>
      <input type="date" name="date_to" value="<?php echo esc_attr( $date_to ); ?>">
    </div>
    <button type="submit" class="button button-primary">Показать</button>
    <div class="ts-fi-presets">
      <?php
      $presets = array(
          'Сегодня'       => array( $today, $today ),
          'Неделя'        => array( date( 'Y-m-d', strtotime( '-6 days', current_time( 'timestamp' ) ) ), $today ),
          'Месяц'         => array( date( 'Y-m-01', current_time( 'timestamp' ) ), $today ),
          'Прошлый месяц' => array( date( 'Y-m-01', strtotime( 'first day of last month', current_time( 'timestamp' ) ) ), date( 'Y-m-t', strtotime( 'first day of last month', current_time( 'timestamp' ) ) ) ),
      );
      foreach ( $presets as $label => list( $from, $to ) ) :
        $url = admin_url( 'admin.php?page=ts-reports&date_from=' . $from . '&date_to=' . $to );
      ?>
      <a href="<?php echo esc_url( $url ); ?>" class="ts-preset"><?php echo esc_html( $label ); ?></a>
      <?php endforeach; ?>
    </div>
    <div style="margin-left:auto;display:flex;gap:6px;">
      <?php
      $export_base = wp_nonce_url(
          admin_url( 'admin-post.php?action=ts_export&date_from=' . urlencode( $date_from ) . '&date_to=' . urlencode( $date_to ) ),
          'ts_export'
      );
      ?>
      <a href="<?php echo esc_url( $export_base . '&format=excel' ); ?>" class="button ts-btn-excel">⬇ Excel</a>
      <a href="<?php echo esc_url( $export_base . '&format=csv' );   ?>" class="button ts-btn-csv">⬇ CSV</a>
    </div>
  </div>
</form>

<!-- KPI -->
<div class="ts-kpi-grid">
  <div class="ts-kpi-card ts-kpi-revenue">
    <div class="ts-kpi-icon">💰</div>
    <div><div class="ts-kpi-value"><?php echo number_format( (float)($summary->revenue??0), 0, '.', ' ' ); ?> BYN</div><div class="ts-kpi-label">Выручка</div></div>
  </div>
  <div class="ts-kpi-card ts-kpi-orders">
    <div class="ts-kpi-icon">📋</div>
    <div><div class="ts-kpi-value"><?php echo (int)($summary->total??0); ?></div><div class="ts-kpi-label">Заказов</div></div>
  </div>
  <div class="ts-kpi-card ts-kpi-done">
    <div class="ts-kpi-icon">✅</div>
    <div><div class="ts-kpi-value"><?php echo (int)($summary->completed??0); ?></div><div class="ts-kpi-label">Выполнено</div></div>
  </div>
  <div class="ts-kpi-card ts-kpi-cancel">
    <div class="ts-kpi-icon">❌</div>
    <div><div class="ts-kpi-value"><?php echo (int)($summary->cancelled??0); ?></div><div class="ts-kpi-label">Отменено</div></div>
  </div>
  <div class="ts-kpi-card ts-kpi-avg">
    <div class="ts-kpi-icon">💳</div>
    <div><div class="ts-kpi-value"><?php echo number_format( (float)($summary->avg_price??0), 0, '.', ' ' ); ?> BYN</div><div class="ts-kpi-label">Средний чек</div></div>
  </div>
  <div class="ts-kpi-card ts-kpi-km">
    <div class="ts-kpi-icon">🛣</div>
    <div><div class="ts-kpi-value"><?php echo number_format( (float)($summary->avg_km??0), 1 ); ?> км</div><div class="ts-kpi-label">Средний км</div></div>
  </div>
</div>

<!-- Charts -->
<div class="ts-charts-row">
  <div class="ts-chart-card ts-chart-wide">
    <div class="ts-chart-title">Выручка по дням</div>
    <canvas id="ts-rep-revenue" height="110"></canvas>
  </div>
  <div class="ts-chart-card">
    <div class="ts-chart-title">Заказы по часам</div>
    <canvas id="ts-rep-hourly" height="110"></canvas>
  </div>
</div>

<!-- Tabs -->
<div class="ts-tab-btns">
  <button class="ts-tab-btn active" data-tab="tab-earnings">💰 Расчёт с водителями</button>
  <button class="ts-tab-btn" data-tab="tab-top">🏆 Топ водителей</button>
  <button class="ts-tab-btn" data-tab="tab-orders">📋 Список заказов</button>
</div>

<!-- TAB: Расчёт с водителями -->
<div class="ts-tab-pane active" id="tab-earnings">
  <div class="ts-report-section">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
      <h2 style="margin:0;">💰 Расчёт с водителями
        <span style="font-size:13px;font-weight:400;color:#888;">
          за <?php echo esc_html($date_from); ?> — <?php echo esc_html($date_to); ?>
        </span>
      </h2>
      <div style="display:flex;gap:6px;">
        <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ts_export&tab=earnings&date_from=' . urlencode($date_from) . '&date_to=' . urlencode($date_to) ), 'ts_export' ) . '&format=earnings_csv' ); ?>"
           class="button ts-btn-csv">⬇ CSV расчётов</a>
      </div>
    </div>

    <p style="font-size:13px;color:#666;margin:0 0 10px;">
      <strong>Процент</strong> — водитель отдаёт % от суммы поездок.
      <strong>Абонент</strong> — водитель платит фиксированную сумму за месяц независимо от числа поездок.
      «Ваш доход» — то, что вы получаете с водителя. «Чистый водителю» — то, что остаётся ему.
    </p>

    <div class="ts-table-scroll">
      <table class="ts-table widefat ts-table-sm">
        <thead>
          <tr>
            <th>Водитель</th>
            <th>Позывной</th>
            <th>Тип</th>
            <th class="num">Поездок</th>
            <th class="num">Выручка, BYN</th>
            <th class="num">Ср. чек, BYN</th>
            <th class="num">Ваш доход, BYN</th>
            <th class="num">Чистый водителю, BYN</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $driver_earn as $de ) :
            $ptype    = $de->payment_type ?? 'percent';
            $revenue  = (float) $de->revenue;
            $income   = (float) $de->company_income;
            $net      = $revenue - $income;
            $trips    = (int) $de->trips;
            $avg      = $trips > 0 ? $revenue / $trips : 0;
            $pct      = (float) ( $de->commission_pct ?? 0 );
            $sub_fee  = (float) ( $de->subscription_fee ?? 0 );
            $row_cls  = $ptype === 'subscription' ? 'ts-earn-row-sub' : '';
          ?>
          <tr class="<?php echo esc_attr($row_cls); ?>">
            <td><strong><?php echo esc_html($de->name); ?></strong>
              <?php if($de->phone): ?>
                <br><span style="color:#888;font-size:12px;">📞 <?php echo esc_html($de->phone); ?></span>
              <?php endif; ?>
            </td>
            <td><code><?php echo esc_html($de->callsign); ?></code></td>
            <td>
              <?php if ( $ptype === 'percent' ) : ?>
                <span class="ts-earn-badge pct">% <?php echo number_format($pct,1); ?>%</span>
              <?php else : ?>
                <span class="ts-earn-badge sub">Абон. <?php echo number_format($sub_fee,0,'.',' '); ?> BYN</span>
              <?php endif; ?>
            </td>
            <td class="num <?php echo $trips === 0 ? 'ts-earn-zero' : ''; ?>"><?php echo $trips ?: '—'; ?></td>
            <td class="num <?php echo $revenue == 0 ? 'ts-earn-zero' : ''; ?>">
              <?php echo $revenue > 0 ? number_format($revenue,0,'.',' ') : '—'; ?>
            </td>
            <td class="num <?php echo $avg == 0 ? 'ts-earn-zero' : ''; ?>">
              <?php echo $avg > 0 ? number_format($avg,0,'.',' ') : '—'; ?>
            </td>
            <td class="num" style="color:#2e7d32;font-weight:600;">
              <?php echo number_format($income,0,'.',' '); ?>
              <?php if ($ptype==='percent' && $pct>0): ?>
                <span style="color:#888;font-size:11px;">(<?php echo number_format($pct,1); ?>%)</span>
              <?php endif; ?>
            </td>
            <td class="num" style="<?php echo $net < 0 ? 'color:#c62828;' : ''; ?>">
              <?php echo number_format($net,0,'.',' '); ?>
            </td>
          </tr>
          <?php endforeach; ?>

          <?php if ( empty($driver_earn) ) : ?>
            <tr><td colspan="8" class="ts-empty">Нет активных водителей</td></tr>
          <?php else : ?>
            <!-- Строка итогов -->
            <tr class="ts-earn-total">
              <td colspan="3">ИТОГО</td>
              <td class="num"><?php echo array_sum( array_column( (array)$driver_earn, 'trips' ) ); ?></td>
              <td class="num"><?php echo number_format($earn_total_revenue,0,'.',' '); ?></td>
              <td class="num">—</td>
              <td class="num" style="color:#2e7d32;"><?php echo number_format($earn_total_income,0,'.',' '); ?></td>
              <td class="num"><?php echo number_format($earn_total_revenue - $earn_total_income,0,'.',' '); ?></td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <p style="font-size:12px;color:#aaa;margin-top:8px;">
      ⚠️ Для абонентских водителей «Ваш доход» = фиксированная плата за месяц, не зависит от числа поездок.
      «Чистый водителю» = выручка минус ваш доход (может быть отрицательным если поездок не было).
    </p>
  </div>
</div>

<!-- TAB: Топ водителей -->
<div class="ts-tab-pane" id="tab-top">
  <?php if ( $top_drivers ) : ?>
  <div class="ts-report-section">
    <h2>🏆 Топ водителей</h2>
    <div class="ts-table-scroll">
      <table class="ts-table widefat ts-table-sm">
        <thead><tr><th>#</th><th>Водитель</th><th>Поездок</th><th>Выручка</th><th>Ср. чек</th></tr></thead>
        <tbody>
          <?php foreach ( $top_drivers as $i => $d ) : ?>
          <tr>
            <td><span class="ts-rank ts-rank-<?php echo $i+1; ?>"><?php echo $i+1; ?></span></td>
            <td><?php echo esc_html( $d->name ); ?></td>
            <td><?php echo (int)$d->trips; ?></td>
            <td><?php echo number_format( (float)$d->revenue, 0, '.', ' ' ); ?> BYN</td>
            <td><?php echo number_format( (float)$d->avg_price, 0, '.', ' ' ); ?> BYN</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php else : ?>
    <p style="color:#999;padding:20px 0;">Нет данных за выбранный период</p>
  <?php endif; ?>
</div>

<!-- TAB: Список заказов -->
<div class="ts-tab-pane" id="tab-orders">
  <div class="ts-report-section" style="margin-top:14px;">
    <h2>Заказы за период</h2>
    <?php
    $orders = TS_Reports::orders_for_export( $date_from, $date_to );
    $status_labels = array( 'new'=>'Новый','assigned'=>'Назначен','in_progress'=>'В пути','arrived'=>'Прибыл','completed'=>'Выполнен','cancelled'=>'Отменён' );
    ?>
    <div class="ts-table-scroll">
      <table class="ts-table widefat ts-table-sm">
        <thead><tr><th>№</th><th>Дата</th><th>Клиент</th><th>Телефон</th><th>Откуда</th><th>Куда</th><th>Водитель</th><th>Машина</th><th>Статус</th><th>Цена</th></tr></thead>
        <tbody>
          <?php foreach ( $orders as $o ) : ?>
          <tr class="<?php echo $o->status==='completed' ? 'ts-row-ok' : ($o->status==='cancelled'?'ts-row-cancel':''); ?>">
            <td><?php echo esc_html($o->order_number); ?></td>
            <td><?php echo esc_html(substr($o->created_at,0,16)); ?></td>
            <td><?php echo esc_html($o->client_name); ?></td>
            <td><?php echo esc_html($o->client_phone); ?></td>
            <td><?php echo esc_html(mb_strimwidth($o->address_from,0,40,'…')); ?></td>
            <td><?php echo esc_html(mb_strimwidth($o->address_to,0,30,'…')); ?></td>
            <td><?php echo esc_html($o->driver_name??'—'); ?></td>
            <td><?php echo esc_html($o->car_callsign??'—'); ?></td>
            <td><span class="ts-badge ts-badge-<?php echo esc_attr($o->status); ?>"><?php echo esc_html($status_labels[$o->status]??$o->status); ?></span></td>
            <td><?php echo $o->price ? number_format((float)$o->price,0,'.',' ').' BYN' : '—'; ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if(!$orders): ?><tr><td colspan="10" class="ts-empty">Нет заказов за выбранный период</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div><!-- /wrap -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function(){
  /* ---- Charts ---- */
  var revLabels = <?php echo wp_json_encode($rev_labels); ?>;
  var revData   = <?php echo wp_json_encode($rev_data); ?>;
  var revCancel = <?php echo wp_json_encode($rev_cancel); ?>;
  var hourly    = <?php echo wp_json_encode(array_values($hourly)); ?>;
  var hLabels   = Array.from({length:24},function(_,i){ return ('0'+i).slice(-2)+':00'; });

  new Chart(document.getElementById('ts-rep-revenue'), {
    type:'bar',
    data:{
      labels:revLabels,
      datasets:[
        { label:'Выручка BYN', data:revData, backgroundColor:'rgba(230,57,70,.75)', borderRadius:6 },
        { label:'Отменено',  data:revCancel, type:'line', borderColor:'#ff9800', backgroundColor:'transparent', tension:.3, pointRadius:4 }
      ]
    },
    options:{ responsive:true, interaction:{mode:'index',intersect:false},
      scales:{ y:{ beginAtZero:true, ticks:{ callback:function(v){ return v.toLocaleString('ru')+'BYN'; } } } }
    }
  });

  new Chart(document.getElementById('ts-rep-hourly'), {
    type:'bar',
    data:{
      labels:hLabels,
      datasets:[{ label:'Заказов', data:hourly, backgroundColor:'rgba(33,150,243,.7)', borderRadius:4 }]
    },
    options:{ responsive:true, scales:{ y:{ beginAtZero:true } } }
  });

  /* ---- Tabs ---- */
  document.querySelectorAll('.ts-tab-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      document.querySelectorAll('.ts-tab-btn').forEach(function(b){ b.classList.remove('active'); });
      document.querySelectorAll('.ts-tab-pane').forEach(function(p){ p.classList.remove('active'); });
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });
})();
</script>
