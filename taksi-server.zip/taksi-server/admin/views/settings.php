<?php if ( ! defined( 'ABSPATH' ) ) exit; $saved = ! empty( $_GET['saved'] ); ?>
<div class="wrap ts-wrap">
<h1>⚙️ Настройки — Такси Сервер</h1>
<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>✅ Настройки сохранены.</p></div><?php endif; ?>

<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="settings">
  <?php wp_nonce_field( 'ts_save' ); ?>

  <div class="ts-settings-section">
    <h2>🏢 Компания</h2>
    <table class="form-table">
      <tr>
        <th>Название компании</th>
        <td><input type="text" name="ts_company_name" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_company_name', 'Такси' ) ); ?>"></td>
      </tr>
      <tr>
        <th>Телефон компании</th>
        <td><input type="text" name="ts_company_phone" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_company_phone', '' ) ); ?>"></td>
      </tr>
      <tr>
        <th>Секретный ключ водителей</th>
        <td>
          <input type="text" name="ts_driver_secret" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_driver_secret', 'taksi-server' ) ); ?>">
          <p class="description">Токен = MD5(позывной + ключ). Не меняйте без необходимости.</p>
        </td>
      </tr>
      <tr>
        <th>Порт TCP-сервера (Таксофон)</th>
        <td>
          <input type="number" name="ts_tcp_port" class="small-text" value="<?php echo esc_attr( get_option( 'ts_tcp_port', '4000' ) ); ?>">
          <p class="description">Порт для таксофонов «Такси Мастер». По умолчанию: 4000.</p>
        </td>
      </tr>
      <tr>
        <th>API ключ Яндекс.Карт</th>
        <td>
          <input type="text" name="ts_maps_api_key" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_maps_api_key', '' ) ); ?>">
          <p class="description">Для карты водителей. Получить: <a href="https://developer.tech.yandex.ru/" target="_blank">developer.tech.yandex.ru</a></p>
        </td>
      </tr>
    </table>
  </div>

  <div class="ts-settings-section">
    <h2>💰 Финансы / Оплата водителей</h2>
    <table class="form-table">
      <tr>
        <th>Комиссия по умолчанию (%)</th>
        <td>
          <input type="number" name="ts_default_commission_pct" class="small-text" min="0" max="100" step="0.01"
                 value="<?php echo esc_attr( number_format( (float) get_option( 'ts_default_commission_pct', 0 ), 2, '.', '' ) ); ?>">
          <p class="description">Процент, который подставляется при создании нового водителя с типом «Процент с поездок». Каждому водителю можно задать свой.</p>
        </td>
      </tr>
    </table>
  </div>

  <div class="ts-settings-section">
    <h2>📨 Уведомления водителям</h2>
    <table class="form-table">
      <tr>
        <th>Канал уведомлений водителям</th>
        <td>
          <select name="ts_driver_notify_channel">
            <?php $ch = get_option( 'ts_driver_notify_channel', 'telegram' );
            foreach ( array( 'telegram' => 'Telegram', 'viber' => 'Viber', 'max' => 'Max', 'sms' => 'SMS' ) as $v => $l ) : ?>
            <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $ch, $v ); ?>><?php echo esc_html( $l ); ?></option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th>Telegram: токен бота (водители)</th>
        <td>
          <input type="text" name="ts_telegram_driver_bot_token" class="regular-text"
                 placeholder="1234567890:AAABBB..."
                 value="<?php echo esc_attr( get_option( 'ts_telegram_driver_bot_token', '' ) ); ?>">
          <p class="description">Создать бота: <a href="https://t.me/BotFather" target="_blank">@BotFather</a></p>
        </td>
      </tr>
      <tr>
        <th>Viber: токен бота</th>
        <td><input type="text" name="ts_viber_bot_token" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_viber_bot_token', '' ) ); ?>"></td>
      </tr>
      <tr>
        <th>Max: токен бота</th>
        <td><input type="text" name="ts_max_bot_token" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_max_bot_token', '' ) ); ?>"></td>
      </tr>
    </table>
    <div class="ts-test-notify-box">
      <h4>Тест уведомления водителю</h4>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <select id="test-drv-channel">
          <option value="telegram_driver">Telegram</option>
          <option value="viber">Viber</option>
          <option value="max">Max</option>
          <option value="sms">SMS</option>
        </select>
        <input type="text" id="test-drv-recipient" placeholder="Chat ID / номер телефона" style="width:200px;">
        <button type="button" id="test-drv-btn" class="button">Отправить тест</button>
        <span id="test-drv-result"></span>
      </div>
    </div>
  </div>

  <div class="ts-settings-section">
    <h2>📱 Уведомления клиентам</h2>
    <table class="form-table">
      <tr>
        <th>Канал уведомлений клиентам</th>
        <td>
          <select name="ts_client_notify_channel">
            <?php $cc = get_option( 'ts_client_notify_channel', 'sms' );
            foreach ( array( 'telegram' => 'Telegram', 'viber' => 'Viber', 'max' => 'Max', 'sms' => 'SMS' ) as $v => $l ) : ?>
            <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $cc, $v ); ?>><?php echo esc_html( $l ); ?></option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th>Telegram: токен бота (клиенты)</th>
        <td>
          <input type="text" name="ts_telegram_client_bot_token" class="regular-text"
                 placeholder="Можно использовать того же бота"
                 value="<?php echo esc_attr( get_option( 'ts_telegram_client_bot_token', '' ) ); ?>">
        </td>
      </tr>
    </table>
  </div>

  <div class="ts-settings-section">
    <h2>📲 SMS (SMSC.ru)</h2>
    <table class="form-table">
      <tr>
        <th>Логин SMSC.ru</th>
        <td><input type="text" name="ts_sms_login" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_sms_login', '' ) ); ?>"></td>
      </tr>
      <tr>
        <th>Пароль SMSC.ru</th>
        <td><input type="password" name="ts_sms_password" class="regular-text" value="<?php echo esc_attr( get_option( 'ts_sms_password', '' ) ); ?>"></td>
      </tr>
    </table>
  </div>

  <div class="ts-settings-section">
    <h2>⚡ Авто-распределение заказов</h2>
    <table class="form-table">
      <tr>
        <th>Включить авто-распределение</th>
        <td>
          <label>
            <input type="checkbox" name="ts_auto_dispatch" value="1" <?php checked( '1', get_option( 'ts_auto_dispatch', '0' ) ); ?>>
            Автоматически назначать заказы свободным машинам
          </label>
          <p class="description">Если диспетчер не назначил заказ вручную — он автоматически уйдёт первой свободной машине (по очереди).</p>
        </td>
      </tr>
      <tr>
        <th>Таймаут (секунд)</th>
        <td>
          <input type="number" name="ts_auto_dispatch_timeout" class="small-text" min="5" max="3600"
                 value="<?php echo esc_attr( get_option( 'ts_auto_dispatch_timeout', 20 ) ); ?>">
          <p class="description">Через сколько секунд после создания заказ передаётся авто-распределению. По умолчанию: 20 сек.</p>
        </td>
      </tr>
    </table>
  </div>

  <p><button type="submit" class="button button-primary button-large">💾 Сохранить настройки</button></p>
</form>

<div class="ts-settings-section" style="margin-top:24px;">
  <h2>🗄️ База данных</h2>
  <table class="form-table">
    <tr>
      <th>Версия схемы в БД</th>
      <td>
        <?php
        $installed = get_option( 'ts_db_version', '—' );
        $current   = TS_VERSION;
        $ok        = version_compare( $installed, $current, '>=' );
        echo '<code>' . esc_html( $installed ) . '</code>';
        echo $ok
          ? ' <span style="color:#4caf50;">✅ актуальная</span>'
          : ' <span style="color:#e53935;">⚠️ устарела (текущая: ' . esc_html( $current ) . ')</span>';
        ?>
      </td>
    </tr>
    <tr>
      <th>Статус таблиц</th>
      <td>
        <?php
        global $wpdb;
        $tables  = array( 'ts_orders', 'ts_cars', 'ts_drivers', 'ts_dispatchers', 'ts_phone_lines' );
        $missing = array();
        foreach ( $tables as $t ) {
            $full = $wpdb->prefix . $t;
            if ( $wpdb->get_var( "SHOW TABLES LIKE '$full'" ) !== $full ) {
                $missing[] = $full;
            }
        }
        echo empty( $missing )
          ? '<span style="color:#4caf50;">✅ Все таблицы существуют</span>'
          : '<span style="color:#e53935;">❌ Отсутствуют: ' . esc_html( implode( ', ', $missing ) ) . '</span>';
        ?>
      </td>
    </tr>
    <tr>
      <th>Пересоздать / обновить таблицы</th>
      <td>
        <button type="button" id="ts-recreate-tables-btn" class="button button-secondary">🔧 Пересоздать таблицы</button>
        <span id="ts-recreate-result" style="margin-left:10px;font-size:13px;"></span>
        <p class="description">Используйте если таблицы отсутствуют или появляются ошибки. Данные не удаляются. Также добавляет новые колонки (поля оплаты водителя).</p>
      </td>
    </tr>
  </table>
</div>
</div>

<script>
jQuery(function($){
  $('#ts-recreate-tables-btn').on('click', function(){
    var btn = $(this).prop('disabled', true).text('Пересоздаём…');
    $('#ts-recreate-result').css('color','#888').text('Подождите…');
    $.post(TS.ajax_url, {action:'ts_action', ts_action:'recreate_tables', nonce:TS.nonce}, function(res){
      btn.prop('disabled', false).text('🔧 Пересоздать таблицы');
      if (res && res.success) {
        $('#ts-recreate-result').css('color','#4caf50').text('✅ Готово! ' + (res.data.message || ''));
        setTimeout(function(){ location.reload(); }, 1500);
      } else {
        $('#ts-recreate-result').css('color','#e53935').text('❌ Ошибка: ' + (res && res.data ? res.data : 'нет ответа'));
      }
    }).fail(function(){
      btn.prop('disabled', false).text('🔧 Пересоздать таблицы');
      $('#ts-recreate-result').css('color','#e53935').text('❌ Ошибка соединения');
    });
  });

  $('#test-drv-btn').on('click',function(){
    var ch  = $('#test-drv-channel').val();
    var rec = $('#test-drv-recipient').val().trim();
    if(!rec){ alert('Введите получателя'); return; }
    var btn = $(this).prop('disabled',true).text('Отправка…');
    $.post(TS.ajax_url, {action:'ts_action',ts_action:'notify_test',channel:ch,recipient:rec,nonce:TS.nonce}, function(res){
      btn.prop('disabled',false).text('Отправить тест');
      var el = $('#test-drv-result');
      if(res.ok){ el.css('color','#4caf50').text('✅ Отправлено!'); }
      else { el.css('color','#e63946').text('❌ Ошибка: '+(res.error||JSON.stringify(res))); }
    });
  });
});
</script>
