<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="ts-register-wrap" style="max-width:480px;margin:0 auto;">
<style>
.ts-register-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
.ts-reg-card{background:#fff;border:1px solid #e0e0e0;border-radius:12px;overflow:hidden;}
.ts-reg-header{background:#1a1a2e;color:#fff;padding:20px;text-align:center;}
.ts-reg-header h2{margin:0 0 4px;font-size:20px;}
.ts-reg-header p{margin:0;font-size:13px;opacity:.7;}
.ts-reg-body{padding:20px;}
.ts-reg-field{margin-bottom:14px;}
.ts-reg-label{display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:5px;}
.ts-reg-input{width:100%;padding:10px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;transition:border-color .15s;}
.ts-reg-input:focus{outline:none;border-color:#e63946;}
.ts-reg-btn{width:100%;padding:13px;background:#e63946;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;margin-top:6px;}
.ts-reg-btn:disabled{opacity:.6;}
.ts-reg-msg{padding:12px;border-radius:8px;margin-top:12px;font-size:14px;}
.ts-reg-msg.ok{background:#e8f5e9;color:#2e7d32;border:1px solid #c8e6c9;}
.ts-reg-msg.err{background:#ffebee;color:#c62828;border:1px solid #ffcdd2;}
</style>
<div class="ts-reg-card">
  <div class="ts-reg-header">
    <h2>🧑‍✈️ Регистрация водителя</h2>
    <p>Заполните форму — диспетчер одобрит заявку</p>
  </div>
  <div class="ts-reg-body">
    <div class="ts-reg-field">
      <label class="ts-reg-label">ФИО *</label>
      <input type="text" class="ts-reg-input" id="reg-name" placeholder="Иванов Иван Иванович">
    </div>
    <div class="ts-reg-field">
      <label class="ts-reg-label">Позывной * <small style="color:#999;">(придумайте уникальный, например: 001 или Сокол)</small></label>
      <input type="text" class="ts-reg-input" id="reg-callsign" placeholder="Ваш позывной">
    </div>
    <div class="ts-reg-field">
      <label class="ts-reg-label">Телефон *</label>
      <input type="tel" class="ts-reg-input" id="reg-phone" placeholder="+7 000 000 00 00">
    </div>
    <div class="ts-reg-field">
      <label class="ts-reg-label">Номер водительского удостоверения</label>
      <input type="text" class="ts-reg-input" id="reg-license" placeholder="00 00 000000">
    </div>
    <div class="ts-reg-field">
      <label class="ts-reg-label">Telegram Chat ID <small style="color:#999;">(для уведомлений о заказах)</small></label>
      <input type="text" class="ts-reg-input" id="reg-tg" placeholder="Узнать: написать @userinfobot">
    </div>
    <button class="ts-reg-btn" id="reg-submit-btn">Отправить заявку</button>
    <div id="reg-msg" style="display:none;"></div>
  </div>
</div>
</div>

<script>
(function(){
  var apiBase = '<?php echo esc_js( rest_url( 'taksi-server/v1' ) ); ?>';
  var nonce   = '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>';

  document.getElementById('reg-submit-btn').onclick = function(){
    var name     = document.getElementById('reg-name').value.trim();
    var callsign = document.getElementById('reg-callsign').value.trim();
    var phone    = document.getElementById('reg-phone').value.trim();
    var license  = document.getElementById('reg-license').value.trim();
    var tg_id    = document.getElementById('reg-tg').value.trim();
    var msgEl    = document.getElementById('reg-msg');

    if(!name||!callsign||!phone){ showMsg('❌ Заполните обязательные поля: ФИО, позывной, телефон','err'); return; }

    var btn = this;
    btn.disabled=true; btn.textContent='Отправляем…';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', apiBase+'/driver/register');
    xhr.setRequestHeader('Content-Type','application/json');
    xhr.setRequestHeader('X-WP-Nonce', nonce);
    xhr.onload = function(){
      btn.disabled=false; btn.textContent='Отправить заявку';
      var res = JSON.parse(xhr.responseText);
      if(res.ok){
        showMsg('✅ Заявка принята! Ожидайте звонка от диспетчера.<br>Ваш позывной: <strong>'+res.callsign+'</strong><br>Ваш токен (запишите): <code>'+res.token+'</code>','ok');
        btn.style.display='none';
      } else {
        showMsg('❌ '+(res.message||'Ошибка. Попробуйте снова.'),'err');
      }
    };
    xhr.send(JSON.stringify({name:name,callsign:callsign,phone:phone,license:license,telegram_chat_id:tg_id}));

    function showMsg(text,type){
      msgEl.style.display='';
      msgEl.className='ts-reg-msg '+type;
      msgEl.innerHTML=text;
    }
  };
})();
</script>
