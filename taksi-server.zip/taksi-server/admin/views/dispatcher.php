<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$new_orders  = TS_Orders::get_all( array( 'status' => 'new',                             'limit' => 200 ) );
$assigned    = TS_Orders::get_all( array( 'status' => 'assigned',                        'limit' => 200 ) );
$progress    = TS_Orders::get_all( array( 'status' => array( 'in_progress', 'arrived' ), 'limit' => 200 ) );
$all_cars    = TS_Cars::get_all();
$free_cars   = array_filter( $all_cars, fn($c) => $c->status === 'free' );
$all_drivers = TS_Drivers::get_all( array( 'status' => 'active', 'limit' => 100 ) );
$phone_lines = TS_Database::table('phone_lines') ? TS_Phones::get_all() : array();
?>
<style>
/* ====  Диспетчер — общий фрейм  ==== */
.ts-disp-wrap{width:100%;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;}
.ts-disp-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 14px;background:#1a1a2e;border-radius:10px;margin-bottom:14px;}
.ts-disp-title{color:#fff;font-size:17px;font-weight:800;letter-spacing:.3px;}
.ts-disp-cars-count{color:rgba(255,255,255,.75);font-size:13px;margin-left:auto;}
.ts-autodispatch-badge{background:#4caf50;color:#fff;font-size:12px;padding:2px 10px;border-radius:10px;display:none;}

/* ====  Колонки  ==== */
.ts-disp-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;}
@media(max-width:900px){.ts-disp-columns{grid-template-columns:1fr;}}
.ts-disp-col{background:#f7f8fc;border-radius:12px;min-height:260px;display:flex;flex-direction:column;}
.ts-disp-col-header{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#fff;border-radius:12px 12px 0 0;border-bottom:2px solid #eee;font-weight:700;font-size:14px;}
.ts-disp-col-body{padding:10px;flex:1;overflow-y:auto;max-height:75vh;}
.ts-disp-count{background:#e63946;color:#fff;font-size:12px;font-weight:700;border-radius:12px;padding:2px 8px;min-width:22px;text-align:center;}

/* ====  Карточка заказа  ==== */
.ts-order-card{background:#fff;border-radius:10px;padding:12px 14px;margin-bottom:10px;box-shadow:0 1px 4px rgba(0,0,0,.08);border-left:4px solid #e0e0e0;transition:box-shadow .15s;}
.ts-order-card:hover{box-shadow:0 3px 12px rgba(0,0,0,.13);}
.ts-order-card[data-status="assigned"]{border-left-color:#2196f3;}
.ts-order-card[data-status="arrived"]{border-left-color:#ff9800;}
.ts-order-card[data-status="in_progress"]{border-left-color:#4caf50;}
.ts-card-urgent{border-left-color:#e63946!important;animation:ts-urgent-pulse 2s infinite;}
@keyframes ts-urgent-pulse{0%,100%{box-shadow:0 0 0 0 rgba(230,57,70,.25);}50%{box-shadow:0 0 0 6px rgba(230,57,70,0);}}
.ts-oc-top{display:flex;justify-content:space-between;margin-bottom:5px;}
.ts-oc-num{font-weight:800;font-size:14px;color:#1a1a2e;}
.ts-oc-age{font-size:12px;color:#aaa;}
.ts-oc-age-urgent{color:#e63946;font-weight:700;}
.ts-oc-phone{font-size:14px;color:#333;margin:3px 0;}
.ts-oc-addr{font-size:13px;color:#555;margin:2px 0;word-break:break-word;}
.ts-oc-driver{font-size:12px;color:#1565c0;margin-top:5px;}
.ts-oc-notes{font-size:12px;color:#888;font-style:italic;margin-top:3px;}
.ts-oc-actions{margin-top:10px;display:flex;flex-wrap:wrap;gap:5px;}
.ts-oc-btn{padding:6px 12px;border:none;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;transition:opacity .15s;}
.ts-oc-btn:disabled{opacity:.5;cursor:default;}
.ts-oc-btn-assign{background:#e63946;color:#fff;}
.ts-oc-btn-arrived{background:#ff9800;color:#fff;}
.ts-oc-btn-intaxi{background:#2196f3;color:#fff;}
.ts-oc-btn-complete{background:#4caf50;color:#fff;}
.ts-oc-btn-cancel{background:#f5f5f5;color:#666;}

/* ====  Форма назначения  ==== */
.ts-assign-form{margin-top:10px;padding-top:10px;border-top:1px solid #eee;display:none;}
.ts-assign-form select,.ts-assign-price-wrap input{width:100%;padding:6px 8px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;margin-bottom:6px;box-sizing:border-box;}
.ts-assign-notify{display:flex;gap:10px;font-size:12px;margin-bottom:8px;flex-wrap:wrap;}
.ts-assign-notify label{display:flex;align-items:center;gap:3px;cursor:pointer;}

/* ====  Модальное окно «Новый заказ»  ==== */
#ts-new-order-modal{display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);align-items:center;justify-content:center;}
#ts-new-order-modal.open{display:flex;}
#ts-nom-card{background:#fff;border-radius:14px;width:100%;max-width:520px;box-shadow:0 8px 40px rgba(0,0,0,.25);overflow:hidden;animation:ts-slide-in .2s ease;}
@keyframes ts-slide-in{from{transform:translateY(-24px);opacity:0;}to{transform:translateY(0);opacity:1;}}
#ts-nom-head{background:#1a1a2e;color:#fff;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;}
#ts-nom-head h3{margin:0;font-size:17px;}
#ts-nom-close{background:none;border:none;color:#fff;font-size:22px;cursor:pointer;line-height:1;padding:0 4px;}
#ts-nom-body{padding:20px;}
.ts-nom-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.ts-nom-grid .full{grid-column:1/-1;}
.ts-nom-label{display:block;font-size:13px;font-weight:600;color:#444;margin-bottom:4px;}
.ts-nom-input{width:100%;padding:9px 12px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;transition:border-color .15s;}
.ts-nom-input:focus{border-color:#e63946;outline:none;}
.ts-phone-row{display:flex;gap:6px;}
.ts-phone-prefix{padding:9px 10px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;background:#f9f9f9;cursor:pointer;}
.ts-phone-prefix:focus{border-color:#e63946;outline:none;}
#ts-nom-foot{display:flex;gap:8px;align-items:center;margin-top:16px;}
#ts-nom-submit{flex:1;padding:11px;background:#e63946;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;}
#ts-nom-submit:disabled{opacity:.6;}
#ts-nom-cancel{padding:11px 16px;border:1.5px solid #ddd;background:#fff;border-radius:8px;font-size:14px;cursor:pointer;}
#ts-nom-msg{font-size:13px;}
</style>

<div class="ts-disp-wrap" id="ts-disp-wrap">

<div class="ts-disp-toolbar">
  <span class="ts-disp-title">🚖 Диспетчер</span>
  <span id="ts-disp-autodispatch-badge" class="ts-autodispatch-badge">⚡ Авто</span>
  <span class="ts-disp-cars-count">
    Свободных: <strong id="ts-cnt-free"><?php echo count($free_cars); ?></strong>
    / Всего: <?php echo count($all_cars); ?>
  </span>
  <button class="ts-oc-btn ts-oc-btn-assign" id="ts-disp-new-order-btn" style="padding:8px 16px;font-size:13px;">＋ Новый заказ</button>
</div>

<!-- ====  Модальное окно нового заказа  ==== -->
<div id="ts-new-order-modal">
  <div id="ts-nom-card">
    <div id="ts-nom-head">
      <h3>📋 Новый заказ</h3>
      <button id="ts-nom-close" title="Закрыть">✕</button>
    </div>
    <div id="ts-nom-body">
      <div class="ts-nom-grid">
        <div>
          <label class="ts-nom-label">Телефон клиента *</label>
          <div class="ts-phone-row">
            <select id="nf-phone-prefix" class="ts-phone-prefix">
              <option value="+375">🇧🇾 +375</option>
              <option value="+7">🇷🇺 +7</option>
            </select>
            <input type="tel" id="nf-phone" class="ts-nom-input" placeholder="291234567" style="flex:1;">
          </div>
        </div>
        <div>
          <label class="ts-nom-label">Имя клиента</label>
          <input type="text" id="nf-name" class="ts-nom-input" placeholder="Иванов И.И.">
        </div>
        <div class="full">
          <label class="ts-nom-label">Адрес подачи *</label>
          <input type="text" id="nf-from" class="ts-nom-input" placeholder="ул. Ленина, 1">
        </div>
        <div class="full">
          <label class="ts-nom-label">Адрес назначения</label>
          <input type="text" id="nf-to" class="ts-nom-input" placeholder="Аэропорт, ж/д вокзал…">
        </div>
        <?php if ( $phone_lines ) : ?>
        <div>
          <label class="ts-nom-label">Телефонная линия</label>
          <select id="nf-phone-line" class="ts-nom-input">
            <option value="">— нет —</option>
            <?php foreach ( $phone_lines as $pl ) : ?>
              <option value="<?php echo (int)$pl->id; ?>"><?php echo esc_html($pl->number.($pl->description?' — '.$pl->description:'')); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>
        <div>
          <label class="ts-nom-label">Примечание</label>
          <input type="text" id="nf-notes" class="ts-nom-input" placeholder="Детское кресло, багаж…">
        </div>
      </div>
      <div id="ts-nom-foot">
        <button id="ts-nom-submit">✅ Создать заказ</button>
        <button id="ts-nom-cancel">Отмена</button>
        <span id="ts-nom-msg"></span>
      </div>
    </div>
  </div>
</div>

<!-- Колонки -->
<div class="ts-disp-columns">

  <div class="ts-disp-col">
    <div class="ts-disp-col-header">
      <span>🆕 Новые</span>
      <span class="ts-disp-count" id="ts-cnt-new"><?php echo count($new_orders); ?></span>
    </div>
    <div class="ts-disp-col-body" id="ts-new-orders">
      <?php foreach ( $new_orders as $o ) ts_disp_order_card( $o, 'new', $all_cars, $all_drivers ); ?>
      <?php if ( !$new_orders ) echo '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Нет новых заказов</p>'; ?>
    </div>
  </div>

  <div class="ts-disp-col">
    <div class="ts-disp-col-header">
      <span>✅ Назначены</span>
      <span class="ts-disp-count" id="ts-cnt-assigned"><?php echo count($assigned); ?></span>
    </div>
    <div class="ts-disp-col-body" id="ts-assigned-orders">
      <?php foreach ( $assigned as $o ) ts_disp_order_card( $o, 'assigned', $all_cars, $all_drivers ); ?>
      <?php if ( !$assigned ) echo '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Пусто</p>'; ?>
    </div>
  </div>

  <div class="ts-disp-col">
    <div class="ts-disp-col-header">
      <span>🚕 В поездке</span>
      <span class="ts-disp-count" id="ts-cnt-progress"><?php echo count($progress); ?></span>
    </div>
    <div class="ts-disp-col-body" id="ts-progress-orders">
      <?php foreach ( $progress as $o ) ts_disp_order_card( $o, $o->status, $all_cars, $all_drivers ); ?>
      <?php if ( !$progress ) echo '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Пусто</p>'; ?>
    </div>
  </div>

</div><!-- /columns -->
</div><!-- /wrap -->

<script>
(function($){
  var ajaxUrl = (typeof TS !== 'undefined') ? TS.ajax_url : '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';
  var nonce   = (typeof TS !== 'undefined') ? TS.nonce    : '<?php echo esc_js( wp_create_nonce( 'ts_nonce' ) ); ?>';
  var autoDispatch = <?php echo get_option('ts_auto_dispatch','0') === '1' ? 'true' : 'false'; ?>;

  if(autoDispatch) $('#ts-disp-autodispatch-badge').show();

  // Флаг: пауза авторефреша когда открыта форма назначения
  var assignFormOpen = false;

  /* ---- Обновление панели каждые 6 секунд ---- */
  function refreshOrders(force){
    // Не обновлять колонки пока открыта форма назначения (иначе форма закроется)
    if(assignFormOpen && !force) return;
    $.post(ajaxUrl, {action:'ts_action', ts_action:'disp_refresh', nonce:nonce}, function(res){
      if(!res || !res.success) return;
      var d = res.data;
      $('#ts-new-orders').html(d.html_new     || '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Нет новых заказов</p>');
      $('#ts-assigned-orders').html(d.html_assigned || '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Пусто</p>');
      $('#ts-progress-orders').html(d.html_progress || '<p style="color:#bbb;padding:20px;text-align:center;font-size:13px;">Пусто</p>');
      $('#ts-cnt-new').text(d.cnt_new);
      $('#ts-cnt-assigned').text(d.cnt_assigned);
      $('#ts-cnt-progress').text(d.cnt_progress);
      $('#ts-cnt-free').text(d.cnt_free);
    });
  }
  setInterval(refreshOrders, 6000);

  /* ---- Модал: открыть / закрыть ---- */
  function openModal(){  $('#ts-new-order-modal').addClass('open'); $('#nf-phone').focus(); }
  function closeModal(){ $('#ts-new-order-modal').removeClass('open'); $('#ts-nom-msg').text(''); }

  $('#ts-disp-new-order-btn').on('click', openModal);
  $('#ts-nom-close, #ts-nom-cancel').on('click', closeModal);
  $('#ts-new-order-modal').on('click', function(e){ if(e.target === this) closeModal(); });
  $(document).on('keydown', function(e){ if(e.key==='Escape') closeModal(); });

  /* ---- Создание заказа ---- */
  $('#ts-nom-submit').on('click', function(){
    var prefix = $('#nf-phone-prefix').val();
    var phoneRaw = $('#nf-phone').val().trim().replace(/^0+/,'');
    var phone = prefix + phoneRaw;
    var from  = $('#nf-from').val().trim();
    if(!phoneRaw || !from){
      $('#ts-nom-msg').css('color','#e63946').text('Укажите телефон и адрес подачи');
      return;
    }
    $(this).prop('disabled',true).text('Создаём…');
    $.post(ajaxUrl, {
      action:'ts_action', ts_action:'create_order', nonce:nonce,
      phone: phone,
      name: $('#nf-name').val().trim(),
      address_from: from,
      address_to: $('#nf-to').val().trim(),
      notes: $('#nf-notes').val().trim(),
      phone_line_id: $('#nf-phone-line').val() || ''
    }, function(res){
      $('#ts-nom-submit').prop('disabled',false).text('✅ Создать заказ');
      if(res && res.success){
        $('#ts-nom-msg').css('color','#4caf50').text('✅ Заказ '+res.data.order_number+' создан!');
        $('#nf-phone,#nf-name,#nf-from,#nf-to,#nf-notes').val('');
        setTimeout(function(){ closeModal(); refreshOrders(); }, 1800);
      } else {
        $('#ts-nom-msg').css('color','#e63946').text('❌ '+(res&&res.data?res.data:'Ошибка'));
      }
    });
  });

  /* ---- Переключить форму назначения ---- */
  $(document).on('click', '.ts-disp-toggle-assign', function(){
    var card = $(this).closest('.ts-order-card');
    var form = card.find('.ts-assign-form');
    form.toggle();
    // Пауза авторефреша пока форма открыта — иначе она закроется через 6 сек
    assignFormOpen = $('.ts-assign-form:visible').length > 0;
  });

  /* ---- Назначить водителя (кнопка внутри формы) ---- */
  $(document).on('click', '.ts-disp-assign-btn', function(){
    var card  = $(this).closest('.ts-order-card');
    var oid   = card.data('id');
    var carId = card.find('.ts-assign-car').val();
    var drvId = card.find('.ts-assign-driver').val();
    var ch    = card.find('input[type="radio"]:checked').val() || 'none';
    var price = card.find('.ts-assign-price').val();
    if(!carId){ alert('Выберите автомобиль'); return; }
    $(this).prop('disabled',true).text('…');
    var btn = this;
    $.post(ajaxUrl, {
      action:'ts_action', ts_action:'assign_order', nonce:nonce,
      order_id:oid, car_id:carId, driver_id:drvId, notify_channel:ch, price:price
    }, function(res){
      $(btn).prop('disabled',false).text('✓ Назначить');
      assignFormOpen = false;
      if(res && res.success){ refreshOrders(true); }
      else { alert('Ошибка назначения: '+(res&&res.data?res.data:'неизвестная ошибка')); }
    });
  });

  /* ---- Прибыл ---- */
  $(document).on('click', '.ts-disp-arrived-btn', function(){
    var oid = $(this).closest('.ts-order-card').data('id');
    var btn = this;
    $(btn).prop('disabled',true).text('…');
    $.post(ajaxUrl, {action:'ts_action', ts_action:'set_driver_status', order_id:oid, status:'arrived', nonce:nonce}, function(res){
      $(btn).prop('disabled',false).text('🅿 Прибыл');
      if(res && res.success){ refreshOrders(); }
      else { alert('Ошибка смены статуса'); }
    });
  });

  /* ---- В такси ---- */
  $(document).on('click', '.ts-disp-intaxi-btn', function(){
    var oid = $(this).closest('.ts-order-card').data('id');
    var btn = this;
    $(btn).prop('disabled',true).text('…');
    $.post(ajaxUrl, {action:'ts_action', ts_action:'set_driver_status', order_id:oid, status:'in_progress', nonce:nonce}, function(res){
      $(btn).prop('disabled',false).text('🚕 В такси');
      if(res && res.success){ refreshOrders(); }
      else { alert('Ошибка смены статуса'); }
    });
  });

  /* ---- Завершить ---- */
  $(document).on('click', '.ts-disp-complete-btn', function(){
    var oid = $(this).closest('.ts-order-card').data('id');
    var btn = this;
    $(btn).prop('disabled',true).text('…');
    $.post(ajaxUrl, {action:'ts_action', ts_action:'set_driver_status', order_id:oid, status:'completed', nonce:nonce}, function(res){
      $(btn).prop('disabled',false).text('✅ Завершить');
      if(res && res.success){ refreshOrders(); }
      else { alert('Ошибка'); }
    });
  });

  /* ---- Отменить ---- */
  $(document).on('click', '.ts-disp-cancel-btn', function(){
    if(!confirm('Отменить заказ?')) return;
    var oid = $(this).closest('.ts-order-card').data('id');
    var btn = this;
    $(btn).prop('disabled',true).text('…');
    $.post(ajaxUrl, {action:'ts_action', ts_action:'cancel_order', order_id:oid, nonce:nonce}, function(res){
      $(btn).prop('disabled',false).text('✕');
      if(res && res.success){ refreshOrders(); }
    });
  });

})(jQuery);
</script>
