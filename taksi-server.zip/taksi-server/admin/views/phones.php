<?php if ( ! defined( 'ABSPATH' ) ) exit;
$action = sanitize_key( $_GET['action'] ?? 'list' );
$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
$saved  = ! empty( $_GET['saved'] );
$item   = $id ? TS_Phones::get( $id ) : null;
?>
<div class="wrap ts-wrap">
<h1>☎ Телефонные линии <a href="<?php echo admin_url( 'admin.php?page=ts-phones&action=new' ); ?>" class="page-title-action">+ Добавить</a></h1>
<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>✅ Сохранено.</p></div><?php endif; ?>
<?php if ( $action === 'list' ) :
  $items = TS_Phones::get_all();
?>
<table class="ts-table widefat">
<thead><tr><th>Номер</th><th>Описание</th><th>Тип</th><th>Статус</th><th></th></tr></thead>
<tbody>
<?php if ( $items ) : foreach ( $items as $p ) : ?>
<tr>
  <td><strong><?php echo esc_html( $p->number ); ?></strong></td>
  <td><?php echo esc_html( $p->description ); ?></td>
  <td><?php echo esc_html( $p->type ); ?></td>
  <td><span class="ts-badge ts-badge-<?php echo esc_attr( $p->status ); ?>"><?php echo $p->status === 'active' ? 'Активна' : 'Отключена'; ?></span></td>
  <td>
    <a href="<?php echo admin_url( 'admin.php?page=ts-phones&action=edit&id=' . $p->id ); ?>" class="button button-small">Ред.</a>
    <button class="button button-small ts-delete" data-entity="phone" data-id="<?php echo esc_attr( $p->id ); ?>">Удалить</button>
  </td>
</tr>
<?php endforeach; else : ?>
  <tr><td colspan="5" class="ts-empty">Нет телефонных линий.</td></tr>
<?php endif; ?>
</tbody>
</table>
<?php else : ?>
<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
  <input type="hidden" name="action" value="ts_save">
  <input type="hidden" name="entity" value="phone">
  <input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
  <?php wp_nonce_field( 'ts_save' ); ?>
  <h2><?php echo $id ? 'Редактировать линию' : 'Добавить телефонную линию'; ?></h2>
  <table class="form-table">
    <tr><th>Номер *</th><td><input type="text" name="number" required class="regular-text" value="<?php echo esc_attr( $item->number ?? '' ); ?>"></td></tr>
    <tr><th>Описание</th><td><input type="text" name="description" class="regular-text" value="<?php echo esc_attr( $item->description ?? '' ); ?>"></td></tr>
    <tr>
      <th>Тип</th>
      <td>
        <select name="type">
          <?php foreach ( array( 'mobile' => 'Мобильный', 'landline' => 'Городской', 'voip' => 'VoIP', 'modem' => 'Модем', 'other' => 'Другое' ) as $v => $l ) : ?>
          <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $item->type ?? 'mobile', $v ); ?>><?php echo esc_html( $l ); ?></option>
          <?php endforeach; ?>
        </select>
      </td>
    </tr>
    <tr>
      <th>Статус</th>
      <td>
        <select name="status">
          <option value="active"   <?php selected( $item->status ?? 'active', 'active' );   ?>>Активна</option>
          <option value="inactive" <?php selected( $item->status ?? '', 'inactive' ); ?>>Отключена</option>
        </select>
      </td>
    </tr>
    <tr><th>Примечание</th><td><textarea name="notes" class="large-text" rows="3"><?php echo esc_textarea( $item->notes ?? '' ); ?></textarea></td></tr>
  </table>
  <p>
    <button type="submit" class="button button-primary">Сохранить</button>
    <a href="<?php echo admin_url( 'admin.php?page=ts-phones' ); ?>" class="button">Отмена</a>
  </p>
</form>
<?php endif; ?>
</div>
