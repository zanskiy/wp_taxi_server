<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Admin {

    public function __construct() {
        add_action( 'admin_menu',            array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
        add_action( 'wp_enqueue_scripts',    array( $this, 'enqueue_frontend' ) );
        add_action( 'admin_post_ts_save',    array( $this, 'handle_save' ) );
        add_action( 'wp_ajax_ts_action',         array( $this, 'handle_ajax' ) );
        add_action( 'wp_ajax_nopriv_ts_action',  array( $this, 'handle_ajax_public' ) );
        add_action( 'admin_post_ts_export',  array( $this, 'handle_export' ) );

        add_shortcode( 'taksi_order_form',      array( $this, 'shortcode_order_form' ) );
        add_shortcode( 'taksi_driver_app',      array( $this, 'shortcode_driver_app' ) );
        add_shortcode( 'taksi_driver_register', array( $this, 'shortcode_driver_register' ) );
        add_shortcode( 'taksi_dispatcher',      array( $this, 'shortcode_dispatcher' ) );
        add_shortcode( 'taksi_director',        array( $this, 'shortcode_director' ) );
    }

    public function register_menu() {
        add_menu_page( 'Такси Сервер', 'Такси Сервер', 'manage_options', 'taksi-server',
            array( $this, 'page_dashboard' ), 'dashicons-car', 30 );
        add_submenu_page( 'taksi-server', 'Панель',           'Панель',     'manage_options', 'taksi-server',       array( $this, 'page_dashboard' ) );
        add_submenu_page( 'taksi-server', 'Диспетчер',        'Диспетчер',  'manage_options', 'ts-dispatcher',      array( $this, 'page_dispatcher' ) );
        add_submenu_page( 'taksi-server', 'Директор',         'Директор',   'manage_options', 'ts-director',        array( $this, 'page_director' ) );
        add_submenu_page( 'taksi-server', 'Заказы',           'Заказы',     'manage_options', 'ts-orders',          array( $this, 'page_orders' ) );
        add_submenu_page( 'taksi-server', 'Автомобили',       'Автомобили', 'manage_options', 'ts-cars',            array( $this, 'page_cars' ) );
        add_submenu_page( 'taksi-server', 'Водители',         'Водители',   'manage_options', 'ts-drivers',         array( $this, 'page_drivers' ) );
        add_submenu_page( 'taksi-server', 'Диспетчеры',       'Диспетчеры', 'manage_options', 'ts-dispatchers',     array( $this, 'page_dispatchers' ) );
        add_submenu_page( 'taksi-server', 'Телефонные линии', 'Телефоны',   'manage_options', 'ts-phones',          array( $this, 'page_phones' ) );
        add_submenu_page( 'taksi-server', 'Отчёты',           'Отчёты',     'manage_options', 'ts-reports',         array( $this, 'page_reports' ) );
        add_submenu_page( 'taksi-server', 'Настройки',        'Настройки',  'manage_options', 'ts-settings',        array( $this, 'page_settings' ) );
        add_submenu_page( 'taksi-server', 'Подключение',      'Подключение','manage_options', 'ts-connection',      array( $this, 'page_connection' ) );
    }

    /* ------------------------------------------------------------------ */
    /*  ENQUEUE                                                             */
    /* ------------------------------------------------------------------ */

    private function ts_script_data() {
        return array(
            'ajax_url'   => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'ts_nonce' ),
            'api_base'   => rest_url( 'taksi-server/v1' ),
            'server_url' => home_url(),
        );
    }

    public function enqueue_admin( $hook ) {
        if ( strpos( $hook, 'taksi' ) === false && strpos( $hook, 'ts-' ) === false ) return;
        wp_enqueue_style(  'ts-admin', TS_PLUGIN_URL . 'assets/css/admin.css', array(), TS_VERSION );
        wp_enqueue_script( 'ts-admin', TS_PLUGIN_URL . 'assets/js/admin.js',   array( 'jquery' ), TS_VERSION, true );
        wp_localize_script( 'ts-admin', 'TS', $this->ts_script_data() );
    }

    public function enqueue_frontend() {
        wp_enqueue_style(  'ts-admin', TS_PLUGIN_URL . 'assets/css/admin.css', array(), TS_VERSION );
        wp_enqueue_script( 'ts-admin', TS_PLUGIN_URL . 'assets/js/admin.js',   array( 'jquery' ), TS_VERSION, true );
        wp_localize_script( 'ts-admin', 'TS', $this->ts_script_data() );
    }

    /* ------------------------------------------------------------------ */
    /*  ADMIN PAGES                                                         */
    /* ------------------------------------------------------------------ */

    public function page_dashboard()   { include TS_PLUGIN_DIR . 'admin/views/dashboard.php'; }
    public function page_dispatcher()  { include TS_PLUGIN_DIR . 'admin/views/dispatcher.php'; }
    public function page_director()    { include TS_PLUGIN_DIR . 'admin/views/director.php'; }
    public function page_orders()      { include TS_PLUGIN_DIR . 'admin/views/orders.php'; }
    public function page_cars()        { include TS_PLUGIN_DIR . 'admin/views/cars.php'; }
    public function page_drivers()     { include TS_PLUGIN_DIR . 'admin/views/drivers.php'; }
    public function page_dispatchers() { include TS_PLUGIN_DIR . 'admin/views/dispatchers.php'; }
    public function page_phones()      { include TS_PLUGIN_DIR . 'admin/views/phones.php'; }
    public function page_reports()     { include TS_PLUGIN_DIR . 'admin/views/reports.php'; }
    public function page_settings()    { include TS_PLUGIN_DIR . 'admin/views/settings.php'; }
    public function page_connection()  { include TS_PLUGIN_DIR . 'admin/views/connection.php'; }

    /* ------------------------------------------------------------------ */
    /*  SHORTCODES                                                          */
    /* ------------------------------------------------------------------ */

    public function shortcode_order_form( $atts ) {
        ob_start(); include TS_PLUGIN_DIR . 'admin/views/client-form.php'; return ob_get_clean();
    }

    public function shortcode_driver_app( $atts ) {
        ob_start(); include TS_PLUGIN_DIR . 'admin/views/driver-app.php'; return ob_get_clean();
    }

    public function shortcode_driver_register( $atts ) {
        ob_start(); include TS_PLUGIN_DIR . 'admin/views/driver-register.php'; return ob_get_clean();
    }

    public function shortcode_dispatcher( $atts ) {
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'ts_dispatcher' ) ) {
            return '<p style="color:red;">Нет доступа. Войдите как диспетчер.</p>';
        }
        ob_start(); include TS_PLUGIN_DIR . 'admin/views/dispatcher.php'; return ob_get_clean();
    }

    public function shortcode_director( $atts ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return '<p style="color:red;">Нет доступа.</p>';
        }
        wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', array(), '4.4.0', true );
        ob_start(); include TS_PLUGIN_DIR . 'admin/views/director.php'; return ob_get_clean();
    }

    /* ------------------------------------------------------------------ */
    /*  SAVE (admin-post)                                                   */
    /* ------------------------------------------------------------------ */

    public function handle_save() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Нет доступа' );
        check_admin_referer( 'ts_save' );

        $entity = sanitize_key( $_POST['entity'] ?? '' );
        $id     = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;

        if ( $entity === 'settings' ) {
            $opts = array(
                'ts_company_name','ts_company_phone','ts_driver_secret','ts_tcp_port',
                'ts_telegram_driver_bot_token','ts_telegram_client_bot_token',
                'ts_viber_bot_token','ts_max_bot_token',
                'ts_sms_login','ts_sms_password',
                'ts_driver_notify_channel','ts_client_notify_channel',
                'ts_maps_api_key',
                'ts_auto_dispatch_timeout',
            );
            foreach ( $opts as $key ) {
                if ( isset( $_POST[ $key ] ) ) {
                    update_option( $key, sanitize_text_field( $_POST[ $key ] ) );
                }
            }
            update_option( 'ts_auto_dispatch', isset( $_POST['ts_auto_dispatch'] ) ? '1' : '0' );

            // Новая настройка — комиссия по умолчанию для водителей
            if ( isset( $_POST['ts_default_commission_pct'] ) ) {
                update_option( 'ts_default_commission_pct', (float) $_POST['ts_default_commission_pct'] );
            }

            wp_redirect( admin_url( 'admin.php?page=ts-settings&saved=1' ) );
            exit;
        }

        $map = array(
            'order'      => array( 'class' => 'TS_Orders',      'fields' => array( 'client_name','client_phone','client_tg_id','address_from','address_to','status','car_id','driver_id','dispatcher_id','phone_line_id','price','distance_km','notes' ) ),
            'car'        => array( 'class' => 'TS_Cars',        'fields' => array( 'callsign','plate','model','color','driver_id','status','phone','notes' ) ),
            'driver'     => array( 'class' => 'TS_Drivers',     'fields' => array( 'name','callsign','phone','license','status','telegram_chat_id','viber_id','max_id','payment_type','notes' ) ),
            'dispatcher' => array( 'class' => 'TS_Dispatchers', 'fields' => array( 'name','login','email','phone','status','notes' ) ),
            'phone'      => array( 'class' => 'TS_Phones',      'fields' => array( 'number','description','type','status','notes' ) ),
        );

        if ( ! isset( $map[ $entity ] ) ) {
            wp_redirect( admin_url( 'admin.php?page=taksi-server&error=unknown_entity' ) );
            exit;
        }

        $cfg  = $map[ $entity ];
        $data = array();
        foreach ( $cfg['fields'] as $f ) {
            if ( isset( $_POST[ $f ] ) ) {
                $data[ $f ] = sanitize_text_field( $_POST[ $f ] );
            }
        }
        foreach ( array( 'notes','address_from','address_to' ) as $ta ) {
            if ( isset( $_POST[ $ta ] ) ) {
                $data[ $ta ] = sanitize_textarea_field( $_POST[ $ta ] );
            }
        }

        // Числовые поля оплаты водителя
        if ( $entity === 'driver' ) {
            if ( isset( $_POST['commission_pct'] ) ) {
                $data['commission_pct'] = round( (float) $_POST['commission_pct'], 2 );
            }
            if ( isset( $_POST['subscription_fee'] ) ) {
                $data['subscription_fee'] = round( (float) $_POST['subscription_fee'], 2 );
            }
        }

        // waypoints JSON
        if ( $entity === 'order' && ! empty( $_POST['waypoints'] ) ) {
            $wps = array_filter( array_map( 'sanitize_text_field', (array) $_POST['waypoints'] ) );
            $data['waypoints'] = wp_json_encode( array_values( $wps ) );
        }

        $class = $cfg['class'];
        if ( $id ) {
            $class::update( $id, $data );
            $new_record_id = $id;
        } else {
            $new_record_id = $class::create( $data );
        }

        if ( $entity === 'dispatcher' && ! $id && ! empty( $_POST['create_wp_user'] ) && $new_record_id ) {
            $password = ! empty( $_POST['wp_password'] ) ? sanitize_text_field( $_POST['wp_password'] ) : '';
            $email    = ! empty( $data['email'] )        ? $data['email']                               : '';
            $result   = TS_Dispatchers::create_wp_account( $new_record_id, $email, $password );
            if ( ! is_wp_error( $result ) ) {
                set_transient( 'ts_disp_new_creds_' . get_current_user_id(), $result, 60 );
            }
        }

        $redirect = $entity === 'order' ? 'ts-orders' : "ts-{$entity}s";
        wp_redirect( admin_url( "admin.php?page={$redirect}&saved=1" ) );
        exit;
    }

    /* ------------------------------------------------------------------ */
    /*  EXPORT                                                              */
    /* ------------------------------------------------------------------ */

    public function handle_export() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Нет доступа' );
        check_admin_referer( 'ts_export' );

        $format    = sanitize_key( $_GET['format'] ?? 'excel' );
        $date_from = sanitize_text_field( $_GET['date_from'] ?? date( 'Y-m-01' ) );
        $date_to   = sanitize_text_field( $_GET['date_to']   ?? date( 'Y-m-d' ) );

        if ( $format === 'earnings_csv' ) {
            TS_Reports::export_earnings_csv( $date_from, $date_to );
        } elseif ( $format === 'csv' ) {
            TS_Reports::export_csv( $date_from, $date_to );
        } else {
            TS_Reports::export_excel( $date_from, $date_to );
        }
    }

    /* ------------------------------------------------------------------ */
    /*  AJAX — авторизованные                                               */
    /* ------------------------------------------------------------------ */

    public function handle_ajax() {
        check_ajax_referer( 'ts_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'ts_dispatcher' ) ) {
            wp_send_json_error( 'no_access' );
        }

        $action = sanitize_key( $_POST['ts_action'] ?? '' );

        switch ( $action ) {

            case 'delete':
                $entity = sanitize_key( $_POST['entity'] ?? '' );
                $id     = (int) ( $_POST['id'] ?? 0 );
                $map    = array( 'order' => 'TS_Orders', 'car' => 'TS_Cars', 'driver' => 'TS_Drivers', 'dispatcher' => 'TS_Dispatchers', 'phone' => 'TS_Phones' );
                if ( ! isset( $map[ $entity ] ) || ! $id ) wp_send_json_error( 'bad_params' );
                $map[ $entity ]::delete( $id );
                wp_send_json_success();
                break;

            case 'get_stats':
                wp_send_json_success( array(
                    'cars'   => TS_Cars::count_by_status(),
                    'orders' => TS_Orders::today_stats(),
                ) );
                break;

            case 'create_order':
                $phone = sanitize_text_field( $_POST['phone']        ?? '' );
                $from  = sanitize_text_field( $_POST['address_from'] ?? '' );
                if ( ! $phone || ! $from ) {
                    wp_send_json_error( 'Укажите телефон и адрес подачи' );
                }

                $waypoints = array();
                if ( ! empty( $_POST['waypoints'] ) && is_array( $_POST['waypoints'] ) ) {
                    $waypoints = array_filter( array_map( 'sanitize_text_field', $_POST['waypoints'] ) );
                    $waypoints = array_values( $waypoints );
                }

                $data = array(
                    'client_phone' => $phone,
                    'client_name'  => sanitize_text_field( $_POST['name']         ?? '' ),
                    'address_from' => $from,
                    'address_to'   => sanitize_text_field( $_POST['address_to']   ?? '' ),
                    'notes'        => sanitize_textarea_field( $_POST['notes']    ?? '' ),
                    'phone_line_id'=> ! empty( $_POST['phone_line_id'] ) ? (int) $_POST['phone_line_id'] : null,
                    'status'       => 'new',
                    'waypoints'    => ! empty( $waypoints ) ? wp_json_encode( $waypoints ) : null,
                );

                $data['order_number'] = 'TS-' . date( 'Ymd' ) . '-' . strtoupper( substr( uniqid(), -4 ) );

                $id = TS_Orders::create( $data );
                if ( ! $id ) {
                    global $wpdb;
                    $db_err = $wpdb->last_error ? ' (' . $wpdb->last_error . ')' : '';
                    wp_send_json_error( 'Ошибка создания заказа' . $db_err );
                }

                $order = TS_Orders::get( $id );
                wp_send_json_success( array(
                    'order_id'     => $id,
                    'order_number' => $order ? $order->order_number : $data['order_number'],
                ) );
                break;

            case 'assign_order':
                $oid     = (int) ( $_POST['order_id']  ?? 0 );
                $car_id  = (int) ( $_POST['car_id']    ?? 0 );
                $drv_id  = (int) ( $_POST['driver_id'] ?? 0 );
                $channel = sanitize_key( $_POST['notify_channel'] ?? 'none' );
                $price   = ! empty( $_POST['price'] ) ? (float) $_POST['price'] : null;

                if ( ! $oid || ! $car_id ) wp_send_json_error( 'bad_params' );

                $update = array( 'car_id' => $car_id, 'driver_id' => $drv_id ?: null, 'status' => 'assigned' );
                if ( $price !== null ) $update['price'] = $price;
                TS_Orders::update( $oid, $update );

                global $wpdb;
                $wpdb->update( TS_Database::table( 'cars' ), array( 'status' => 'busy' ), array( 'id' => $car_id ) );

                $notified = false;
                if ( $channel !== 'none' && $drv_id ) {
                    $order = TS_Orders::get( $oid );
                    update_option( 'ts_driver_notify_channel', $channel );
                    $result   = TS_Notifications::notify_driver( $drv_id, $order );
                    $notified = is_array( $result ) && ! empty( $result['ok'] );
                }

                $order = TS_Orders::get( $oid );
                if ( $order ) TS_Notifications::notify_client( $order );

                wp_send_json_success( array( 'notified' => $notified ) );
                break;

            case 'cancel_order':
                $oid = (int) ( $_POST['order_id'] ?? 0 );
                if ( ! $oid ) wp_send_json_error( 'bad_params' );
                TS_Orders::update( $oid, array( 'status' => 'cancelled' ) );
                $order = TS_Orders::get( $oid );
                if ( $order ) TS_Notifications::notify_client( $order );
                wp_send_json_success();
                break;

            case 'set_driver_status':
                $oid     = (int) ( $_POST['order_id'] ?? 0 );
                $status  = sanitize_key( $_POST['status'] ?? '' );
                $allowed = array( 'arrived', 'in_progress', 'completed' );
                if ( ! $oid || ! in_array( $status, $allowed, true ) ) wp_send_json_error( 'bad_params' );

                $update = array( 'status' => $status );
                if ( $status === 'arrived' )     $update['arrived_at']   = current_time( 'mysql' );
                if ( $status === 'in_progress' ) $update['accepted_at']  = current_time( 'mysql' );
                if ( $status === 'completed' )   $update['completed_at'] = current_time( 'mysql' );
                TS_Orders::update( $oid, $update );

                $order = TS_Orders::get( $oid );
                if ( $order ) {
                    TS_Notifications::notify_client( $order );
                    if ( $order->driver_id ) {
                        TS_Notifications::notify_driver_status_change( $order->driver_id, $order, $status );
                    }
                    if ( $status === 'completed' && $order->car_id ) {
                        TS_Cars::update( $order->car_id, array( 'status' => 'free' ) );
                    }
                }
                wp_send_json_success();
                break;

            case 'approve_driver':
                if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'no_access' );
                $id = (int) ( $_POST['driver_id'] ?? 0 );
                if ( ! $id ) wp_send_json_error( 'bad_params' );
                TS_Drivers::update( $id, array( 'status' => 'active' ) );
                wp_send_json_success();
                break;

            case 'disp_refresh':
                /* Авто-распределение перед рендером */
                $auto_assigned = TS_AutoDispatch::run();

                $new_orders = TS_Orders::get_all( array( 'status' => 'new',                              'limit' => 200 ) );
                $assigned   = TS_Orders::get_all( array( 'status' => 'assigned',                         'limit' => 200 ) );
                $progress   = TS_Orders::get_all( array( 'status' => array( 'in_progress', 'arrived' ),  'limit' => 200 ) );

                /* Загружаем машины и водителей для форм назначения */
                global $wpdb;
                $rf_all_cars    = $wpdb->get_results( "SELECT * FROM " . TS_Database::table( 'cars' )    . " ORDER BY callsign" );
                $rf_all_drivers = $wpdb->get_results( "SELECT * FROM " . TS_Database::table( 'drivers' ) . " ORDER BY name" );

                ob_start();
                foreach ( $new_orders as $o ) ts_disp_order_card( $o, 'new', $rf_all_cars, $rf_all_drivers );
                $html_new = ob_get_clean();

                ob_start();
                foreach ( $assigned as $o ) ts_disp_order_card( $o, 'assigned', $rf_all_cars, $rf_all_drivers );
                $html_assigned = ob_get_clean();

                ob_start();
                // ИСПРАВЛЕНИЕ: передаём реальный статус заказа ($o->status), а не
                // название колонки. Это позволяет показывать правильные кнопки
                // (Прибыл / В такси / Завершить) в зависимости от статуса.
                foreach ( $progress as $o ) ts_disp_order_card( $o, $o->status, $rf_all_cars, $rf_all_drivers );
                $html_progress = ob_get_clean();

                $cnt_free = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . TS_Database::table( 'cars' ) . " WHERE status='free'" );

                wp_send_json_success( array(
                    'cnt_new'          => count( $new_orders ),
                    'cnt_assigned'     => count( $assigned ),
                    'cnt_progress'     => count( $progress ),
                    'cnt_free'         => $cnt_free,
                    'html_new'         => $html_new      ?: '<div class="ts-disp-empty">Нет новых заказов</div>',
                    'html_assigned'    => $html_assigned ?: '<div class="ts-disp-empty">Нет</div>',
                    'html_progress'    => $html_progress ?: '<div class="ts-disp-empty">Нет</div>',
                    'auto_assigned'    => $auto_assigned,
                    'auto_dispatch_on' => (bool) get_option( 'ts_auto_dispatch', '0' ),
                ) );
                break;

            case 'cars_map':
                $cars = TS_Cars::get_with_location();
                wp_send_json_success( array( 'cars' => $cars ) );
                break;

            case 'notify_test':
                if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'no_access' );
                $channel   = sanitize_key( $_POST['channel']   ?? '' );
                $recipient = sanitize_text_field( $_POST['recipient'] ?? '' );
                $result    = TS_Notifications::test_send( $channel, $recipient );
                wp_send_json( $result );
                break;

            case 'recreate_tables':
                if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'no_access' );
                TS_Database::install();
                global $wpdb;
                $err = $wpdb->last_error;
                if ( $err ) {
                    wp_send_json_error( 'Ошибка БД: ' . $err );
                }
                wp_send_json_success( array( 'message' => 'Таблицы успешно созданы/обновлены.' ) );
                break;

            case 'create_dispatcher_wp':
                if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'no_access' );
                $disp_id  = (int) ( $_POST['dispatcher_id'] ?? 0 );
                $email    = sanitize_email( $_POST['email'] ?? '' );
                $password = sanitize_text_field( $_POST['wp_password'] ?? '' );
                if ( ! $disp_id ) wp_send_json_error( 'bad_params' );

                $result = TS_Dispatchers::create_wp_account( $disp_id, $email, $password );
                if ( is_wp_error( $result ) ) {
                    wp_send_json_error( $result->get_error_message() );
                }
                set_transient( 'ts_disp_new_creds_' . get_current_user_id(), $result, 60 );
                wp_send_json_success( array( 'login' => $result['login'] ) );
                break;

            case 'revoke_dispatcher_wp':
                if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'no_access' );
                $disp_id = (int) ( $_POST['dispatcher_id'] ?? 0 );
                if ( ! $disp_id ) wp_send_json_error( 'bad_params' );
                $ok = TS_Dispatchers::revoke_wp_access( $disp_id );
                if ( $ok ) {
                    wp_send_json_success();
                } else {
                    wp_send_json_error( 'WP-аккаунт не найден или не привязан' );
                }
                break;

            default:
                wp_send_json_error( 'unknown_action' );
        }
    }

    /* ------------------------------------------------------------------ */
    /*  AJAX — публичные                                                    */
    /* ------------------------------------------------------------------ */

    public function handle_ajax_public() {
        check_ajax_referer( 'ts_nonce', 'nonce' );

        $action = sanitize_key( $_POST['ts_action'] ?? '' );
        $public_actions = array( 'driver_login', 'driver_update_status', 'driver_update_location', 'driver_register', 'client_order' );

        if ( ! in_array( $action, $public_actions, true ) ) {
            wp_send_json_error( 'forbidden' );
        }

        switch ( $action ) {

            case 'client_order':
                $phone = sanitize_text_field( $_POST['phone'] ?? '' );
                $from  = sanitize_text_field( $_POST['address_from'] ?? '' );
                if ( ! $phone || ! $from ) wp_send_json_error( 'Укажите телефон и адрес' );

                $waypoints = array();
                if ( ! empty( $_POST['waypoints'] ) && is_array( $_POST['waypoints'] ) ) {
                    $waypoints = array_filter( array_map( 'sanitize_text_field', $_POST['waypoints'] ) );
                    $waypoints = array_values( $waypoints );
                }

                $data = array(
                    'client_phone'  => $phone,
                    'client_name'   => sanitize_text_field( $_POST['name'] ?? '' ),
                    'address_from'  => $from,
                    'address_to'    => sanitize_text_field( $_POST['address_to'] ?? '' ),
                    'notes'         => sanitize_textarea_field( $_POST['notes'] ?? '' ),
                    'status'        => 'new',
                    'order_number'  => 'TS-' . date( 'Ymd' ) . '-' . strtoupper( substr( uniqid(), -4 ) ),
                    'waypoints'     => ! empty( $waypoints ) ? wp_json_encode( $waypoints ) : null,
                );
                $id = TS_Orders::create( $data );
                if ( ! $id ) wp_send_json_error( 'db_error' );
                $order = TS_Orders::get( $id );
                wp_send_json_success( array( 'order_number' => $order ? $order->order_number : $data['order_number'] ) );
                break;

            case 'driver_register':
                $name     = sanitize_text_field( $_POST['name']     ?? '' );
                $phone    = sanitize_text_field( $_POST['phone']    ?? '' );
                $callsign = sanitize_text_field( $_POST['callsign'] ?? '' );
                if ( ! $name || ! $phone ) wp_send_json_error( 'Укажите имя и телефон' );

                $id = TS_Drivers::create( array(
                    'name'     => $name,
                    'phone'    => $phone,
                    'callsign' => $callsign,
                    'license'  => sanitize_text_field( $_POST['license'] ?? '' ),
                    'status'   => 'pending',
                ) );
                wp_send_json( array( 'ok' => (bool) $id ) );
                break;

            default:
                wp_send_json_error( 'not_implemented' );
        }
    }
}

/* ================================================================== */
/*  Helper: render one order card for dispatcher panel                 */
/*  ИСПРАВЛЕНИЕ: $status — реальный статус заказа ($o->status),        */
/*  а не имя колонки. Кнопки определяются по нему.                    */
/* ================================================================== */
if ( ! function_exists( 'ts_disp_order_card' ) ) {
    function ts_disp_order_card( $o, $status, $all_cars = null, $all_drivers = null ) {
        // Используем реальный статус объекта если возможно
        $real_status = ! empty( $o->status ) ? $o->status : $status;

        $age     = round( ( time() - strtotime( $o->created_at ) ) / 60 );
        $age_str = $age < 60 ? $age . ' мин' : round( $age / 60, 1 ) . ' ч';
        $urgent  = $age > 15 && $real_status === 'new' ? 'ts-card-urgent' : '';

        $wps = '';
        if ( ! empty( $o->waypoints ) ) {
            $wpa = json_decode( $o->waypoints, true );
            if ( is_array( $wpa ) && ! empty( $wpa ) ) {
                $wps = '<div class="ts-oc-addr ts-oc-waypoints">🔀 ' . esc_html( implode( ' → ', $wpa ) ) . '</div>';
            }
        }
        ?>
        <div class="ts-order-card <?php echo esc_attr( $urgent ); ?>"
             data-id="<?php echo esc_attr( $o->id ); ?>"
             data-num="<?php echo esc_attr( $o->order_number ); ?>"
             data-from="<?php echo esc_attr( $o->address_from ); ?>"
             data-to="<?php echo esc_attr( $o->address_to ); ?>"
             data-phone="<?php echo esc_attr( $o->client_phone ); ?>"
             data-name="<?php echo esc_attr( $o->client_name ); ?>">
          <div class="ts-oc-top">
            <span class="ts-oc-num"><?php echo esc_html( $o->order_number ); ?></span>
            <span class="ts-oc-age <?php echo ( $age > 15 && $real_status === 'new' ) ? 'ts-oc-age-urgent' : ''; ?>"><?php echo esc_html( $age_str ); ?></span>
          </div>
          <div class="ts-oc-phone">📞 <?php echo esc_html( $o->client_phone ); ?><?php if ( $o->client_name ) echo ' · ' . esc_html( $o->client_name ); ?></div>
          <div class="ts-oc-addr">📍 <?php echo esc_html( $o->address_from ); ?></div>
          <?php if ( $o->address_to ) : ?>
            <div class="ts-oc-addr ts-oc-to">🏁 <?php echo esc_html( $o->address_to ); ?></div>
          <?php endif; ?>
          <?php echo $wps; ?>
          <?php if ( ! empty( $o->driver_name ) ) : ?>
            <div class="ts-oc-driver">🧑‍✈️ <?php echo esc_html( $o->driver_name ); ?><?php if ( ! empty( $o->car_callsign ) ) echo ' (' . esc_html( $o->car_callsign ) . ')'; ?></div>
          <?php endif; ?>
          <?php if ( $o->notes ) : ?>
            <div class="ts-oc-notes">💬 <?php echo esc_html( $o->notes ); ?></div>
          <?php endif; ?>

          <div class="ts-oc-actions">

            <?php if ( $real_status === 'new' ) : ?>
              <button class="ts-oc-btn ts-oc-btn-assign ts-disp-toggle-assign">Назначить →</button>
            <?php endif; ?>

          </div><!-- /actions -->

          <?php if ( $real_status === 'new' && $all_cars ) : ?>
          <div class="ts-assign-form" style="display:none;margin-top:10px;padding-top:10px;border-top:1px solid #eee;">
            <select class="ts-assign-car" style="width:100%;padding:7px 8px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;margin-bottom:6px;box-sizing:border-box;">
              <option value="">— Выберите автомобиль —</option>
              <?php foreach ( (array) $all_cars as $c ) :
                $c_label = $c->callsign . ' ';
                $c_color = '';
                switch ( $c->status ) {
                    case 'free':    $c_label .= '(свободен)'; $c_color = '';               break;
                    case 'busy':    $c_label .= '(занят)';    $c_color = 'color:#e65100;'; break;
                    case 'offline': $c_label .= '(офлайн)';   $c_color = 'color:#999;';    break;
                    default:        $c_label .= '(' . esc_html( $c->status ) . ')';         break;
                }
              ?>
                <option value="<?php echo (int) $c->id; ?>" style="<?php echo $c_color; ?>"><?php echo esc_html( $c_label ); ?></option>
              <?php endforeach; ?>
            </select>

            <?php if ( $all_drivers ) : ?>
            <select class="ts-assign-driver" style="width:100%;padding:7px 8px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;margin-bottom:6px;box-sizing:border-box;">
              <option value="">— Водитель (необяз.) —</option>
              <?php foreach ( (array) $all_drivers as $d ) : ?>
              <option value="<?php echo (int) $d->id; ?>"><?php echo esc_html( $d->name . ' (' . $d->callsign . ')' ); ?></option>
              <?php endforeach; ?>
            </select>
            <?php endif; ?>

            <div style="display:flex;gap:6px;margin-bottom:8px;">
              <input type="number" class="ts-assign-price" placeholder="Цена (BYN)" min="0" step="0.01"
                style="flex:1;padding:7px 8px;border:1.5px solid #ddd;border-radius:7px;font-size:13px;box-sizing:border-box;">
            </div>

            <div style="font-size:12px;color:#666;margin-bottom:7px;display:flex;gap:12px;flex-wrap:wrap;">
              <label style="cursor:pointer;"><input type="radio" name="notify_channel_<?php echo (int)$o->id; ?>" value="none" checked> Без уведомления</label>
              <label style="cursor:pointer;"><input type="radio" name="notify_channel_<?php echo (int)$o->id; ?>" value="telegram"> Telegram</label>
            </div>

            <div style="display:flex;gap:6px;">
              <button class="ts-oc-btn ts-oc-btn-assign ts-disp-assign-btn" style="flex:1;">✓ Назначить</button>
              <button class="ts-oc-btn ts-oc-btn-cancel ts-disp-toggle-assign" style="flex:0;">✕</button>
            </div>
          </div><!-- /assign-form -->
          <?php endif; ?>

          <div class="ts-oc-actions" style="margin-top:<?php echo $real_status === 'new' ? '0' : '10px'; ?>;display:<?php echo $real_status === 'new' ? 'none' : 'flex'; ?>;"
               id="ts-oc-status-actions-<?php echo (int)$o->id; ?>">

            <?php
            // ИСПРАВЛЕНИЕ: кнопки строго по реальному статусу заказа
            // assigned  → кнопка «Прибыл» (водитель едет к клиенту)
            // arrived   → кнопка «В такси» (клиент сел) + «Завершить»
            // in_progress → только «Завершить»
            ?>
            <?php if ( $real_status === 'assigned' ) : ?>
              <button class="ts-oc-btn ts-oc-btn-arrived ts-disp-arrived-btn">🅿 Прибыл</button>
            <?php endif; ?>

            <?php if ( $real_status === 'arrived' ) : ?>
              <button class="ts-oc-btn ts-oc-btn-intaxi ts-disp-intaxi-btn">🚕 В такси</button>
              <button class="ts-oc-btn ts-oc-btn-complete ts-disp-complete-btn">✅ Завершить</button>
            <?php endif; ?>

            <?php if ( $real_status === 'in_progress' ) : ?>
              <button class="ts-oc-btn ts-oc-btn-complete ts-disp-complete-btn">✅ Завершить</button>
            <?php endif; ?>

            <?php if ( in_array( $real_status, array( 'new', 'assigned', 'arrived', 'in_progress' ), true ) ) : ?>
              <button class="ts-oc-btn ts-oc-btn-cancel ts-disp-cancel-btn">✕ Отменить</button>
            <?php endif; ?>

          </div>
        </div>
        <?php
    }
}
