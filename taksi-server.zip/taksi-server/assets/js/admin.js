/* Такси Сервер — Admin JS v2.0.0 */
jQuery(function($){

  /* --- Delete confirmation --- */
  $(document).on('click', '.ts-delete', function(){
    var entity = $(this).data('entity');
    var id     = $(this).data('id');
    var labels = { order: 'заказ', car: 'автомобиль', driver: 'водителя', dispatcher: 'диспетчера', phone: 'телефонную линию' };
    if ( ! confirm( 'Удалить ' + ( labels[entity] || entity ) + ' #' + id + '?' ) ) return;
    $.post( TS.ajax_url, {
      action:    'ts_action',
      ts_action: 'delete',
      entity:    entity,
      id:        id,
      nonce:     TS.nonce
    }, function(res){
      if ( res.success ) location.reload();
      else alert( 'Ошибка удаления' );
    });
  });

  /* --- Approve driver --- */
  $(document).on('click', '.ts-approve-driver', function(){
    var id  = $(this).data('id');
    var btn = $(this).prop('disabled', true).text('Одобряем…');
    $.post( TS.ajax_url, {
      action:    'ts_action',
      ts_action: 'approve_driver',
      driver_id: id,
      nonce:     TS.nonce
    }, function(res){
      if ( res.success ) location.reload();
      else { btn.prop('disabled', false).text('✅ Одобрить'); alert('Ошибка'); }
    });
  });

  /* --- Copy to clipboard --- */
  $(document).on('click', '.ts-copy-btn', function(){
    var text = $(this).data('copy');
    if ( navigator.clipboard ) {
      navigator.clipboard.writeText(text);
    } else {
      var ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    var btn = $(this);
    btn.text('Скопировано!');
    setTimeout(function(){ btn.text('Скопировать'); }, 2000);
  });

  /* --- Auto-refresh dashboard stats every 15s --- */
  if ( $('.ts-stats-grid').length ) {
    setInterval(function(){
      $.post( TS.ajax_url, {
        action:    'ts_action',
        ts_action: 'get_stats',
        nonce:     TS.nonce
      }, function(res){
        if ( ! res.success ) return;
        var d = res.data;
        if ( d.cars ) {
          $('.ts-car-badge.free strong').text(d.cars.free);
          $('.ts-car-badge.busy strong').text(d.cars.busy);
          $('.ts-car-badge.offline strong').text(d.cars.offline);
        }
      });
    }, 15000);
  }

  /* --- Notify channel highlight --- */
  $(document).on('change', '[name=notify_channel]', function(){
    $('.ts-ch-label').removeClass('ts-ch-active');
    $(this).closest('.ts-ch-label').addClass('ts-ch-active');
  });

  /* --- Date preset helpers on filter form --- */
  $(document).on('click', '.ts-preset', function(e){
    // allow default href navigation
  });

});
