<?php
/**
 * Такси Сервер — TCP-сервер для совместимости с таксофонами «Такси Мастер»
 * Запуск: php taxophone-server.php
 * Требует: PHP CLI с расширением sockets
 *
 * Протокол «Такси Мастер»:
 * Входящие сообщения (от таксофона):
 *   [callsign]|[token]|STATUS|[status]  — обновление статуса машины
 *   [callsign]|[token]|ACCEPT|[order_id] — принятие заказа
 *   [callsign]|[token]|COMPLETE|[order_id] — завершение заказа
 *   [callsign]|[token]|LOCATION|[lat]|[lng] — координаты
 *
 * Исходящие сообщения (к таксофону):
 *   ORDER|[order_id]|[order_number]|[from]|[to]|[phone]|[notes]\n
 *   OK\n
 *   ERR|[message]\n
 */

define( 'TS_WP_DIR', __DIR__ . '/../../../' );

$config_file = __DIR__ . '/taxophone-config.php';
if ( file_exists( $config_file ) ) {
    require_once $config_file;
} else {
    define( 'TS_TCP_PORT', (int) ( getenv('TS_TCP_PORT') ?: 4000 ) );
    define( 'TS_DB_HOST', getenv('DB_HOST') ?: 'localhost' );
    define( 'TS_DB_NAME', getenv('DB_NAME') ?: '' );
    define( 'TS_DB_USER', getenv('DB_USER') ?: 'root' );
    define( 'TS_DB_PASS', getenv('DB_PASS') ?: '' );
    define( 'TS_DB_PREFIX', getenv('DB_PREFIX') ?: 'wp_' );
    define( 'TS_SECRET', getenv('TS_SECRET') ?: 'taksi-server' );
}

if ( ! extension_loaded('sockets') ) {
    echo "Ошибка: расширение sockets не загружено. Установите php-sockets.\n";
    exit(1);
}

$pdo = null;
try {
    $pdo = new PDO(
        'mysql:host=' . TS_DB_HOST . ';dbname=' . TS_DB_NAME . ';charset=utf8mb4',
        TS_DB_USER, TS_DB_PASS,
        array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION )
    );
} catch ( PDOException $e ) {
    echo "Ошибка подключения к БД: " . $e->getMessage() . "\n";
    exit(1);
}

$server = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_set_option($server, SOL_SOCKET, SO_REUSEADDR, 1);
socket_bind($server, '0.0.0.0', TS_TCP_PORT);
socket_listen($server, 10);
socket_set_nonblock($server);

echo "Такси Сервер TCP запущен на порту " . TS_TCP_PORT . "\n";

$clients = array();

while (true) {
    $read = array_merge(array($server), $clients);
    $write = null;
    $except = null;
    if (socket_select($read, $write, $except, 0, 200000) < 1) continue;

    if (in_array($server, $read)) {
        $client = socket_accept($server);
        if ($client) {
            socket_set_nonblock($client);
            $clients[] = $client;
            echo date('H:i:s') . " Новое подключение\n";
        }
        unset($read[array_search($server, $read)]);
    }

    foreach ($read as $client) {
        $data = @socket_read($client, 2048, PHP_NORMAL_READ);
        if ($data === false || $data === '') {
            $idx = array_search($client, $clients);
            if ($idx !== false) unset($clients[$idx]);
            socket_close($client);
            continue;
        }

        $data = trim($data);
        if ($data === '') continue;

        echo date('H:i:s') . " ← $data\n";
        $parts = explode('|', $data);
        if (count($parts) < 4) {
            ts_send($client, "ERR|Неверный формат\n");
            continue;
        }

        $callsign = trim($parts[0]);
        $token    = trim($parts[1]);
        $command  = strtoupper(trim($parts[2]));

        // Auth
        $expected_token = md5($callsign . TS_SECRET);
        if ($token !== $expected_token) {
            ts_send($client, "ERR|Неверный токен\n");
            continue;
        }

        $car = $pdo->prepare("SELECT * FROM " . TS_DB_PREFIX . "ts_cars WHERE callsign = ?");
        $car->execute([$callsign]);
        $car = $car->fetch(PDO::FETCH_OBJ);
        if (!$car) {
            ts_send($client, "ERR|Машина не найдена\n");
            continue;
        }

        switch ($command) {
            case 'STATUS':
                $status = strtolower(trim($parts[3] ?? ''));
                if (in_array($status, ['free', 'busy', 'offline'])) {
                    $stmt = $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_cars SET status=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$status, $car->id]);
                    ts_send($client, "OK\n");
                    echo "  → Машина $callsign: статус = $status\n";
                }
                break;

            case 'ACCEPT':
                $order_id = (int)($parts[3] ?? 0);
                if ($order_id) {
                    $stmt = $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_orders SET status='in_progress', accepted_at=NOW(), updated_at=NOW() WHERE id=?");
                    $stmt->execute([$order_id]);
                    $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_cars SET status='busy', updated_at=NOW() WHERE id=?")->execute([$car->id]);
                    ts_send($client, "OK\n");
                    echo "  → Машина $callsign принял заказ #$order_id\n";
                }
                break;

            case 'COMPLETE':
                $order_id = (int)($parts[3] ?? 0);
                if ($order_id) {
                    $stmt = $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_orders SET status='completed', completed_at=NOW(), updated_at=NOW() WHERE id=?");
                    $stmt->execute([$order_id]);
                    $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_cars SET status='free', updated_at=NOW() WHERE id=?")->execute([$car->id]);
                    ts_send($client, "OK\n");
                    echo "  → Машина $callsign завершил заказ #$order_id\n";
                }
                break;

            case 'LOCATION':
                $lat = (float)($parts[3] ?? 0);
                $lng = (float)($parts[4] ?? 0);
                if ($lat && $lng) {
                    $pdo->prepare("UPDATE " . TS_DB_PREFIX . "ts_cars SET lat=?, lng=?, last_seen=NOW(), updated_at=NOW() WHERE id=?")->execute([$lat, $lng, $car->id]);
                    ts_send($client, "OK\n");
                }
                break;

            case 'GETORDERS':
                $orders = $pdo->prepare("SELECT * FROM " . TS_DB_PREFIX . "ts_orders WHERE car_id=? AND status IN ('assigned','arrived') ORDER BY created_at DESC LIMIT 5");
                $orders->execute([$car->id]);
                $list = $orders->fetchAll(PDO::FETCH_OBJ);
                if ($list) {
                    foreach ($list as $o) {
                        ts_send($client, "ORDER|{$o->id}|{$o->order_number}|{$o->address_from}|{$o->address_to}|{$o->client_phone}|{$o->notes}\n");
                    }
                } else {
                    ts_send($client, "NOORDERS\n");
                }
                break;

            default:
                ts_send($client, "ERR|Неизвестная команда $command\n");
        }
    }
    $clients = array_values($clients);
}

function ts_send($client, $msg) {
    echo date('H:i:s') . " → $msg";
    @socket_write($client, $msg, strlen($msg));
}
