<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Phones {

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table  = TS_Database::table( 'phone_lines' );
        $where  = array( '1=1' );
        $params = array();

        if ( isset( $args['status'] ) && $args['status'] !== '' ) {
            $where[]  = 'status = %s';
            $params[] = $args['status'];
        }
        if ( ! empty( $args['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[]  = '(number LIKE %s OR description LIKE %s)';
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM $table WHERE $where_sql ORDER BY number ASC";
        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, ...$params );
        }
        return $wpdb->get_results( $sql );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'phone_lines' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = TS_Database::table( 'phone_lines' );
        $data['created_at'] = current_time( 'mysql' );
        $data['updated_at'] = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = TS_Database::table( 'phone_lines' );
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'phone_lines' );
        return $wpdb->delete( $table, array( 'id' => $id ) );
    }

    public static function get_active() {
        global $wpdb;
        $table = TS_Database::table( 'phone_lines' );
        return $wpdb->get_results( "SELECT * FROM $table WHERE status = 'active' ORDER BY number ASC" );
    }
}
