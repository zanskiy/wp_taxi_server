<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Orders {

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $cars  = TS_Database::table( 'cars' );
        $drv   = TS_Database::table( 'drivers' );
        $disp  = TS_Database::table( 'dispatchers' );

        $where  = array( '1=1' );
        $params = array();

        if ( ! empty( $args['status'] ) ) {
            if ( is_array( $args['status'] ) ) {
                $placeholders = implode( ',', array_fill( 0, count( $args['status'] ), '%s' ) );
                $where[]      = "o.status IN ($placeholders)";
                $params       = array_merge( $params, $args['status'] );
            } else {
                $where[]  = 'o.status = %s';
                $params[] = $args['status'];
            }
        }
        if ( ! empty( $args['date_from'] ) ) {
            $where[]  = 'DATE(o.created_at) >= %s';
            $params[] = $args['date_from'];
        }
        if ( ! empty( $args['date_to'] ) ) {
            $where[]  = 'DATE(o.created_at) <= %s';
            $params[] = $args['date_to'];
        }
        if ( ! empty( $args['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[]  = '(o.order_number LIKE %s OR o.client_name LIKE %s OR o.client_phone LIKE %s OR o.address_from LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $limit     = isset( $args['limit'] )  ? (int) $args['limit']  : 100;
        $offset    = isset( $args['offset'] ) ? (int) $args['offset'] : 0;
        $order_dir = ! empty( $args['order'] ) ? 'ASC' : 'DESC';

        $sql = "SELECT o.*,
            c.callsign AS car_callsign, c.plate AS car_plate,
            d.name AS driver_name,
            dp.name AS dispatcher_name
            FROM $table o
            LEFT JOIN $cars c  ON o.car_id = c.id
            LEFT JOIN $drv d   ON o.driver_id = d.id
            LEFT JOIN $disp dp ON o.dispatcher_id = dp.id
            WHERE $where_sql
            ORDER BY o.created_at $order_dir
            LIMIT %d OFFSET %d";

        $params[] = $limit;
        $params[] = $offset;

        return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $data['order_number'] = TS_Database::next_order_number();
        $data['created_at']   = current_time( 'mysql' );
        $data['updated_at']   = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        return $wpdb->delete( $table, array( 'id' => $id ) );
    }

    public static function count_by_status() {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $rows  = $wpdb->get_results( "SELECT status, COUNT(*) as cnt FROM $table GROUP BY status" );
        $out   = array();
        foreach ( $rows as $r ) {
            $out[ $r->status ] = (int) $r->cnt;
        }
        return $out;
    }

    public static function today_stats() {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $today = current_time( 'Y-m-d' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) as total,
             SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
             SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) as cancelled,
             SUM(CASE WHEN status IN ('new','assigned','in_progress','arrived') THEN 1 ELSE 0 END) as active,
             IFNULL(SUM(CASE WHEN status='completed' THEN price ELSE 0 END),0) as revenue
             FROM $table WHERE DATE(created_at) = %s", $today
        ) );
    }
}
