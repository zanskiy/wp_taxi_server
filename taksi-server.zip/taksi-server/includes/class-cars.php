<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Cars {

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        $drv   = TS_Database::table( 'drivers' );

        $where  = array( '1=1' );
        $params = array();

        if ( isset( $args['status'] ) && $args['status'] !== '' ) {
            $where[]  = 'c.status = %s';
            $params[] = $args['status'];
        }
        if ( ! empty( $args['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[]  = '(c.callsign LIKE %s OR c.plate LIKE %s OR c.model LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT c.*, d.name as driver_name
                FROM $table c
                LEFT JOIN $drv d ON c.driver_id = d.id
                WHERE $where_sql
                ORDER BY c.callsign ASC";

        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, ...$params );
        }

        return $wpdb->get_results( $sql );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        $data['created_at'] = current_time( 'mysql' );
        $data['updated_at'] = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        return $wpdb->delete( $table, array( 'id' => $id ) );
    }

    public static function count_by_status() {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        $rows  = $wpdb->get_results( "SELECT status, COUNT(*) as cnt FROM $table GROUP BY status" );
        $out   = array( 'free' => 0, 'busy' => 0, 'offline' => 0 );
        foreach ( $rows as $r ) {
            $out[ $r->status ] = (int) $r->cnt;
        }
        return $out;
    }

    public static function get_with_location() {
        global $wpdb;
        $table = TS_Database::table( 'cars' );
        $drv   = TS_Database::table( 'drivers' );
        return $wpdb->get_results(
            "SELECT c.*, d.name as driver_name
             FROM $table c
             LEFT JOIN $drv d ON c.driver_id = d.id
             WHERE c.status != 'offline'
             ORDER BY c.callsign ASC"
        );
    }
}
