<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        $ns = 'taksi-server/v1';

        register_rest_route( $ns, '/driver/orders',          array( 'methods' => 'GET',  'callback' => array( $this, 'r_driver_orders' ),         'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/order/accept',    array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_order_accept' ),    'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/order/complete',  array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_order_complete' ),  'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/order/cancel',    array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_order_cancel' ),    'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/order/arrived',   array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_order_arrived' ),   'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/status',          array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_set_status' ),      'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/location',        array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_update_location' ), 'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/balance',        array( 'methods' => 'GET',  'callback' => array( $this, 'r_driver_balance' ),        'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/driver/register',        array( 'methods' => 'POST', 'callback' => array( $this, 'r_driver_register' ),        'permission_callback' => '__return_true' ) );

        register_rest_route( $ns, '/client/order',           array( 'methods' => 'POST', 'callback' => array( $this, 'r_client_create_order' ),   'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/client/order/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( $this, 'r_client_order_status' ),  'permission_callback' => '__return_true' ) );

        register_rest_route( $ns, '/dispatcher/dashboard',   array( 'methods' => 'GET',  'callback' => array( $this, 'r_dispatcher_dashboard' ),  'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/dispatcher/cars',        array( 'methods' => 'GET',  'callback' => array( $this, 'r_dispatcher_cars' ),        'permission_callback' => '__return_true' ) );

        register_rest_route( $ns, '/telegram/location', array( 'methods' => 'POST', 'callback' => array( $this, 'r_telegram_location' ), 'permission_callback' => '__return_true' ) );
    }

    private function driver_auth( $callsign, $token ) {
        global $wpdb;
        $secret   = get_option( 'ts_driver_secret', 'taksi-server' );
        $expected = md5( $callsign . $secret );
        if ( $token !== $expected ) return false;

        $cars_table = TS_Database::table( 'cars' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $cars_table WHERE callsign = %s", $callsign ) );
    }

    public function r_driver_orders( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        $orders = TS_Orders::get_all( array(
            'status' => array( 'assigned', 'in_progress', 'arrived' ),
            'limit'  => 20,
        ) );

        $my_orders = array_filter( $orders, function( $o ) use ( $car ) {
            return (int) $o->car_id === (int) $car->id;
        } );

        return rest_ensure_response( array( 'ok' => true, 'orders' => array_values( $my_orders ) ) );
    }

    public function r_driver_order_accept( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $order_id = (int) $req->get_param( 'order_id' );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        // "Клиент в машине" — arrived -> in_progress
        TS_Orders::update( $order_id, array( 'status' => 'in_progress', 'accepted_at' => current_time( 'mysql' ) ) );
        TS_Cars::update( $car->id, array( 'status' => 'busy' ) );

        $order = TS_Orders::get( $order_id );
        if ( $order ) TS_Notifications::notify_client( $order );

        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_order_arrived( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $order_id = (int) $req->get_param( 'order_id' );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        // Проверяем, что заказ принадлежит этой машине
        $order = TS_Orders::get( $order_id );
        if ( ! $order ) return new WP_Error( 'ts_not_found', 'Заказ не найден', array( 'status' => 404 ) );
        if ( (int) $order->car_id !== (int) $car->id ) {
            return new WP_Error( 'ts_forbidden', 'Нет доступа к этому заказу', array( 'status' => 403 ) );
        }

        // assigned -> arrived (водитель прибыл к клиенту, машина остаётся busy)
        TS_Orders::update( $order_id, array( 'status' => 'arrived', 'arrived_at' => current_time( 'mysql' ) ) );
        $order = TS_Orders::get( $order_id );
        if ( $order ) TS_Notifications::notify_client( $order );

        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_order_complete( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $order_id = (int) $req->get_param( 'order_id' );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        TS_Orders::update( $order_id, array( 'status' => 'completed', 'completed_at' => current_time( 'mysql' ) ) );
        TS_Cars::update( $car->id, array( 'status' => 'free' ) );

        $order = TS_Orders::get( $order_id );
        if ( $order ) TS_Notifications::notify_client( $order );

        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_order_cancel( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $order_id = (int) $req->get_param( 'order_id' );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        TS_Orders::update( $order_id, array( 'status' => 'cancelled' ) );
        TS_Cars::update( $car->id, array( 'status' => 'free' ) );

        $order = TS_Orders::get( $order_id );
        if ( $order ) TS_Notifications::notify_client( $order );

        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_set_status( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $status   = sanitize_key( $req->get_param( 'status' ) );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        if ( ! in_array( $status, array( 'free', 'busy', 'offline' ), true ) ) {
            return new WP_Error( 'ts_validation', 'Неверный статус', array( 'status' => 400 ) );
        }

        TS_Cars::update( $car->id, array( 'status' => $status ) );
        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_update_location( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $lat      = (float) $req->get_param( 'lat' );
        $lng      = (float) $req->get_param( 'lng' );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        $update = array( 'lat' => $lat, 'lng' => $lng, 'last_seen' => current_time( 'mysql' ) );

        // ИСПРАВЛЕНИЕ КАРТЫ: водитель онлайн (шлёт геолокацию) — если машина была
        // offline, переводим в free, иначе диспетчер не видит её на карте
        if ( $car->status === 'offline' ) {
            $update['status'] = 'free';
        }

        TS_Cars::update( $car->id, $update );
        return rest_ensure_response( array( 'ok' => true ) );
    }

    public function r_driver_register( $req ) {
        $name     = sanitize_text_field( $req->get_param( 'name' ) );
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $phone    = sanitize_text_field( $req->get_param( 'phone' ) );
        $license  = sanitize_text_field( $req->get_param( 'license' ) );
        $tg_id    = sanitize_text_field( $req->get_param( 'telegram_chat_id' ) );

        if ( empty( $name ) || empty( $callsign ) || empty( $phone ) ) {
            return new WP_Error( 'ts_validation', 'Заполните все обязательные поля', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table    = TS_Database::table( 'drivers' );
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE callsign = %s", $callsign ) );
        if ( $existing ) {
            return new WP_Error( 'ts_duplicate', 'Позывной уже занят. Выберите другой.', array( 'status' => 409 ) );
        }

        TS_Drivers::create( array(
            'name'             => $name,
            'callsign'         => $callsign,
            'phone'            => $phone,
            'license'          => $license,
            'telegram_chat_id' => $tg_id,
            'status'           => 'pending',
        ) );

        $token = md5( $callsign . get_option( 'ts_driver_secret', 'taksi-server' ) );
        return rest_ensure_response( array(
            'ok'       => true,
            'message'  => 'Заявка принята. Ожидайте одобрения диспетчера.',
            'callsign' => $callsign,
            'token'    => $token,
        ) );
    }

    public function r_client_create_order( $req ) {
        $data = array(
            'client_name'  => sanitize_text_field( $req->get_param( 'name' ) ),
            'client_phone' => sanitize_text_field( $req->get_param( 'phone' ) ),
            'client_tg_id' => sanitize_text_field( $req->get_param( 'tg_id' ) ),
            'address_from' => sanitize_textarea_field( $req->get_param( 'address_from' ) ),
            'address_to'   => sanitize_textarea_field( $req->get_param( 'address_to' ) ),
            'waypoints'    => wp_json_encode( array_filter( (array) $req->get_param( 'waypoints' ) ) ),
            'notes'        => sanitize_textarea_field( $req->get_param( 'notes' ) ),
            'status'       => 'new',
        );

        if ( empty( $data['client_phone'] ) || empty( $data['address_from'] ) ) {
            return new WP_Error( 'ts_validation', 'Телефон и адрес подачи обязательны', array( 'status' => 400 ) );
        }

        $id    = TS_Orders::create( $data );
        $order = TS_Orders::get( $id );
        return rest_ensure_response( array( 'ok' => true, 'order_id' => $id, 'order_number' => $order->order_number ) );
    }

    public function r_client_order_status( $req ) {
        $id    = (int) $req->get_param( 'id' );
        $phone = sanitize_text_field( $req->get_param( 'phone' ) );
        $order = TS_Orders::get( $id );

        if ( ! $order ) return new WP_Error( 'ts_not_found', 'Заказ не найден', array( 'status' => 404 ) );
        if ( $phone && $order->client_phone !== $phone ) {
            return new WP_Error( 'ts_auth', 'Доступ запрещён', array( 'status' => 403 ) );
        }

        global $wpdb;
        $car = null;
        if ( $order->car_id ) {
            $cars_table = TS_Database::table( 'cars' );
            $car = $wpdb->get_row( $wpdb->prepare( "SELECT callsign, model, color, phone FROM $cars_table WHERE id = %d", $order->car_id ) );
        }

        return rest_ensure_response( array(
            'ok'    => true,
            'order' => array(
                'id'           => $order->id,
                'order_number' => $order->order_number,
                'status'       => $order->status,
                'address_from' => $order->address_from,
                'address_to'   => $order->address_to,
                'created_at'   => $order->created_at,
            ),
            'car' => $car,
        ) );
    }

    public function r_dispatcher_dashboard( $req ) {
        $stats      = TS_Orders::today_stats();
        $cars       = TS_Cars::count_by_status();
        $new_orders = TS_Orders::get_all( array( 'status' => 'new', 'limit' => 20 ) );
        return rest_ensure_response( array( 'stats' => $stats, 'cars' => $cars, 'new_orders' => $new_orders ) );
    }

    public function r_dispatcher_cars( $req ) {
        $cars = TS_Cars::get_with_location();
        return rest_ensure_response( array( 'ok' => true, 'cars' => $cars ) );
    }

    public function r_telegram_location( WP_REST_Request $req ) {
        $body = $req->get_json_params();
        if ( empty( $body ) ) return rest_ensure_response( array( 'ok' => true ) );

        $message = $body['message'] ?? $body['edited_message'] ?? null;
        if ( ! $message ) return rest_ensure_response( array( 'ok' => true ) );

        $location = $message['location'] ?? null;
        if ( ! $location ) return rest_ensure_response( array( 'ok' => true ) );

        $lat   = (float) ( $location['latitude']  ?? 0 );
        $lng   = (float) ( $location['longitude'] ?? 0 );
        $tg_id = (string) ( $message['from']['id'] ?? $message['chat']['id'] ?? '' );

        if ( ! $lat || ! $lng || ! $tg_id ) return rest_ensure_response( array( 'ok' => true ) );

        global $wpdb;
        $drivers_table = TS_Database::table( 'drivers' );
        $driver = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $drivers_table WHERE telegram_chat_id = %s LIMIT 1", $tg_id
        ) );

        if ( ! $driver ) return rest_ensure_response( array( 'ok' => true, 'note' => 'driver_not_found' ) );

        $cars_table = TS_Database::table( 'cars' );
        $car = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $cars_table WHERE driver_id = %d LIMIT 1", $driver->id
        ) );

        if ( $car ) {
            $update = array( 'lat' => $lat, 'lng' => $lng, 'last_seen' => current_time( 'mysql' ) );
            // Telegram-водитель онлайн — убираем offline, чтобы показывать на карте
            if ( $car->status === 'offline' ) {
                $update['status'] = 'free';
            }
            TS_Cars::update( $car->id, $update );
        }

        return rest_ensure_response( array( 'ok' => true ) );
    }
    /**
     * Баланс водителя: поездки за текущий месяц, выручка, начислено фирме, чистый заработок.
     */
    public function r_driver_balance( $req ) {
        $callsign = sanitize_text_field( $req->get_param( 'callsign' ) );
        $token    = sanitize_text_field( $req->get_param( 'token' ) );
        $car      = $this->driver_auth( $callsign, $token );
        if ( ! $car ) return new WP_Error( 'ts_auth', 'Неверный позывной или токен', array( 'status' => 401 ) );

        // Найдём водителя по машине
        global $wpdb;
        $drivers_t = TS_Database::table( 'drivers' );
        $driver    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $drivers_t WHERE status='active' LIMIT 1" ) );
        // Попробуем найти по car_id через orders
        $orders_t  = TS_Database::table( 'orders' );

        // Статистика текущего месяца по car_id
        $date_from = date( 'Y-m-01' );
        $date_to   = date( 'Y-m-d' );

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS trips, IFNULL(SUM(price),0) AS revenue
             FROM $orders_t
             WHERE car_id = %d AND status = 'completed'
             AND DATE(created_at) BETWEEN %s AND %s",
            $car->id, $date_from, $date_to
        ) );

        // Найдём данные водителя через car
        $driver = $wpdb->get_row( $wpdb->prepare(
            "SELECT d.* FROM $drivers_t d
             WHERE d.callsign = %s AND d.status = 'active'
             LIMIT 1",
            $callsign
        ) );

        $revenue      = (float) ( $stats->trips ? $stats->revenue : 0 );
        $trips        = (int) ( $stats->trips ?? 0 );
        $payment_type = $driver ? ( $driver->payment_type ?? 'percent' ) : 'percent';
        $commission   = $driver ? (float) ( $driver->commission_pct ?? get_option( 'ts_default_commission_pct', 15 ) ) : (float) get_option( 'ts_default_commission_pct', 15 );
        $sub_fee      = $driver ? (float) ( $driver->subscription_fee ?? 0 ) : 0;

        if ( $payment_type === 'percent' ) {
            $deducted = round( $revenue * $commission / 100, 2 );
        } else {
            $deducted = $sub_fee;
        }
        $net = round( $revenue - $deducted, 2 );

        // Всего за всё время
        $all_time = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS trips, IFNULL(SUM(price),0) AS revenue
             FROM $orders_t WHERE car_id = %d AND status = 'completed'",
            $car->id
        ) );

        return rest_ensure_response( array(
            'ok'           => true,
            'month'        => date( 'm.Y' ),
            'trips'        => $trips,
            'revenue'      => $revenue,
            'payment_type' => $payment_type,
            'commission'   => $commission,
            'sub_fee'      => $sub_fee,
            'deducted'     => $deducted,
            'net'          => $net,
            'all_trips'    => (int) ( $all_time->trips ?? 0 ),
            'all_revenue'  => (float) ( $all_time->revenue ?? 0 ),
        ) );
    }

}
