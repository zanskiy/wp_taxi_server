<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_AutoDispatch {

    /**
     * Назначает свободных водителей на необработанные заказы.
     * Запускается из WP-Cron и из AJAX диспетчера (disp_refresh).
     *
     * @return array Список назначений
     */
    public static function run() {
        if ( ! get_option( 'ts_auto_dispatch', '0' ) ) {
            return array();
        }

        $timeout = max( 5, (int) get_option( 'ts_auto_dispatch_timeout', 20 ) );

        global $wpdb;
        $orders_table = TS_Database::table( 'orders' );
        $cars_table   = TS_Database::table( 'cars' );

        // ИСПРАВЛЕНИЕ АВТОРAЗДАЧИ: используем UTC_TIMESTAMP() вместо NOW(),
        // чтобы избежать расхождения часовых поясов между MySQL и WordPress.
        // created_at хранится в UTC (WordPress сохраняет через current_time('mysql', true) в UTC,
        // а через current_time('mysql') — в локальном времени WP).
        // Используем сравнение на основе UNIX_TIMESTAMP для надёжности.
        $pending = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $orders_table
             WHERE status = 'new'
               AND UNIX_TIMESTAMP() - UNIX_TIMESTAMP(created_at) >= %d
             ORDER BY created_at ASC
             LIMIT 50",
            $timeout
        ) );

        if ( empty( $pending ) ) {
            return array();
        }

        $assigned = array();

        foreach ( $pending as $order ) {
            // Берём первую свободную машину (очередь — по дате последнего использования)
            $car = $wpdb->get_row(
                "SELECT * FROM $cars_table
                 WHERE status = 'free'
                 ORDER BY last_seen ASC, id ASC
                 LIMIT 1"
            );

            if ( ! $car ) break; // Нет свободных машин

            // Назначаем заказ
            TS_Orders::update( $order->id, array(
                'status'    => 'assigned',
                'car_id'    => $car->id,
                'driver_id' => $car->driver_id ?: null,
            ) );

            // Помечаем машину как занятую
            TS_Cars::update( $car->id, array( 'status' => 'busy' ) );

            // Уведомляем водителя
            if ( $car->driver_id ) {
                $updated_order = TS_Orders::get( $order->id );
                if ( $updated_order ) {
                    TS_Notifications::notify_driver( $car->driver_id, $updated_order );
                }
            }

            $assigned[] = array(
                'order_id'     => (int) $order->id,
                'order_number' => $order->order_number,
                'car_id'       => (int) $car->id,
                'car_callsign' => $car->callsign,
            );
        }

        return $assigned;
    }
}
