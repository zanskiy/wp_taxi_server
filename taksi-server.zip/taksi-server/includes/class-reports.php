<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Reports {

    public static function revenue_by_day( $date_from, $date_to ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(created_at) AS day,
                    COUNT(*) AS total,
                    SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
                    SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) AS cancelled,
                    IFNULL(SUM(CASE WHEN status='completed' THEN price ELSE 0 END),0) AS revenue
             FROM $table
             WHERE DATE(created_at) BETWEEN %s AND %s
             GROUP BY DATE(created_at)
             ORDER BY day ASC",
            $date_from, $date_to
        ) );
    }

    public static function top_drivers( $date_from, $date_to, $limit = 10 ) {
        global $wpdb;
        $orders  = TS_Database::table( 'orders' );
        $drivers = TS_Database::table( 'drivers' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.name,
                    COUNT(o.id) AS trips,
                    IFNULL(SUM(o.price),0) AS revenue,
                    IFNULL(AVG(o.price),0) AS avg_price
             FROM $orders o
             JOIN $drivers d ON o.driver_id = d.id
             WHERE DATE(o.created_at) BETWEEN %s AND %s
               AND o.status = 'completed'
             GROUP BY o.driver_id
             ORDER BY revenue DESC
             LIMIT %d",
            $date_from, $date_to, $limit
        ) );
    }

    public static function hourly_distribution( $date_from, $date_to ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT HOUR(created_at) AS h, COUNT(*) AS cnt
             FROM $table
             WHERE DATE(created_at) BETWEEN %s AND %s
             GROUP BY HOUR(created_at) ORDER BY h",
            $date_from, $date_to
        ) );
        $out = array_fill( 0, 24, 0 );
        foreach ( $rows as $r ) {
            $out[ (int) $r->h ] = (int) $r->cnt;
        }
        return $out;
    }

    public static function summary( $date_from, $date_to ) {
        global $wpdb;
        $table = TS_Database::table( 'orders' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status='completed'  THEN 1 ELSE 0 END) AS completed,
                    SUM(CASE WHEN status='cancelled'  THEN 1 ELSE 0 END) AS cancelled,
                    SUM(CASE WHEN status='new'        THEN 1 ELSE 0 END) AS new_orders,
                    IFNULL(SUM(CASE WHEN status='completed' THEN price ELSE 0 END),0) AS revenue,
                    IFNULL(AVG(CASE WHEN status='completed' THEN price END),0) AS avg_price,
                    IFNULL(AVG(CASE WHEN status='completed' THEN distance_km END),0) AS avg_km
             FROM $table
             WHERE DATE(created_at) BETWEEN %s AND %s",
            $date_from, $date_to
        ) );
    }

    public static function orders_for_export( $date_from, $date_to ) {
        return TS_Orders::get_all( array(
            'date_from' => $date_from,
            'date_to'   => $date_to,
            'limit'     => 99999,
        ) );
    }

    public static function export_excel( $date_from, $date_to ) {
        $orders  = self::orders_for_export( $date_from, $date_to );
        $summary = self::summary( $date_from, $date_to );
        $company = get_option( 'ts_company_name', 'Такси Сервер' );

        $status_labels = array(
            'new'         => 'Новый',
            'assigned'    => 'Назначен',
            'in_progress' => 'В пути',
            'arrived'     => 'Прибыл',
            'completed'   => 'Выполнен',
            'cancelled'   => 'Отменён',
        );

        $cols = array( '№ заказа', 'Дата', 'Клиент', 'Телефон', 'Откуда', 'Куда', 'Остановки', 'Водитель', 'Машина', 'Статус', 'Цена', 'Км' );

        header( 'Content-Type: application/vnd.ms-excel; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="otchet-' . sanitize_file_name( $date_from ) . '--' . sanitize_file_name( $date_to ) . '.xls"' );
        header( 'Cache-Control: max-age=0' );
        header( 'Pragma: public' );

        echo "\xEF\xBB\xBF";
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
        echo ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
        echo ' xmlns:x="urn:schemas-microsoft-com:office:excel">' . "\n";

        echo '<Styles>' . "\n";
        echo ' <Style ss:ID="h"><Font ss:Bold="1" ss:Color="#ffffff"/><Interior ss:Color="#1a1a2e" ss:Pattern="Solid"/></Style>' . "\n";
        echo ' <Style ss:ID="s"><Font ss:Bold="1"/><Interior ss:Color="#f0f0f0" ss:Pattern="Solid"/></Style>' . "\n";
        echo ' <Style ss:ID="g"><Interior ss:Color="#e8f5e9" ss:Pattern="Solid"/></Style>' . "\n";
        echo ' <Style ss:ID="r"><Interior ss:Color="#ffebee" ss:Pattern="Solid"/></Style>' . "\n";
        echo '</Styles>' . "\n";

        echo '<Worksheet ss:Name="Заказы">' . "\n";
        echo '<Table>' . "\n";

        $title = esc_html( $company ) . ' — Отчёт ' . esc_html( $date_from ) . ' – ' . esc_html( $date_to );
        echo ' <Row><Cell ss:StyleID="h" ss:MergeAcross="11"><Data ss:Type="String">' . $title . '</Data></Cell></Row>' . "\n";

        echo ' <Row>' . "\n";
        foreach ( $cols as $col ) {
            echo '  <Cell ss:StyleID="s"><Data ss:Type="String">' . esc_html( $col ) . '</Data></Cell>' . "\n";
        }
        echo ' </Row>' . "\n";

        foreach ( $orders as $o ) {
            $style = '';
            if ( $o->status === 'completed' ) {
                $style = ' ss:StyleID="g"';
            } elseif ( $o->status === 'cancelled' ) {
                $style = ' ss:StyleID="r"';
            }

            $waypoints = '';
            if ( ! empty( $o->waypoints ) ) {
                $wps = json_decode( $o->waypoints, true );
                if ( is_array( $wps ) ) {
                    $waypoints = implode( ' -> ', $wps );
                }
            }

            $status_label = isset( $status_labels[ $o->status ] ) ? $status_labels[ $o->status ] : $o->status;

            echo ' <Row>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->order_number )                       . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( substr( $o->created_at, 0, 16 ) )        . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->client_name )                        . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->client_phone )                       . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->address_from )                       . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->address_to )                         . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $waypoints )                             . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->driver_name ? $o->driver_name : '—' ) . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $o->car_callsign ? $o->car_callsign : '—' ) . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="String">'  . esc_html( $status_label )                          . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="Number">'  . (float) $o->price                                  . '</Data></Cell>' . "\n";
            echo '  <Cell' . $style . '><Data ss:Type="Number">'  . (float) $o->distance_km                            . '</Data></Cell>' . "\n";
            echo ' </Row>' . "\n";
        }

        $revenue_total = $summary ? (float) $summary->revenue : 0;
        echo ' <Row>' . "\n";
        echo '  <Cell ss:StyleID="s" ss:MergeAcross="9"><Data ss:Type="String">ИТОГО</Data></Cell>' . "\n";
        echo '  <Cell ss:StyleID="s"><Data ss:Type="Number">' . $revenue_total . '</Data></Cell>' . "\n";
        echo '  <Cell ss:StyleID="s"><Data ss:Type="String"></Data></Cell>' . "\n";
        echo ' </Row>' . "\n";

        echo '</Table>' . "\n";
        echo '</Worksheet>' . "\n";
        echo '</Workbook>' . "\n";

        exit;
    }

    public static function export_csv( $date_from, $date_to ) {
        $orders = self::orders_for_export( $date_from, $date_to );

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="otchet-' . sanitize_file_name( $date_from ) . '--' . sanitize_file_name( $date_to ) . '.csv"' );
        header( 'Cache-Control: max-age=0' );

        echo "\xEF\xBB\xBF";

        $cols = array( '№ заказа', 'Дата', 'Клиент', 'Телефон', 'Откуда', 'Куда', 'Остановки', 'Водитель', 'Машина', 'Статус', 'Цена', 'Км' );
        echo implode( ';', $cols ) . "\n";

        $status_labels = array(
            'new'         => 'Новый',
            'assigned'    => 'Назначен',
            'in_progress' => 'В пути',
            'arrived'     => 'Прибыл',
            'completed'   => 'Выполнен',
            'cancelled'   => 'Отменён',
        );

        foreach ( $orders as $o ) {
            $waypoints = '';
            if ( ! empty( $o->waypoints ) ) {
                $wps = json_decode( $o->waypoints, true );
                if ( is_array( $wps ) ) {
                    $waypoints = implode( ' -> ', $wps );
                }
            }

            $status_label = isset( $status_labels[ $o->status ] ) ? $status_labels[ $o->status ] : $o->status;
            $driver_name  = $o->driver_name  ? $o->driver_name  : '';
            $car_callsign = $o->car_callsign ? $o->car_callsign : '';

            $row = array(
                $o->order_number,
                substr( $o->created_at, 0, 16 ),
                $o->client_name,
                $o->client_phone,
                '"' . str_replace( '"', '""', $o->address_from ) . '"',
                '"' . str_replace( '"', '""', $o->address_to ) . '"',
                '"' . str_replace( '"', '""', $waypoints ) . '"',
                $driver_name,
                $car_callsign,
                $status_label,
                $o->price,
                $o->distance_km,
            );

            echo implode( ';', $row ) . "\n";
        }

        exit;
    }

    /**
     * Расчёт заработка / задолженности водителей за период.
     * Для percent-водителей: ваш доход = выручка × commission_pct / 100.
     * Для subscription-водителей: ваш доход = subscription_fee (фикс./мес).
     */
    public static function driver_earnings( $date_from, $date_to ) {
        global $wpdb;
        $orders  = TS_Database::table( 'orders' );
        $drivers = TS_Database::table( 'drivers' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT
                d.id,
                d.name,
                d.callsign,
                d.phone,
                d.payment_type,
                d.commission_pct,
                d.subscription_fee,
                COUNT(o.id)                                          AS trips,
                IFNULL(SUM(o.price), 0)                              AS revenue,
                IFNULL(AVG(o.price), 0)                              AS avg_price,
                CASE
                    WHEN d.payment_type = 'percent'
                        THEN IFNULL(SUM(o.price), 0) * d.commission_pct / 100
                    ELSE d.subscription_fee
                END                                                  AS company_income
             FROM $drivers d
             LEFT JOIN $orders o
                ON o.driver_id = d.id
               AND DATE(o.created_at) BETWEEN %s AND %s
               AND o.status = 'completed'
             WHERE d.status = 'active'
             GROUP BY d.id
             ORDER BY revenue DESC",
            $date_from, $date_to
        ) );
    }

    /**
     * Экспорт расчётов с водителями в CSV.
     */
    public static function export_earnings_csv( $date_from, $date_to ) {
        $rows = self::driver_earnings( $date_from, $date_to );

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="rashod-voditelej-' . sanitize_file_name( $date_from ) . '--' . sanitize_file_name( $date_to ) . '.csv"' );
        header( 'Cache-Control: max-age=0' );

        echo "\xEF\xBB\xBF";

        $cols = array( 'Водитель', 'Позывной', 'Телефон', 'Тип оплаты', 'Ставка', 'Поездок', 'Выручка руб', 'Ср. чек руб', 'Ваш доход руб', 'Чистый водителю руб' );
        echo implode( ';', $cols ) . "\n";

        foreach ( $rows as $de ) {
            $ptype   = $de->payment_type ?? 'percent';
            $revenue = (float) $de->revenue;
            $income  = (float) $de->company_income;
            $net     = $revenue - $income;
            $trips   = (int) $de->trips;
            $avg     = $trips > 0 ? round( $revenue / $trips, 2 ) : 0;
            $pval    = $ptype === 'percent'
                ? number_format( (float) $de->commission_pct, 2, '.', '' ) . '%'
                : number_format( (float) $de->subscription_fee, 2, '.', '' ) . ' руб/мес';

            $row = array(
                $de->name,
                $de->callsign,
                $de->phone,
                $ptype === 'percent' ? 'Процент' : 'Абонент',
                $pval,
                $trips,
                number_format( $revenue, 2, '.', '' ),
                number_format( $avg, 2, '.', '' ),
                number_format( $income, 2, '.', '' ),
                number_format( $net, 2, '.', '' ),
            );

            echo implode( ';', $row ) . "\n";
        }

        exit;
    }
}
