<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Notifications {

    public static function notify_driver( $driver_id, $order ) {
        $driver = TS_Drivers::get( $driver_id );
        if ( ! $driver ) return;

        $channel = get_option( 'ts_driver_notify_channel', 'telegram' );
        $msg = self::driver_order_message( $driver, $order );

        switch ( $channel ) {
            case 'telegram':
                $tid = $driver->telegram_chat_id ?? '';
                if ( $tid ) return self::send_telegram( $tid, $msg, 'driver' );
                // Нет Telegram ID у водителя — отправляем SMS
                return self::send_sms( $driver->phone, $msg );
            case 'viber':
                $vid = $driver->viber_id ?? '';
                if ( $vid ) return self::send_viber( $vid, $msg );
                return self::send_sms( $driver->phone, $msg );
            case 'max':
                $mid = $driver->max_id ?? '';
                if ( $mid ) return self::send_max( $mid, $msg );
                return self::send_sms( $driver->phone, $msg );
            case 'sms':
                return self::send_sms( $driver->phone, $msg );
        }
    }

    public static function notify_client( $order ) {
        $channel = get_option( 'ts_client_notify_channel', 'sms' );
        $msg     = self::client_status_message( $order );
        $phone   = $order->client_phone ?? '';

        switch ( $channel ) {
            case 'telegram':
                $tid = $order->client_tg_id ?? '';
                if ( $tid ) {
                    $result = self::send_telegram( $tid, $msg, 'client' );
                    // Если Telegram отправился успешно — выходим
                    if ( ! empty( $result['ok'] ) ) return $result;
                }
                // Нет Telegram ID или ошибка отправки — отправляем SMS как резерв
                if ( $phone ) return self::send_sms( $phone, $msg );
                break;

            case 'viber':
                if ( $phone ) {
                    $result = self::send_viber( $phone, $msg );
                    if ( ! empty( $result['status'] ) && $result['status'] === 0 ) return $result;
                    // Viber не отправился — пробуем SMS
                    return self::send_sms( $phone, $msg );
                }
                break;

            case 'max':
                if ( $phone ) {
                    $result = self::send_max( $phone, $msg );
                    if ( ! empty( $result['message_id'] ) ) return $result;
                    // MAX не отправился — пробуем SMS
                    return self::send_sms( $phone, $msg );
                }
                break;

            case 'sms':
                if ( $phone ) return self::send_sms( $phone, $msg );
                break;
        }

        return array( 'ok' => false, 'error' => 'no_contact' );
    }

    public static function notify_driver_status_change( $driver_id, $order, $new_status ) {
        $driver = TS_Drivers::get( $driver_id );
        if ( ! $driver ) return;

        $company = get_option( 'ts_company_name', 'Такси' );
        $labels  = array(
            'arrived'     => "✅ Водитель прибыл к клиенту.\nЗаказ #{$order->order_number}",
            'in_progress' => "🚕 Поездка началась.\nЗаказ #{$order->order_number}",
            'completed'   => "🏁 Поездка завершена.\nЗаказ #{$order->order_number}",
        );
        $msg      = $labels[ $new_status ] ?? "Статус заказа обновлён: $new_status";
        $full_msg = "{$company}\n$msg";

        $channel = get_option( 'ts_driver_notify_channel', 'telegram' );
        switch ( $channel ) {
            case 'telegram':
                $tid = $driver->telegram_chat_id ?? '';
                if ( $tid ) { self::send_telegram( $tid, $full_msg, 'driver' ); break; }
                self::send_sms( $driver->phone, $full_msg );
                break;
            case 'viber':
                $vid = $driver->viber_id ?? '';
                if ( $vid ) { self::send_viber( $vid, $full_msg ); break; }
                self::send_sms( $driver->phone, $full_msg );
                break;
            case 'max':
                $mid = $driver->max_id ?? '';
                if ( $mid ) { self::send_max( $mid, $full_msg ); break; }
                self::send_sms( $driver->phone, $full_msg );
                break;
            case 'sms':
                self::send_sms( $driver->phone, $full_msg );
                break;
        }
    }

    private static function driver_order_message( $driver, $order ) {
        $company = get_option( 'ts_company_name', 'Такси' );
        $waypoints = '';
        if ( ! empty( $order->waypoints ) ) {
            $wps = json_decode( $order->waypoints, true );
            if ( is_array( $wps ) && ! empty( $wps ) ) {
                $waypoints = "\n📍 Заезды: " . implode( ' → ', $wps );
            }
        }
        return "🚖 {$company} — Новый заказ #{$order->order_number}\n\n"
             . "📍 Откуда: {$order->address_from}\n"
             . "🏁 Куда: " . ( $order->address_to ?: '—' ) . $waypoints . "\n"
             . "👤 Клиент: " . ( $order->client_name ?: 'Не указан' ) . "\n"
             . "📞 Телефон: {$order->client_phone}\n"
             . ( $order->notes ? "💬 Примечание: {$order->notes}\n" : '' )
             . "\nПримите заказ в приложении водителя.";
    }

    private static function client_status_message( $order ) {
        $company = get_option( 'ts_company_name', 'Такси' );
        $statuses = array(
            'new'         => '📋 Ваш заказ принят и ожидает обработки.',
            'assigned'    => '🚗 Водитель назначен и едет к вам.',
            'in_progress' => '🚕 Поездка началась. Приятного пути!',
            'arrived'     => '🚕 Водитель прибыл. Пожалуйста, выходите.',
            'completed'   => '✅ Поездка завершена. Спасибо, что воспользовались нашим сервисом!',
            'cancelled'   => '❌ Ваш заказ отменён.',
        );
        $text = $statuses[ $order->status ] ?? 'Статус заказа изменился.';
        return "{$company} — Заказ #{$order->order_number}\n{$text}";
    }

    public static function send_telegram( $chat_id, $text, $mode = 'driver' ) {
        $token = $mode === 'driver'
            ? get_option( 'ts_telegram_driver_bot_token', '' )
            : get_option( 'ts_telegram_client_bot_token', '' );

        if ( ! $token || ! $chat_id ) return array( 'ok' => false, 'error' => 'no_token_or_chat_id' );

        $response = wp_remote_post( "https://api.telegram.org/bot{$token}/sendMessage", array(
            'timeout' => 10,
            'body'    => array(
                'chat_id'    => $chat_id,
                'text'       => $text,
                'parse_mode' => 'HTML',
            ),
        ) );

        if ( is_wp_error( $response ) ) return array( 'ok' => false, 'error' => $response->get_error_message() );
        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    public static function send_viber( $receiver, $text ) {
        $token = get_option( 'ts_viber_bot_token', '' );
        if ( ! $token || ! $receiver ) return array( 'ok' => false, 'error' => 'no_token' );

        $response = wp_remote_post( 'https://chatapi.viber.com/pa/send_message', array(
            'timeout' => 10,
            'headers' => array( 'X-Viber-Auth-Token' => $token ),
            'body'    => wp_json_encode( array(
                'receiver'        => $receiver,
                'min_api_version' => 1,
                'type'            => 'text',
                'text'            => $text,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) return array( 'ok' => false, 'error' => $response->get_error_message() );
        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    public static function send_max( $user_id, $text ) {
        $token = get_option( 'ts_max_bot_token', '' );
        if ( ! $token || ! $user_id ) return array( 'ok' => false, 'error' => 'no_token' );

        $url = 'https://botapi.max.app/messages/send?access_token=' . urlencode( $token )
             . '&user_id=' . urlencode( $user_id );

        $response = wp_remote_post( $url, array(
            'timeout' => 10,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => wp_json_encode( array( 'text' => $text ) ),
        ) );

        if ( is_wp_error( $response ) ) return array( 'ok' => false, 'error' => $response->get_error_message() );
        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    public static function send_sms( $phone, $text ) {
        $login    = get_option( 'ts_sms_login', '' );
        $password = get_option( 'ts_sms_password', '' );
        if ( ! $login || ! $password || ! $phone ) return array( 'ok' => false, 'error' => 'no_credentials' );

        $phone = preg_replace( '/[^0-9+]/', '', $phone );
        $url   = add_query_arg( array(
            'login'   => $login,
            'psw'     => md5( $password ),
            'phones'  => $phone,
            'mes'     => $text,
            'fmt'     => 3,
            'charset' => 'utf-8',
        ), 'https://smsc.ru/sys/send.php' );

        $response = wp_remote_get( $url, array( 'timeout' => 10 ) );
        if ( is_wp_error( $response ) ) return array( 'ok' => false, 'error' => $response->get_error_message() );

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return isset( $body['id'] ) ? array( 'ok' => true ) : array( 'ok' => false, 'error' => $body['error'] ?? 'unknown' );
    }

    public static function test_send( $channel, $recipient, $text = 'Тест уведомлений — Такси Сервер' ) {
        switch ( $channel ) {
            case 'telegram_driver': return self::send_telegram( $recipient, $text, 'driver' );
            case 'telegram_client': return self::send_telegram( $recipient, $text, 'client' );
            case 'viber':           return self::send_viber( $recipient, $text );
            case 'max':             return self::send_max( $recipient, $text );
            case 'sms':             return self::send_sms( $recipient, $text );
        }
        return array( 'ok' => false, 'error' => 'unknown_channel' );
    }
}
