<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Database {

    public static function install() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql = array();

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ts_cars (
            id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            callsign   VARCHAR(50)  NOT NULL,
            plate      VARCHAR(30)  NOT NULL,
            model      VARCHAR(100) NOT NULL DEFAULT '',
            color      VARCHAR(50)  NOT NULL DEFAULT '',
            driver_id  INT UNSIGNED DEFAULT NULL,
            status     ENUM('free','busy','offline') NOT NULL DEFAULT 'offline',
            phone      VARCHAR(50)  NOT NULL DEFAULT '',
            lat        DECIMAL(10,7) DEFAULT NULL,
            lng        DECIMAL(10,7) DEFAULT NULL,
            last_seen  DATETIME     DEFAULT NULL,
            notes      TEXT,
            created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (status),
            INDEX (driver_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ts_drivers (
            id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name             VARCHAR(150) NOT NULL,
            callsign         VARCHAR(50)  NOT NULL DEFAULT '',
            phone            VARCHAR(50)  NOT NULL DEFAULT '',
            license          VARCHAR(50)  NOT NULL DEFAULT '',
            status           ENUM('active','inactive','blocked','pending') NOT NULL DEFAULT 'active',
            telegram_chat_id VARCHAR(100) NOT NULL DEFAULT '',
            viber_id         VARCHAR(100) NOT NULL DEFAULT '',
            max_id           VARCHAR(100) NOT NULL DEFAULT '',
            payment_type     ENUM('percent','subscription') NOT NULL DEFAULT 'percent',
            commission_pct   DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            subscription_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            notes            TEXT,
            created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (status),
            INDEX (callsign)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ts_dispatchers (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(150) NOT NULL,
            login       VARCHAR(80)  NOT NULL UNIQUE,
            email       VARCHAR(200) NOT NULL DEFAULT '',
            phone       VARCHAR(50)  NOT NULL DEFAULT '',
            status      ENUM('active','inactive') NOT NULL DEFAULT 'active',
            wp_user_id  BIGINT UNSIGNED DEFAULT NULL,
            notes       TEXT,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (status),
            INDEX (wp_user_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ts_phone_lines (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            number      VARCHAR(50)  NOT NULL,
            description VARCHAR(200) NOT NULL DEFAULT '',
            type        ENUM('landline','mobile','voip','modem','other') NOT NULL DEFAULT 'mobile',
            status      ENUM('active','inactive') NOT NULL DEFAULT 'active',
            notes       TEXT,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (status)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ts_orders (
            id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            order_number   VARCHAR(30)  NOT NULL,
            client_name    VARCHAR(150) NOT NULL DEFAULT '',
            client_phone   VARCHAR(50)  NOT NULL DEFAULT '',
            client_tg_id   VARCHAR(100) NOT NULL DEFAULT '',
            address_from   TEXT         NOT NULL,
            address_to     TEXT         NOT NULL,
            waypoints      TEXT         DEFAULT NULL,
            car_id         INT UNSIGNED DEFAULT NULL,
            driver_id      INT UNSIGNED DEFAULT NULL,
            dispatcher_id  INT UNSIGNED DEFAULT NULL,
            phone_line_id  INT UNSIGNED DEFAULT NULL,
            status         ENUM('new','assigned','in_progress','arrived','completed','cancelled') NOT NULL DEFAULT 'new',
            price          DECIMAL(10,2) DEFAULT NULL,
            distance_km    DECIMAL(8,2)  DEFAULT NULL,
            notes          TEXT,
            accepted_at    DATETIME     DEFAULT NULL,
            arrived_at     DATETIME     DEFAULT NULL,
            completed_at   DATETIME     DEFAULT NULL,
            created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (status),
            INDEX (car_id),
            INDEX (driver_id),
            INDEX (created_at)
        ) $charset;";

        foreach ( $sql as $q ) {
            dbDelta( $q );
        }

        // Добавляем новые колонки если их нет (для уже установленных версий)
        $drivers_table = $wpdb->prefix . 'ts_drivers';
        $orders_table  = $wpdb->prefix . 'ts_orders';

        $cols_to_add = array(
            $drivers_table => array(
                'payment_type'     => "ALTER TABLE `$drivers_table` ADD COLUMN `payment_type` ENUM('percent','subscription') NOT NULL DEFAULT 'percent' AFTER `max_id`",
                'commission_pct'   => "ALTER TABLE `$drivers_table` ADD COLUMN `commission_pct` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `payment_type`",
                'subscription_fee' => "ALTER TABLE `$drivers_table` ADD COLUMN `subscription_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `commission_pct`",
            ),
            $orders_table => array(
                'waypoints'   => "ALTER TABLE `$orders_table` ADD COLUMN `waypoints` TEXT DEFAULT NULL AFTER `address_to`",
                'arrived_at'  => "ALTER TABLE `$orders_table` ADD COLUMN `arrived_at` DATETIME DEFAULT NULL AFTER `accepted_at`",
                'distance_km' => "ALTER TABLE `$orders_table` ADD COLUMN `distance_km` DECIMAL(8,2) DEFAULT NULL AFTER `price`",
                'client_tg_id'=> "ALTER TABLE `$orders_table` ADD COLUMN `client_tg_id` VARCHAR(100) NOT NULL DEFAULT '' AFTER `client_phone`",
            ),
        );

        foreach ( $cols_to_add as $table => $columns ) {
            foreach ( $columns as $col => $alter_sql ) {
                $exists = $wpdb->get_results( "SHOW COLUMNS FROM `$table` LIKE '$col'" );
                if ( empty( $exists ) ) {
                    $wpdb->query( $alter_sql );
                }
            }
        }

        // КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: добавляем статус 'arrived' в ENUM если его нет.
        // dbDelta() не обновляет ENUM-значения в существующих таблицах, поэтому
        // делаем это вручную. Без этого UPDATE status='arrived' молча игнорируется MySQL.
        $enum_row = $wpdb->get_row( "SHOW COLUMNS FROM `$orders_table` LIKE 'status'" );
        if ( $enum_row && strpos( $enum_row->Type, "'arrived'" ) === false ) {
            $wpdb->query(
                "ALTER TABLE `$orders_table`
                 MODIFY COLUMN `status`
                 ENUM('new','assigned','in_progress','arrived','completed','cancelled')
                 NOT NULL DEFAULT 'new'"
            );
        }

        update_option( 'ts_db_version', TS_VERSION );

        self::register_dispatcher_role();
    }

    public static function register_dispatcher_role() {
        if ( get_role( 'ts_dispatcher' ) ) return;

        add_role(
            'ts_dispatcher',
            'Диспетчер такси',
            array(
                'read'          => true,
                'ts_dispatcher' => true,
            )
        );
    }

    public static function deactivate() {
        remove_role( 'ts_dispatcher' );
    }

    public static function table( $name ) {
        global $wpdb;
        $map = array(
            'cars'        => $wpdb->prefix . 'ts_cars',
            'drivers'     => $wpdb->prefix . 'ts_drivers',
            'dispatchers' => $wpdb->prefix . 'ts_dispatchers',
            'phone_lines' => $wpdb->prefix . 'ts_phone_lines',
            'orders'      => $wpdb->prefix . 'ts_orders',
        );
        return isset( $map[ $name ] ) ? $map[ $name ] : $wpdb->prefix . 'ts_' . $name;
    }

    public static function next_order_number() {
        global $wpdb;
        $table = self::table( 'orders' );
        $today = current_time( 'Y-m-d' );
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE DATE(created_at) = %s", $today
        ) );
        return current_time( 'Ymd' ) . '-' . str_pad( $count + 1, 3, '0', STR_PAD_LEFT );
    }

    public static function maybe_upgrade() {
        $installed = get_option( 'ts_db_version', '1.0.0' );
        if ( version_compare( $installed, TS_VERSION, '<' ) ) {
            self::install();
        }
    }
}
