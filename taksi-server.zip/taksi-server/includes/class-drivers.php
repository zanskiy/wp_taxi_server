<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Drivers {

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );

        $where  = array( '1=1' );
        $params = array();

        if ( isset( $args['status'] ) && $args['status'] !== '' ) {
            $where[]  = 'status = %s';
            $params[] = $args['status'];
        }
        if ( ! empty( $args['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[]  = '(name LIKE %s OR phone LIKE %s OR license LIKE %s OR callsign LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM $table WHERE $where_sql ORDER BY name ASC";

        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, ...$params );
        }

        return $wpdb->get_results( $sql );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }

    public static function get_by_callsign( $callsign ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE callsign = %s", $callsign ) );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        $data['created_at'] = current_time( 'mysql' );
        $data['updated_at'] = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        return $wpdb->delete( $table, array( 'id' => $id ) );
    }

    public static function get_active() {
        global $wpdb;
        $table = TS_Database::table( 'drivers' );
        return $wpdb->get_results( "SELECT * FROM $table WHERE status = 'active' ORDER BY name ASC" );
    }
}
