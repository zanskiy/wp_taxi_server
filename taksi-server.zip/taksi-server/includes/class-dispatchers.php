<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TS_Dispatchers {

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table  = TS_Database::table( 'dispatchers' );
        $where  = array( '1=1' );
        $params = array();

        if ( isset( $args['status'] ) && $args['status'] !== '' ) {
            $where[]  = 'status = %s';
            $params[] = $args['status'];
        }
        if ( ! empty( $args['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[]  = '(name LIKE %s OR login LIKE %s OR phone LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM $table WHERE $where_sql ORDER BY name ASC";
        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, ...$params );
        }
        return $wpdb->get_results( $sql );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'dispatchers' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }

    public static function get_by_wp_user_id( $wp_user_id ) {
        global $wpdb;
        $table = TS_Database::table( 'dispatchers' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE wp_user_id = %d", (int) $wp_user_id
        ) );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = TS_Database::table( 'dispatchers' );
        $data['created_at'] = current_time( 'mysql' );
        $data['updated_at'] = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = TS_Database::table( 'dispatchers' );
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = TS_Database::table( 'dispatchers' );

        // Если есть связанный WP-пользователь, снимаем с него роль
        $dispatcher = self::get( $id );
        if ( $dispatcher && ! empty( $dispatcher->wp_user_id ) ) {
            $wp_user = get_user_by( 'id', (int) $dispatcher->wp_user_id );
            if ( $wp_user ) {
                $wp_user->remove_role( 'ts_dispatcher' );
            }
        }

        return $wpdb->delete( $table, array( 'id' => $id ) );
    }

    /**
     * Создаёт WordPress-пользователя и связывает его с диспетчером.
     * Возвращает массив ['wp_user_id' => int, 'password' => string] или WP_Error.
     */
    public static function create_wp_account( $dispatcher_id, $email = '', $password = '' ) {
        $dispatcher = self::get( $dispatcher_id );
        if ( ! $dispatcher ) return new WP_Error( 'not_found', 'Диспетчер не найден' );

        // Если WP-аккаунт уже есть — просто возвращаем его
        if ( ! empty( $dispatcher->wp_user_id ) ) {
            $existing = get_user_by( 'id', (int) $dispatcher->wp_user_id );
            if ( $existing ) {
                return new WP_Error( 'already_exists', 'WP-аккаунт уже привязан: ' . $existing->user_login );
            }
        }

        $login = sanitize_user( $dispatcher->login, true );
        // Если логин занят, добавляем суффикс
        if ( username_exists( $login ) ) {
            $login = $login . '_disp' . $dispatcher_id;
        }

        if ( empty( $password ) ) {
            $password = wp_generate_password( 12, true, false );
        }

        if ( empty( $email ) ) {
            // Генерируем временный email если не указан
            $email = $login . '@' . parse_url( home_url(), PHP_URL_HOST );
        }

        $wp_user_id = wp_create_user( $login, $password, sanitize_email( $email ) );
        if ( is_wp_error( $wp_user_id ) ) return $wp_user_id;

        // Назначаем роль диспетчера
        $wp_user = new WP_User( $wp_user_id );
        $wp_user->set_role( 'ts_dispatcher' );

        // Обновляем отображаемое имя
        wp_update_user( array(
            'ID'           => $wp_user_id,
            'display_name' => $dispatcher->name,
            'first_name'   => $dispatcher->name,
        ) );

        // Сохраняем wp_user_id и email в таблице диспетчеров
        self::update( $dispatcher_id, array(
            'wp_user_id' => $wp_user_id,
            'email'      => sanitize_email( $email ),
        ) );

        return array(
            'wp_user_id' => $wp_user_id,
            'login'      => $login,
            'password'   => $password,
        );
    }

    /**
     * Отзывает WP-доступ диспетчера (снимает роль, не удаляет пользователя).
     */
    public static function revoke_wp_access( $dispatcher_id ) {
        $dispatcher = self::get( $dispatcher_id );
        if ( ! $dispatcher || empty( $dispatcher->wp_user_id ) ) return false;

        $wp_user = get_user_by( 'id', (int) $dispatcher->wp_user_id );
        if ( $wp_user ) {
            $wp_user->remove_role( 'ts_dispatcher' );
        }

        self::update( $dispatcher_id, array( 'wp_user_id' => null ) );
        return true;
    }
}
