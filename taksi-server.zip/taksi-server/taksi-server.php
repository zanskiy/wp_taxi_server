<?php
/**
 * Plugin Name: Такси Сервер
 * Plugin URI:  https://taksi-server.ru
 * Description: Полная система управления такси-диспетчерской. Без ограничений на количество машин, водителей, диспетчеров и телефонных линий.
 * Version:     2.0.5
 * Author:      Такси Сервер
 * Text Domain: taksi-server
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'TS_VERSION', '2.0.5' );
define( 'TS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'TS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'TS_PLUGIN_FILE', __FILE__ );

require_once TS_PLUGIN_DIR . 'includes/class-database.php';
require_once TS_PLUGIN_DIR . 'includes/class-orders.php';
require_once TS_PLUGIN_DIR . 'includes/class-cars.php';
require_once TS_PLUGIN_DIR . 'includes/class-drivers.php';
require_once TS_PLUGIN_DIR . 'includes/class-dispatchers.php';
require_once TS_PLUGIN_DIR . 'includes/class-phones.php';
require_once TS_PLUGIN_DIR . 'includes/class-api.php';
require_once TS_PLUGIN_DIR . 'includes/class-notifications.php';
require_once TS_PLUGIN_DIR . 'includes/class-reports.php';
require_once TS_PLUGIN_DIR . 'admin/class-admin.php';
require_once TS_PLUGIN_DIR . 'includes/class-auto-dispatch.php';

register_activation_hook( __FILE__, function() {
    TS_Database::install();
    if ( ! wp_next_scheduled( 'ts_auto_dispatch_cron' ) ) {
        wp_schedule_event( time(), 'ts_30sec', 'ts_auto_dispatch_cron' );
    }
} );

register_deactivation_hook( __FILE__, function() {
    wp_clear_scheduled_hook( 'ts_auto_dispatch_cron' );
    TS_Database::deactivate();
} );

/* Кастомный интервал 30 секунд */
add_filter( 'cron_schedules', function( $schedules ) {
    $schedules['ts_30sec'] = array(
        'interval' => 30,
        'display'  => 'Каждые 30 секунд (Такси Сервер)',
    );
    return $schedules;
} );

add_action( 'ts_auto_dispatch_cron', array( 'TS_AutoDispatch', 'run' ) );

function ts_init() {
    TS_Database::maybe_upgrade();
    new TS_Admin();
    new TS_Api();
    /* Обеспечиваем планировщик даже если плагин был активирован до обновления */
    if ( ! wp_next_scheduled( 'ts_auto_dispatch_cron' ) ) {
        wp_schedule_event( time(), 'ts_30sec', 'ts_auto_dispatch_cron' );
    }
}
add_action( 'plugins_loaded', 'ts_init' );
